--
-- PostgreSQL database dump
--

\restrict f40dWdJ33GZePfJmrRbJOOL7RgbxlmZIeAkOxZNdaT727qnhtEojjzXcLvOmywc

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9

-- Started on 2026-04-12 04:51:44 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4042 (class 0 OID 16525)
-- Dependencies: 342
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- TOC entry 4070 (class 0 OID 18612)
-- Dependencies: 377
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4053 (class 0 OID 16883)
-- Dependencies: 356
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
\.


--
-- TOC entry 4038 (class 0 OID 16495)
-- Dependencies: 338
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- TOC entry 4044 (class 0 OID 16681)
-- Dependencies: 347
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- TOC entry 4041 (class 0 OID 16518)
-- Dependencies: 341
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4055 (class 0 OID 16965)
-- Dependencies: 358
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- TOC entry 4045 (class 0 OID 16711)
-- Dependencies: 348
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
\.


--
-- TOC entry 4048 (class 0 OID 16770)
-- Dependencies: 351
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- TOC entry 4046 (class 0 OID 16745)
-- Dependencies: 349
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- TOC entry 4047 (class 0 OID 16758)
-- Dependencies: 350
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4056 (class 0 OID 16995)
-- Dependencies: 359
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- TOC entry 4058 (class 0 OID 17068)
-- Dependencies: 361
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- TOC entry 4057 (class 0 OID 17028)
-- Dependencies: 360
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- TOC entry 4054 (class 0 OID 16933)
-- Dependencies: 357
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4040 (class 0 OID 16507)
-- Dependencies: 340
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- TOC entry 4049 (class 0 OID 16788)
-- Dependencies: 352
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4051 (class 0 OID 16812)
-- Dependencies: 354
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4052 (class 0 OID 16830)
-- Dependencies: 355
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4043 (class 0 OID 16533)
-- Dependencies: 343
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- TOC entry 4050 (class 0 OID 16797)
-- Dependencies: 353
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4077 (class 0 OID 41279)
-- Dependencies: 384
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- TOC entry 4076 (class 0 OID 41256)
-- Dependencies: 383
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- TOC entry 4073 (class 0 OID 18914)
-- Dependencies: 380
-- Data for Name: Resort; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Resort" (id, name, region, "domainUrl", latitude, longitude, "createdAt", "updatedAt") FROM stdin;
3	Alpe du Grand Serre	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	45.0274177	5.8581966	2026-02-25 12:27:53.28	2026-04-11 11:19:37.06
155	Herbouilly	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	45.0132531	5.4701465	2026-03-06 11:20:21.598	2026-04-11 11:19:40.277
99	Centre de Ski Nordique      La Ruchère en Chartreuse	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	45.4083186	5.796905	2026-02-25 14:56:26.796	2026-04-11 11:19:45.578
156	Le Devoluy	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	44.6958651	5.8734588	2026-03-14 11:15:27.175	2026-04-11 11:19:46.639
1	Abriès-Ristolas - Espace Nordique du Queyras	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	44.8122222	6.9463074	2026-02-25 12:27:45.278	2026-04-11 11:19:47.7
2	Agy	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	46.0789668	6.6212953	2026-02-25 12:27:49.325	2026-04-11 11:19:48.053
153	Chaux Neuve - Le Pré Poncet	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	46.6438463	6.1358909	2026-02-26 11:32:25.119	2026-04-11 11:19:55.479
131	Lans en Vercors	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	45.109901	5.573013	2026-02-25 14:58:59.23	2026-04-11 11:20:09.262
51	Les Contamines-Montjoie	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	45.81104	6.724061	2026-02-25 12:31:18.638	2026-04-11 11:20:12.095
96	Villar d'Arène - Pays de La Meije	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	45.0425508	6.3357532	2026-02-25 14:56:14.465	2026-04-11 11:20:30.12
54	Les Saisies	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	45.7573298	6.5394475	2026-02-25 12:31:30.585	2026-03-31 11:39:59.581
5	Arvieux-Izoard - Espace Nordique du Queyras	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	44.7681112	6.7392651	2026-02-25 12:28:01.49	2026-04-11 11:19:49.467
100	DOMAINE DE CHAMECHAUDE - Col de Porte - Sappey en Chartreuse - St Hugues	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	45.2898838	5.7672199	2026-02-25 14:56:32.955	2026-04-11 11:19:45.931
50	Le Mas de la Barque	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	44.3858772	3.8758911	2026-02-25 12:31:15.944	2026-04-11 11:20:11.033
29	Domaine Nordique du Mézenc	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	44.9133204	4.1691681	2026-02-25 12:29:39.075	2026-04-11 11:19:59.719
15	Brison Solaison	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	46.0336213	6.4253519	2026-02-25 12:28:41.616	2026-04-11 11:19:53.357
17	Ceillac - Espace Nordique du Queyras	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	44.6683282	6.7780124	2026-02-25 12:28:49.641	2026-04-11 11:19:54.066
24	Crévoux - La Chalp	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	44.5478593	6.6233008	2026-02-25 12:29:17.174	2026-04-11 11:19:56.893
38	Haut Giffre	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	46.0823625	6.7598348	2026-02-25 12:30:19.679	2026-04-11 11:20:04.311
27	Domaine Nordique de Sur-Lyand / Grand Colombier	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	46.2840355	5.8469651	2026-02-25 12:29:31.162	2026-04-11 11:19:58.661
21	Chapelle des Bois	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	46.5982675	6.1148105	2026-02-25 12:29:04.703	2026-04-11 11:19:55.126
32	Espace nordique du Haut Vercors - Villard de Lans / Corrençon en Vercors / Herbouilly	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	45.1261702	5.5770815	2026-02-25 12:29:52.579	2026-04-11 11:20:01.131
28	Domaine Nordique des Crêtes du Forez	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	45.1444635	6.41965	2026-02-25 12:29:35.066	2026-04-11 11:19:59.014
33	Foncine-le-Haut	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	46.6596029	6.0743773	2026-02-25 12:29:58.623	2026-04-11 11:20:01.485
26	Domaine Nordique La Bresse-Lispach	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	48.0488045	6.9441511	2026-02-25 12:29:26.722	2026-04-11 11:19:57.954
36	Giron 1000	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	46.2382601	5.768103	2026-02-25 12:30:11.743	2026-04-11 11:20:02.899
47	Le Boréon	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	44.1125922	7.2943627	2026-02-25 12:31:01.089	2026-04-11 11:19:40.986
35	Freissinières	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	44.7536692	6.5377602	2026-02-25 12:30:07.539	2026-04-11 11:20:02.192
39	Hautes Combes du Jura	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	46.3748883	5.9755882	2026-02-25 12:30:23.618	2026-04-11 11:20:05.371
44	La Draye	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	44.797485	6.7269921	2026-02-25 12:30:46.508	2026-04-11 11:20:08.199
12	Beuil Valberg	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	44.1098791	6.9222285	2026-02-25 12:28:28.83	2026-04-11 11:19:37.798
41	La Chapelle d'Abondance	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	46.2957033	6.7883361	2026-02-25 12:30:31.746	2026-04-11 11:20:06.784
19	Champagny-en-Vanoise	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	45.456381	6.700398	2026-02-25 12:28:56.376	2026-04-11 11:19:38.152
43	La Colle Saint Michel	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	44.0472857	6.5932018	2026-02-25 12:30:39.694	2026-04-11 11:20:07.845
42	La Clusaz-Espace Nordique des Confins	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	45.9043659	6.4239011	2026-02-25 12:30:35.647	2026-04-11 11:20:07.491
48	Le Désert d'Entremont en Chartreuse	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	45.4216326	5.8615922	2026-02-25 12:31:07.853	2026-04-11 11:20:10.326
46	Larche - Val d'Oronaye	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	44.4511952	6.84629	2026-02-25 12:30:55.052	2026-04-11 11:20:09.616
31	Espace nordique du Barioz	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	45.3124803	6.0090293	2026-02-25 12:29:47.021	2026-04-11 11:19:39.569
8	BEILLE	Occitanie	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	42.7247664	1.6911439	2026-02-25 12:28:13.687	2026-04-11 11:19:50.527
11	Bessans	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/bessans/	45.3205925	6.9940386	2026-02-25 12:28:24.874	2026-04-11 11:19:37.441
22	Col d'Ornon	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	45.0082793	5.9674424	2026-02-25 12:29:09.177	2026-04-11 11:19:38.862
9	Bellefontaine	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	46.5580386	6.0666661	2026-02-25 12:28:16.363	2026-04-11 11:19:51.236
18	Cervières - Izoard	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	44.8550954	6.7273292	2026-02-25 12:28:53.544	2026-04-11 11:19:54.772
20	Chamrousse	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	45.1108068	5.8748399	2026-02-25 12:29:00.38	2026-04-11 11:19:38.509
25	Domaine Nordique Du Col De La Llose	Occitanie	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	42.5356785	2.1423823	2026-02-25 12:29:22.699	2026-04-11 11:19:39.216
30	Espace Nordique du Grand Coin	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	45.343764	6.356184	2026-02-25 12:29:43.078	2026-04-11 11:20:00.778
14	Brameloup	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	46.0457252	6.1210229	2026-02-25 12:28:37.182	2026-04-11 11:19:53.003
45	La Montagne Ardéchoise	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	44.7563545	4.0982327	2026-02-25 12:30:51.054	2026-04-11 11:19:40.632
49	Le Grand-Bornand	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	45.9418675	6.4271457	2026-02-25 12:31:11.848	2026-04-11 11:19:41.34
37	Haut Champsaur	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	44.6671003	6.2255541	2026-02-25 12:30:15.728	2026-04-11 11:20:03.958
6	Arèches Beaufort	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	45.6629892	6.5663191	2026-02-25 12:28:05.586	2026-04-11 11:19:49.82
40	LE CHIOULA	Occitanie	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	42.7555288	1.8412857	2026-02-25 12:30:27.577	2026-04-11 11:20:06.077
7	Aussois Val Cenis Sardières	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	45.225985	6.7542714	2026-02-25 12:28:09.682	2026-04-11 11:19:50.174
10	Bellevaux Les Mouilles	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	46.2480907	6.5160727	2026-02-25 12:28:20.946	2026-04-11 11:19:51.59
16	Casterino	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/casterino/	44.0985211	7.5063667	2026-02-25 12:28:45.63	2026-04-11 11:19:53.713
23	Col de la Loge-Domaine Nordique du Haut Forez	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	45.7425858	3.7797056	2026-02-25 12:29:13.202	2026-04-11 11:19:56.185
13	Bleymard Mont Lozere	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	44.483456	3.7320971	2026-02-25 12:28:33.28	2026-04-11 11:19:52.297
4	Ancelle	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	44.6235694	6.2097914	2026-02-25 12:27:57.289	2026-04-11 11:19:48.406
34	Font d'Urle	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	44.8989095	5.3217674	2026-02-25 12:30:03.112	2026-04-11 11:19:39.922
53	Les Glières	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	45.9620128	6.3229703	2026-02-25 12:31:26.652	2026-04-11 11:20:13.157
55	Longchaumois / le Rosset	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	46.4567972	5.9689559	2026-02-25 12:31:34.886	2026-04-11 11:19:41.695
77	Saint Paul sur Ubaye	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	44.5150043	6.7511484	2026-02-25 14:51:05.899	2026-04-11 11:20:24.116
60	Morbier	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/morbier/	46.5363166	6.0169531	2026-02-25 12:31:55.788	2026-04-11 11:20:16.34
83	Stade Raphaël Poirée	\N	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	44.878934	5.408478	2026-02-25 14:51:31.348	2026-04-11 11:19:43.814
69	Plateau de Beauregard	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	45.8938937	6.4036156	2026-02-25 12:32:30.992	2026-04-11 11:20:19.876
64	Nâves	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/naves/	45.5532457	6.5312475	2026-02-25 12:32:11.765	2026-04-11 11:20:17.755
71	Prat de Bouc - Haute Planeze	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	45.0519969	2.7942799	2026-02-25 14:50:40.35	2026-04-11 11:20:21.643
90	Val d'Allos	\N	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	44.240363	6.616202	2026-02-25 14:51:59.674	2026-04-11 11:19:44.52
72	Praz de Lys Sommand	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	46.1574673	6.5694854	2026-02-25 14:50:44.707	2026-04-11 11:20:21.996
78	Savoie Grand Revard	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	45.6775655	6.0323852	2026-02-25 14:51:09.929	2026-04-11 11:20:25.175
67	Plaine-Joux les Brasses	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	44.8153028	4.6090715	2026-02-25 12:32:24.157	2026-04-11 11:20:19.168
84	Station Gap Bayard	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	44.6138218	6.0811415	2026-02-25 14:51:36.35	2026-04-11 11:20:26.234
66	Peisey-Vallandry	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	45.5722965	6.8117478	2026-02-25 12:32:19.634	2026-04-11 11:19:42.754
86	Station du Lac Blanc	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	48.146344	7.077408	2026-02-25 14:51:43.582	2026-04-11 11:20:26.942
88	Sur-Lyand / Grand Colombier	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	45.960427	5.7674034	2026-02-25 14:51:52.646	2026-04-11 11:20:27.648
82	Site nordique Vallouise-Pelvoux-les Vigneaux	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	44.8648403	6.4408129	2026-02-25 14:51:28.632	2026-04-11 11:20:25.527
93	Valgaudemar	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	44.8169384	6.1958804	2026-02-25 14:56:01.594	2026-04-11 11:20:29.061
97	Villard-Saint-Pancrace - Centre Montagne	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	44.880085	6.63555	2026-02-25 14:56:17.626	2026-04-11 11:20:30.474
56	Lus la Jarjatte	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	44.6719918	5.7719434	2026-02-25 12:31:38.984	2026-04-11 11:19:42.048
79	Serre Chevalier	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	44.9107381	6.5500282	2026-02-25 14:51:13.989	2026-04-11 11:19:43.108
68	Plateau d'Hauteville	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	45.973353	5.595856	2026-02-25 12:32:26.968	2026-04-11 11:20:19.521
57	Megève	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/megeve/	45.8567089	6.617932	2026-02-25 12:31:43.59	2026-04-11 11:20:14.217
62	Mouthe - Chez Liadet	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	46.7115978	6.1932371	2026-02-25 12:32:03.655	2026-04-11 11:20:16.696
89	Trois Fours	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	48.055956	7.0261423	2026-02-25 14:51:56.893	2026-03-08 22:26:57.098
63	Métabief - Mont d'Or	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	46.7406564	6.3727627	2026-02-25 12:32:07.716	2026-04-11 11:20:17.049
70	Pralognan-la-Vanoise	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	45.381809	6.7212822	2026-02-25 12:32:36.839	2026-04-11 11:20:21.289
87	Station du Plateau de Retord	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	46.035344	5.6965887	2026-02-25 14:51:48.11	2026-03-05 11:26:16.193
74	Ratėry 1700	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/3040/	44.1873049	6.6525541	2026-02-25 14:50:53.815	2026-04-11 11:20:23.057
52	Les Fourgs - L'Herba	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	46.8332037	6.4090287	2026-02-25 12:31:22.683	2026-04-11 11:20:12.802
91	Val-Cenis Bramans domaine nordique du Val d'Ambin	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	45.2421277	6.773802	2026-02-25 14:52:06.469	2026-04-11 11:19:44.873
65	Névache	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/nevache/	45.0189597	6.6040901	2026-02-25 12:32:15.716	2026-04-11 11:20:18.108
58	Molines/Saint-Véran - Espace Nordique du Queyras	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	44.7122166	6.8702566	2026-02-25 12:31:47.672	2026-04-11 11:20:14.923
76	Réallon	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/reallon/	44.6161932	6.3564377	2026-02-25 14:51:01.769	2026-04-11 11:20:23.762
73	Puy-Saint-Vincent	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	44.8279543	6.4926273	2026-02-25 14:50:49.244	2026-04-11 11:20:22.702
75	Rochelotte	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	47.9061644	6.8542953	2026-02-25 14:50:57.832	2026-04-11 11:20:23.41
81	Site Nordique de Pleine Nature et Auberge Montagnarde du Fanget	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	44.4272046	6.3004211	2026-02-25 14:51:24.52	2026-04-11 11:19:47.346
98	Barcelonnette	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	44.3862043	6.6513554	2026-02-25 14:56:22.21	2026-04-11 11:19:50.882
94	Valloire-Galibier	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	45.1655061	6.43242	2026-02-25 14:56:06.55	2026-04-11 11:19:45.225
61	Morzine Avoriaz	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	46.1934884	6.7736261	2026-02-25 12:31:59.725	2026-04-11 11:19:42.401
95	Vallée de Chamonix Mont-Blanc	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	45.940171	6.917463	2026-02-25 14:56:09.627	2026-04-11 11:20:29.414
59	Monts Jura	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	46.3655559	5.9797481	2026-02-25 12:31:51.783	2026-04-11 11:20:15.987
85	Station des Rousses	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	46.4879234	6.0965015	2026-02-25 14:51:40.817	2026-04-11 11:19:44.167
80	Site Nordique Altiservice Font-romeu Pyrenees2000	Occitanie	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	42.5316189	2.0202025	2026-02-25 14:51:20.442	2026-04-11 11:19:43.461
92	Val-des-Prés/Les Alberts	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	43.6882969	7.2288633	2026-02-25 14:55:56.953	2026-04-11 11:20:28.707
132	Laubert - Plateau du Roy	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	44.8321656	4.9754963	2026-02-25 14:59:04.261	2026-04-11 11:20:09.969
133	Le Grand Echaillon	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	44.9136033	5.2081528	2026-02-25 14:59:08.973	2026-04-11 11:20:10.68
134	Le Poli - Fontaine Ferry	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	48.0703893	6.907254	2026-02-25 14:59:13.502	2026-04-11 11:20:11.387
104	Plateau de Maîche / Combe Saint-Pierre	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	47.251676	6.7994083	2026-02-25 14:56:51.382	2026-04-11 11:20:20.23
138	Les Sept Laux Papoutel Beldina	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	45.3730244	5.993103	2026-02-25 14:59:30.521	2026-04-11 11:20:13.864
145	Plateau du Russey	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	47.1621347	6.726069	2026-02-25 15:00:06.673	2026-04-11 11:20:20.583
146	Pontarlier - Larmont / Malmaison / Granges-Dessus / Verrières-de-Joux	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	46.9040348	6.3546345	2026-02-25 15:00:12.528	2026-04-11 11:20:20.936
141	Montoncel	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	45.925722	3.6994958	2026-02-25 14:59:44.448	2026-04-11 11:20:15.633
105	Saint-Urcize	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	44.6963584	3.0029102	2026-02-25 14:56:56.389	2026-04-11 11:20:24.822
106	Val de Morteau	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	47.0316089	6.5438277	2026-02-25 14:57:01.107	2026-04-11 11:20:28.001
102	Le Semnoz	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	45.7909791	6.1018971	2026-02-25 14:56:42.154	2026-04-11 11:19:46.992
107	Apremont	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/apremont/	46.2088936	5.6472045	2026-02-25 14:57:07.815	2026-04-11 11:19:48.76
108	Arc sous Cicon	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	47.0515549	6.3794128	2026-02-25 14:57:12.337	2026-04-11 11:19:49.113
109	Belleydoux	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	46.2525	5.77757	2026-02-25 14:57:18.335	2026-04-11 11:19:51.944
110	Bonnecombe	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	44.2433519	2.5546659	2026-02-25 14:57:22.861	2026-04-11 11:19:52.65
111	Centre Montagnard de Lachat	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	46.069811	5.6650313	2026-02-25 14:57:27.664	2026-04-11 11:19:54.419
112	Chichilianne-Mont-Aiguille	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	44.8116	5.57362	2026-02-25 14:57:34.04	2026-04-11 11:19:55.832
113	Col du Béal	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	45.685236	3.7828102	2026-02-25 14:57:38.471	2026-04-11 11:19:56.539
144	Parrot	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	45.3546982	2.9995142	2026-02-25 15:00:02.014	2026-04-11 11:20:18.815
114	Destination Ballon Alsace	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/1560/	47.8223547	6.8452273	2026-02-25 14:57:43.115	2026-04-11 11:19:57.248
116	Domaine Nordique Markstein Grand-Ballon	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	47.9008362	7.0983962	2026-02-25 14:57:52.901	2026-04-11 11:19:58.308
117	Domaine Nordique du Meygal	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	45.0560533	4.134308	2026-02-25 14:57:57.554	2026-04-11 11:19:59.366
118	Espace Ludique du Col de Marcieu à Saint- Bernard- du -Touvet	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/4971/	45.3559795	5.9188679	2026-02-25 14:58:02.22	2026-04-11 11:20:00.073
119	Espace Nordique des Monts du Pilat	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	45.3199427	4.4885837	2026-02-25 14:58:06.62	2026-04-11 11:20:00.426
136	Le Valtin/Col de la Schlucht	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	48.062052	7.020086	2026-02-25 14:59:21.049	2026-03-08 22:26:58.316
120	Frasne	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/frasne/	46.8570466	6.1617717	2026-02-25 14:58:11.185	2026-04-11 11:20:01.839
101	La Baraque des Bouviers	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	44.7586292	3.5220076	2026-02-25 14:56:37.54	2026-04-11 11:19:46.286
121	Gilley-Les Combes	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/gilley/	47.0512982	6.5332143	2026-02-25 14:58:16.092	2026-04-11 11:20:02.545
122	Gresse en Vercors	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	44.9011374	5.5662216	2026-02-25 14:58:20.68	2026-04-11 11:20:03.252
123	Gréolières	Provence-Alpes-Côte d'Azur	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	43.7951809	6.9435947	2026-02-25 14:58:25.228	2026-04-11 11:20:03.605
124	Haut Saugeais Blanc	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	47.048185	6.4874479	2026-02-25 14:58:29.946	2026-04-11 11:20:04.664
125	Haute Joux	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	46.8391431	6.4325249	2026-02-25 14:58:34.338	2026-04-11 11:20:05.017
128	La Chaux de Gilley - La Cernay Blanche	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	47.0191479	6.4288532	2026-02-25 14:58:46.711	2026-04-11 11:20:07.138
127	La Chapelle Rambaud	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	46.0716672	6.2400559	2026-02-25 14:58:43.624	2026-04-11 11:20:06.431
129	Lac des Rouges Truites - Domaine du Bugnon	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	46.6071203	5.9983349	2026-02-25 14:58:51.34	2026-04-11 11:20:08.552
126	L'Espace Nordique de Pailherols en Carladès	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	44.9508153	2.6845586	2026-02-25 14:58:39.229	2026-04-11 11:20:05.724
135	Le Salève	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	46.1118445	6.1623606	2026-02-25 14:59:17.933	2026-04-11 11:20:11.741
103	Les Moises (Le Léman)	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	46.2856149	6.4676783	2026-02-25 14:56:46.782	2026-04-11 11:20:13.51
140	Mont Lozère - Finiels	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/	44.4042065	3.7452601	2026-02-25 14:59:39.93	2026-04-11 11:20:15.279
139	Mijanes-Donezan	Occitanie	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	42.7221137	2.0092254	2026-02-25 14:59:35.39	2026-04-11 11:20:14.57
137	Les Crozets - Terre d'Emeraude	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	46.4597	5.79485	2026-02-25 14:59:25.957	2026-04-11 11:20:12.448
142	Nasbinals - Fer à cheval	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	44.6625448	3.0465813	2026-02-25 14:59:51.688	2026-04-11 11:20:17.402
143	Orange - Pays Rochois	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	46.0263628	6.3137387	2026-02-25 14:59:56.459	2026-04-11 11:20:18.461
115	Domaine Nordique Gérardmer Stations	Grand Est	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	48.0705772	6.8776965	2026-02-25 14:57:47.768	2026-04-11 11:19:57.601
130	Laguiole	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	44.6514694	2.9668479	2026-02-25 14:58:55.8	2026-04-11 11:20:08.905
147	Prénovel / Les Piards / Chaux-des-Prés NANCHEZ	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	46.5170807	5.8538534	2026-02-25 15:00:16.984	2026-04-11 11:20:22.35
148	Saint-Pierre-en-Grandvaux / Trémontagne	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	46.5690947	5.9097897	2026-02-25 15:00:21.884	2026-04-11 11:20:24.468
154	Station Autrans-Méaudre en Vercors-Domaine nordique	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	45.171305	5.544373	2026-03-05 11:26:15.386	2026-04-11 11:20:25.881
149	Station des Coulmes Centre nordique des Coulmes	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	45.1438725	5.4796741	2026-02-25 15:00:26.625	2026-04-11 11:20:26.588
150	Station du Semnoz	\N	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	45.8033674	6.0975382	2026-02-25 15:00:32.244	2026-04-11 11:20:27.295
151	Val de Vennes	Bourgogne-Franche-Comté	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	47.206635	6.5475682	2026-02-25 15:00:40.489	2026-04-11 11:20:28.354
152	Vassieux en Vercors (voies blanches et raquettes)	Auvergne-Rhône-Alpes	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	44.8954252	5.3707565	2026-02-25 15:00:45.532	2026-04-11 11:20:29.767
\.


--
-- TOC entry 4075 (class 0 OID 18924)
-- Dependencies: 382
-- Data for Name: SnowRecord; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SnowRecord" (id, "resortId", "recordDate", "openSlopes", "totalSlopes", notes, "sourceUrl", "createdAt") FROM stdin;
7152	1	2026-03-09 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-09 00:00:00
10	10	2026-02-21 00:00:00	9	9	32.1km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-25 12:28:20.973
8	8	2026-02-24 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-02-25 12:28:13.715
14	14	2026-02-22 00:00:00	5	18	25.5km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-25 12:28:37.208
5	5	2026-02-24 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-02-25 12:28:01.518
6	6	2026-02-22 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-25 12:28:05.615
7	7	2026-02-25 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-02-25 12:28:09.71
16	16	2026-01-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-25 12:28:45.656
9	9	2026-02-25 00:00:00	16	23	90.1km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-02-25 12:28:16.392
11	11	2026-02-25 00:00:00	21	27	118.6km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-02-25 12:28:24.899
12	12	2026-02-25 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-02-25 12:28:28.856
13	13	2026-02-21 00:00:00	11	15	38.45km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-25 12:28:33.307
3	3	2026-02-24 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-02-25 12:27:53.311
41	41	2026-02-23 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-25 12:30:31.771
42	42	2026-02-25 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-02-25 12:30:35.673
17	17	2026-02-24 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-02-25 12:28:49.667
18	18	2026-02-25 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-02-25 12:28:53.57
19	19	2026-02-24 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-02-25 12:28:56.402
20	20	2026-02-24 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-02-25 12:29:00.405
21	21	2026-02-25 00:00:00	26	27	215.2km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-02-25 12:29:04.73
28	28	2026-02-20 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-25 12:29:35.112
23	23	2026-02-24 00:00:00	3	11	30km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-02-25 12:29:13.23
24	24	2026-02-25 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-02-25 12:29:17.2
25	25	2026-02-25 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-02-25 12:29:22.725
26	26	2026-02-25 00:00:00	8	14	32km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-02-25 12:29:26.748
27	27	2026-02-24 00:00:00	13	13	57.4km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-02-25 12:29:31.189
30	30	2026-02-24 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-02-25 12:29:43.105
33	33	2026-02-25 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-02-25 12:29:58.649
32	32	2026-02-10 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-25 12:29:52.605
43	43	2026-02-25 00:00:00	12	12	97.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-02-25 12:30:39.719
22	22	2026-01-21 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-25 12:29:09.206
34	34	2026-02-24 00:00:00	19	20	123.4km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-02-25 12:30:03.137
50	50	2026-02-21 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-25 12:31:15.969
36	36	2026-02-24 00:00:00	12	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-02-25 12:30:11.769
37	37	2026-02-25 00:00:00	17	23	62.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-02-25 12:30:15.753
38	38	2026-02-25 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-02-25 12:30:19.705
39	39	2026-02-25 00:00:00	70	74	330.8km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-02-25 12:30:23.643
40	40	2026-02-25 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-02-25 12:30:27.603
31	31	2026-01-13 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-25 12:29:47.046
35	35	2026-01-28 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-25 12:30:07.567
44	44	2026-01-27 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-25 12:30:46.533
46	46	2026-02-25 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-02-25 12:30:55.078
45	45	2026-02-25 00:00:00	42	59	202.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-02-25 12:30:51.08
47	47	2026-01-27 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-25 12:31:01.115
2	2	2026-02-23 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-25 12:27:49.353
48	48	2026-02-25 00:00:00	24	26	77.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-02-25 12:31:07.878
49	49	2026-02-24 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-02-25 12:31:11.873
4	4	2026-02-20 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-25 12:27:57.315
51	51	2026-02-25 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-02-25 12:31:18.664
52	52	2026-02-25 00:00:00	20	41	69.8km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-02-25 12:31:22.708
15	15	2026-02-17 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-25 12:28:41.644
63	63	2026-02-25 00:00:00	18	33	96.1km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-02-25 12:32:07.826
64	64	2026-02-25 00:00:00	20	21	75.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-02-25 12:32:11.807
141	71	2026-02-24 00:00:00	16	28	51.3km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-02-25 14:50:40.379
66	66	2026-02-25 00:00:00	19	22	45.2km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-02-25 12:32:19.662
67	67	2026-02-25 00:00:00	7	12	23.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-02-25 12:32:24.188
142	72	2026-02-25 00:00:00	28	30	96.6km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-02-25 14:50:44.736
69	69	2026-02-25 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-02-25 12:32:31.019
70	70	2026-02-25 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-02-25 12:32:36.864
150	80	2026-02-13 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-25 14:51:20.47
151	81	2026-01-27 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-25 14:51:24.546
146	76	2026-02-19 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-25 14:51:01.795
147	77	2026-02-23 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-25 14:51:05.926
148	78	2026-02-25 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-02-25 14:51:09.955
149	79	2026-02-25 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-02-25 14:51:14.02
7153	2	2026-03-09 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-09 00:00:00
54	54	2026-02-17 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-25 12:31:30.611
152	82	2026-02-24 00:00:00	14	16	41.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-02-25 14:51:28.659
7154	3	2026-03-09 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-09 00:00:00
1	1	2026-02-24 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-02-25 12:27:45.334
80	10	2026-02-25 00:00:00	7	9	22.3km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-25 14:50:30.622
29	29	2026-02-23 00:00:00	13	13	67.8km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-25 12:29:39.101
53	53	2026-02-25 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-02-25 12:31:26.678
7155	4	2026-03-09 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-09 00:00:00
7156	5	2026-03-09 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-09 00:00:00
7157	7	2026-03-09 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-09 00:00:00
57	57	2026-02-25 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-02-25 12:31:43.618
58	58	2026-02-24 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-02-25 12:31:47.7
59	59	2026-02-25 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-02-25 12:31:51.809
60	60	2026-02-25 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-02-25 12:31:55.815
61	61	2026-02-24 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-02-25 12:31:59.752
62	62	2026-02-25 00:00:00	21	24	117.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-02-25 12:32:03.703
143	73	2026-02-25 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-02-25 14:50:49.271
7158	8	2026-03-09 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-09 00:00:00
7159	9	2026-03-09 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-09 00:00:00
55	55	2026-02-07 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-25 12:31:34.915
56	56	2026-02-21 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-25 12:31:39.01
65	65	2026-02-24 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-02-25 12:32:15.742
144	74	2026-01-11 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-25 14:50:53.843
145	75	2026-01-21 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-25 14:50:57.861
7160	10	2026-03-09 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-09 00:00:00
7161	11	2026-03-09 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-09 00:00:00
7162	12	2026-03-09 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-09 00:00:00
7163	13	2026-03-09 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-09 00:00:00
7164	15	2026-03-09 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-09 00:00:00
7165	16	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-09 00:00:00
68	68	2026-02-25 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-02-25 12:32:26.993
7166	17	2026-03-09 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-09 00:00:00
7167	18	2026-03-09 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-09 00:00:00
7168	19	2026-03-09 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-09 00:00:00
7169	20	2026-03-09 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-09 00:00:00
7170	153	2026-03-09 00:00:00	8	25	64.7km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-09 00:00:00
285	124	2026-02-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-25 14:58:30.063
264	103	2026-02-24 00:00:00	32	64	73.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-02-25 14:56:46.9
155	85	2026-02-25 00:00:00	53	62	242.1km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-02-25 14:51:40.844
153	83	2026-02-06 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-25 14:51:31.376
157	87	2026-02-25 00:00:00	25	47	227.8km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-02-25 14:51:48.138
158	88	2026-02-24 00:00:00	13	13	62.5km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-02-25 14:51:52.673
159	89	2026-02-25 00:00:00	5	5	16km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-02-25 14:51:56.92
261	100	2026-02-25 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-02-25 14:56:33.074
160	90	2026-01-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-25 14:51:59.701
253	92	2026-02-25 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-02-25 14:55:57.072
254	93	2026-02-25 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-02-25 14:56:01.712
255	94	2026-02-24 00:00:00	2	5	2.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-02-25 14:56:06.668
256	95	2026-02-25 00:00:00	8	16	28km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-02-25 14:56:09.748
257	96	2026-02-25 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-02-25 14:56:14.583
258	97	2026-02-25 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-02-25 14:56:17.744
263	102	2026-02-25 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-02-25 14:56:42.272
265	104	2026-02-25 00:00:00	1	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-02-25 14:56:51.5
267	106	2026-02-24 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-02-25 14:57:01.225
8811	1	2026-03-20 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-20 00:00:00
8812	2	2026-03-20 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-20 00:00:00
8813	3	2026-03-20 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-20 00:00:00
8814	4	2026-03-20 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-20 00:00:00
8815	5	2026-03-20 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-20 00:00:00
8816	7	2026-03-20 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-20 00:00:00
8817	8	2026-03-20 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-20 00:00:00
8818	9	2026-03-20 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-20 00:00:00
262	101	2026-02-23 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-25 14:56:37.659
154	84	2026-02-21 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-25 14:51:36.377
161	91	2026-02-24 00:00:00	14	15	78.2km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-02-25 14:52:06.495
269	108	2026-02-22 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-25 14:57:12.455
270	109	2026-01-18 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-25 14:57:18.452
266	105	2026-02-25 00:00:00	5	20	34.5km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-02-25 14:56:56.506
278	117	2026-02-11 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-25 14:57:57.673
281	120	2026-01-19 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-25 14:58:11.303
282	121	2026-02-04 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-25 14:58:16.21
286	125	2026-02-25 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-02-25 14:58:34.456
7171	22	2026-03-09 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-09 00:00:00
259	98	2026-02-06 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-25 14:56:22.328
268	107	2026-02-17 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-25 14:57:07.933
272	111	2026-02-05 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-25 14:57:27.782
156	86	2026-02-24 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-02-25 14:51:43.609
276	115	2026-02-24 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-02-25 14:57:47.886
260	99	2026-02-25 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-02-25 14:56:26.914
284	123	2026-02-11 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-25 14:58:25.346
7172	24	2026-03-09 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-09 00:00:00
7173	25	2026-03-09 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-09 00:00:00
7174	26	2026-03-09 00:00:00	5	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-09 00:00:00
7175	27	2026-03-09 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-09 00:00:00
7176	29	2026-03-09 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-09 00:00:00
7177	30	2026-03-09 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-09 00:00:00
7178	31	2026-03-09 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-09 00:00:00
7179	32	2026-03-09 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-09 00:00:00
8819	10	2026-03-20 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-20 00:00:00
292	131	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-02-25 14:58:59.348
8820	11	2026-03-20 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-20 00:00:00
297	136	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-02-25 14:59:21.167
8821	12	2026-03-20 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-20 00:00:00
8822	15	2026-03-20 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-20 00:00:00
304	143	2026-03-14 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-02-25 14:59:56.577
8823	16	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-20 00:00:00
8824	17	2026-03-20 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-20 00:00:00
320	7	2026-02-26 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-02-26 11:32:18.27
322	9	2026-02-26 00:00:00	16	23	90.1km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-02-26 11:32:18.918
324	11	2026-02-26 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-02-26 11:32:19.565
325	12	2026-02-26 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-02-26 11:32:19.887
331	18	2026-02-26 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-02-26 11:32:21.819
333	20	2026-02-26 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-02-26 11:32:22.462
334	21	2026-02-26 00:00:00	24	27	186.7km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-02-26 11:32:22.783
335	153	2026-02-26 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-02-26 11:32:25.229
337	24	2026-02-26 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-02-26 11:32:25.873
339	26	2026-02-26 00:00:00	8	14	32km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-02-26 11:32:26.516
340	27	2026-02-26 00:00:00	13	13	57.4km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-02-26 11:32:26.838
350	37	2026-02-26 00:00:00	17	23	62.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-02-26 11:32:30.056
351	38	2026-02-26 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-02-26 11:32:30.379
352	39	2026-02-26 00:00:00	69	74	326.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-02-26 11:32:30.703
353	40	2026-02-26 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-02-26 11:32:31.024
301	140	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-25 14:59:40.047
295	134	2026-01-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-25 14:59:13.619
310	149	2026-03-17 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-02-25 15:00:26.743
306	145	2026-02-20 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-25 15:00:06.79
307	146	2026-02-24 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-02-25 15:00:12.645
308	147	2026-02-11 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-25 15:00:17.101
309	148	2026-02-03 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-25 15:00:22.002
311	150	2026-01-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-25 15:00:32.364
312	151	2026-01-24 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-25 15:00:40.635
326	13	2026-02-25 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-26 11:32:20.208
288	127	2026-01-12 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-25 14:58:43.742
289	128	2026-02-04 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-25 14:58:46.829
290	129	2026-02-03 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-25 14:58:51.458
294	133	2026-02-24 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-02-25 14:59:09.09
323	10	2026-02-26 00:00:00	5	9	15.8km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-26 11:32:19.241
319	6	2026-02-26 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-26 11:32:17.945
314	1	2026-02-25 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-02-26 11:32:16.302
318	5	2026-02-25 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-02-26 11:32:17.621
338	25	2026-02-26 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-02-26 11:32:26.194
332	19	2026-02-26 00:00:00	11	16	24.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-02-26 11:32:22.141
296	135	2026-02-03 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-25 14:59:18.05
330	17	2026-02-25 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-02-26 11:32:21.497
298	137	2026-02-03 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-25 14:59:26.074
299	138	2026-01-30 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-25 14:59:30.639
342	29	2026-02-26 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-26 11:32:27.481
347	34	2026-02-26 00:00:00	18	20	109.7km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-02-26 11:32:29.089
349	36	2026-02-26 00:00:00	11	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-02-26 11:32:29.733
358	45	2026-02-26 00:00:00	41	59	195km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-02-26 11:32:32.631
359	131	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-02-26 11:32:32.961
362	48	2026-02-26 00:00:00	24	26	77.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-02-26 11:32:33.928
363	49	2026-02-26 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-02-26 11:32:34.25
365	51	2026-02-26 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-02-26 11:32:34.895
366	52	2026-02-26 00:00:00	14	41	57.3km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-02-26 11:32:35.216
367	53	2026-02-26 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-02-26 11:32:35.537
371	57	2026-02-26 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-02-26 11:32:36.825
7180	34	2026-03-09 00:00:00	14	20	90.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-09 00:00:00
373	59	2026-02-26 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-02-26 11:32:37.469
374	60	2026-02-26 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-02-26 11:32:37.79
376	62	2026-02-26 00:00:00	21	24	117.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-02-26 11:32:38.433
377	63	2026-02-26 00:00:00	17	33	94.1km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-02-26 11:32:38.755
378	64	2026-02-26 00:00:00	20	21	75.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-02-26 11:32:39.076
383	69	2026-02-26 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-02-26 11:32:40.682
384	70	2026-02-26 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-02-26 11:32:41.003
390	76	2026-02-26 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-26 11:32:42.93
391	77	2026-02-26 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-26 11:32:43.251
393	79	2026-02-26 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-02-26 11:32:43.894
396	82	2026-02-26 00:00:00	14	16	41.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-02-26 11:32:44.862
399	85	2026-02-26 00:00:00	53	62	242.1km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-02-26 11:32:45.826
401	87	2026-02-26 00:00:00	20	47	158km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-02-26 11:32:46.468
402	88	2026-02-26 00:00:00	13	13	62.5km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-02-26 11:32:46.789
403	89	2026-02-26 00:00:00	5	5	16km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-02-26 11:32:47.11
406	92	2026-02-26 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-02-26 11:32:48.075
407	93	2026-02-26 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-02-26 11:32:48.396
409	95	2026-02-26 00:00:00	9	16	31km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-02-26 11:32:49.039
410	96	2026-02-26 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-02-26 11:32:49.362
411	97	2026-02-26 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-02-26 11:32:49.683
416	102	2026-02-26 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-02-26 11:32:51.29
7181	35	2026-03-09 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-09 00:00:00
448	136	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-02-26 11:33:01.574
8825	18	2026-03-20 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-20 00:00:00
473	7	2026-02-27 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-02-27 11:24:16.677
475	9	2026-02-27 00:00:00	16	23	90.1km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-02-27 11:24:17.591
477	11	2026-02-27 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-02-27 11:24:18.502
478	12	2026-02-27 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-02-27 11:24:18.957
484	18	2026-02-27 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-02-27 11:24:21.691
487	21	2026-02-27 00:00:00	22	27	180.5km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-02-27 11:24:23.057
488	153	2026-02-27 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-02-27 11:24:23.511
490	24	2026-02-27 00:00:00	4	8	14.4km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-02-27 11:24:24.42
492	26	2026-02-27 00:00:00	7	14	29km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-02-27 11:24:25.331
425	23	2026-02-26 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-02-26 11:32:54.186
381	67	2026-02-26 00:00:00	7	12	23.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-02-26 11:32:40.039
387	73	2026-02-26 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-02-26 11:32:41.967
392	78	2026-02-26 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-02-26 11:32:43.572
464	106	2026-02-26 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-02-26 11:33:06.705
486	20	2026-02-27 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-02-27 11:24:22.602
457	104	2026-02-26 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-02-26 11:33:04.462
380	66	2026-02-26 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-02-26 11:32:39.718
408	94	2026-02-26 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-02-26 11:32:48.718
375	61	2026-02-26 00:00:00	7	7	20.8km/20.8km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-02-26 11:32:38.112
493	27	2026-02-27 00:00:00	10	13	36.5km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-02-27 11:24:25.786
7182	37	2026-03-09 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-09 00:00:00
502	37	2026-02-27 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-02-27 11:24:29.883
503	38	2026-02-27 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-02-27 11:24:30.337
504	39	2026-02-27 00:00:00	69	74	326.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-02-27 11:24:30.791
505	40	2026-02-27 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-02-27 11:24:31.246
510	45	2026-02-27 00:00:00	41	59	186.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-02-27 11:24:33.518
511	131	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-02-27 11:24:33.973
512	46	2026-02-26 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-02-27 11:24:34.427
515	49	2026-02-27 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-02-27 11:24:35.792
517	51	2026-02-27 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-02-27 11:24:36.702
518	52	2026-02-27 00:00:00	14	41	57.3km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-02-27 11:24:37.156
519	53	2026-02-27 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-02-27 11:24:37.61
523	57	2026-02-27 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-02-27 11:24:39.427
372	58	2026-02-25 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-02-26 11:32:37.148
525	59	2026-02-27 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-02-27 11:24:40.336
526	60	2026-02-27 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-02-27 11:24:40.791
528	62	2026-02-27 00:00:00	21	24	117.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-02-27 11:24:41.7
530	64	2026-02-27 00:00:00	20	21	75.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-02-27 11:24:42.609
535	69	2026-02-27 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-02-27 11:24:44.882
536	70	2026-02-27 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-02-27 11:24:45.337
537	71	2026-02-27 00:00:00	14	28	43.3km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-02-27 11:24:45.792
538	72	2026-02-27 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-02-27 11:24:46.246
543	77	2026-02-27 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-27 11:24:48.518
545	79	2026-02-27 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-02-27 11:24:49.426
551	85	2026-02-27 00:00:00	52	62	241km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-02-27 11:24:52.15
553	87	2026-02-27 00:00:00	18	47	148km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-02-27 11:24:53.056
554	88	2026-02-27 00:00:00	9	13	34.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-02-27 11:24:53.51
555	89	2026-02-27 00:00:00	5	5	16km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-02-27 11:24:53.965
558	92	2026-02-27 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-02-27 11:24:55.326
559	93	2026-02-27 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-02-27 11:24:55.779
561	95	2026-02-27 00:00:00	9	16	31km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-02-27 11:24:56.687
562	96	2026-02-27 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-02-27 11:24:57.142
563	97	2026-02-27 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-02-27 11:24:57.596
566	100	2026-02-26 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-02-27 11:24:58.96
568	102	2026-02-27 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-02-27 11:24:59.867
8826	19	2026-03-20 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-20 00:00:00
7183	38	2026-03-09 00:00:00	21	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-09 00:00:00
626	7	2026-02-28 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-02-28 21:00:13.999
628	9	2026-02-28 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-02-28 21:00:14.755
581	28	2026-02-27 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-27 11:25:05.766
514	48	2026-02-27 00:00:00	26	26	77.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-02-27 11:24:35.336
529	63	2026-02-27 00:00:00	17	33	94.1km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-02-27 11:24:42.154
550	84	2026-02-27 00:00:00	6	9	21.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-27 11:24:51.696
548	82	2026-02-27 00:00:00	14	16	41.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-02-27 11:24:50.789
614	105	2026-02-27 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-02-27 11:25:20.754
600	136	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-02-27 11:25:14.402
624	5	2026-02-28 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-02-28 21:00:13.236
497	32	2026-02-27 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-27 11:24:27.609
627	8	2026-02-28 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-02-28 21:00:14.377
542	76	2026-02-27 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-27 11:24:48.064
630	11	2026-02-28 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-02-28 21:00:15.509
631	12	2026-02-28 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-02-28 21:00:15.892
8827	20	2026-03-20 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-20 00:00:00
636	18	2026-02-28 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-02-28 21:00:17.779
639	21	2026-02-28 00:00:00	22	27	180.5km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-02-28 21:00:18.914
640	153	2026-02-28 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-02-28 21:00:19.291
642	24	2026-02-28 00:00:00	2	8	6.5km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-02-28 21:00:20.049
644	26	2026-02-28 00:00:00	7	14	29km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-02-28 21:00:20.803
645	27	2026-02-28 00:00:00	8	13	34km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-02-28 21:00:21.181
651	34	2026-02-28 00:00:00	18	20	109.7km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-02-28 21:00:23.453
653	36	2026-02-28 00:00:00	11	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-02-28 21:00:24.209
654	37	2026-02-28 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-02-28 21:00:24.585
655	38	2026-02-28 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-02-28 21:00:24.963
656	40	2026-02-28 00:00:00	13	19	30.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-02-28 21:00:25.344
661	45	2026-02-28 00:00:00	35	59	124.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-02-28 21:00:27.229
663	46	2026-02-28 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-02-28 21:00:27.992
666	49	2026-02-28 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-02-28 21:00:29.124
668	51	2026-02-28 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-02-28 21:00:29.878
669	52	2026-02-28 00:00:00	12	41	40.5km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-02-28 21:00:30.256
670	53	2026-02-28 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-02-28 21:00:30.633
674	57	2026-02-28 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-02-28 21:00:32.141
676	59	2026-02-28 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-02-28 21:00:32.896
677	60	2026-02-28 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-02-28 21:00:33.274
679	62	2026-02-28 00:00:00	17	24	117.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-02-28 21:00:34.028
686	69	2026-02-28 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-02-28 21:00:36.668
687	70	2026-02-28 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-02-28 21:00:37.044
688	71	2026-02-28 00:00:00	7	28	13.9km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-02-28 21:00:37.42
689	72	2026-02-28 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-02-28 21:00:37.797
695	78	2026-02-28 00:00:00	25	28	135.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-02-28 21:00:40.06
696	79	2026-02-28 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-02-28 21:00:40.436
702	85	2026-02-28 00:00:00	52	62	241km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-02-28 21:00:42.701
704	87	2026-02-28 00:00:00	16	47	130.1km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-02-28 21:00:43.455
705	88	2026-02-28 00:00:00	7	13	31.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-02-28 21:00:43.832
706	89	2026-02-28 00:00:00	4	5	11km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-02-28 21:00:44.209
709	92	2026-02-28 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-02-28 21:00:45.341
710	93	2026-02-28 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-02-28 21:00:45.722
712	95	2026-02-28 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-02-28 21:00:46.475
713	96	2026-02-28 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-02-28 21:00:46.853
714	97	2026-02-28 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-02-28 21:00:47.23
719	102	2026-02-28 00:00:00	8	15	20.7km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-02-28 21:00:49.117
495	30	2026-02-27 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-02-27 11:24:26.699
650	33	2026-02-28 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-02-28 21:00:23.072
675	58	2026-02-28 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-02-28 21:00:32.518
662	131	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-02-28 21:00:27.606
690	73	2026-02-28 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-02-28 21:00:38.174
681	64	2026-02-28 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-02-28 21:00:34.783
717	100	2026-02-27 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-02-28 21:00:48.364
694	77	2026-02-28 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-28 21:00:39.682
708	91	2026-02-27 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-02-28 21:00:44.963
720	103	2026-02-28 00:00:00	19	64	49.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-02-28 21:00:49.494
646	29	2026-02-27 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-28 21:00:21.559
7184	39	2026-03-09 00:00:00	35	74	209.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-09 00:00:00
744	39	2026-02-28 00:00:00	67	74	322.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-02-28 21:00:58.551
774	2	2026-03-01 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-01 20:48:14.493
778	7	2026-03-01 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-01 20:48:15.551
780	9	2026-03-01 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-01 20:48:16.078
782	11	2026-03-01 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-01 20:48:16.604
783	12	2026-03-01 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-01 20:48:16.867
788	18	2026-03-01 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-01 20:48:18.177
792	153	2026-03-01 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-01 20:48:19.225
795	26	2026-03-01 00:00:00	7	14	29km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-01 20:48:20.011
796	27	2026-03-01 00:00:00	7	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-01 20:48:20.272
804	36	2026-03-01 00:00:00	11	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-01 20:48:22.367
805	37	2026-03-01 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-01 20:48:22.629
812	45	2026-03-01 00:00:00	34	59	110.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-01 20:48:24.469
816	48	2026-03-01 00:00:00	26	26	77.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-01 20:48:25.523
817	49	2026-03-01 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-01 20:48:25.786
819	51	2026-03-01 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-01 20:48:26.313
820	52	2026-03-01 00:00:00	10	41	40.5km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-01 20:48:26.577
821	53	2026-03-01 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-01 20:48:26.84
825	57	2026-03-01 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-01 20:48:27.893
827	59	2026-03-01 00:00:00	28	31	215.1km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-01 20:48:28.421
828	60	2026-03-01 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-01 20:48:28.684
829	61	2026-03-01 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-01 20:48:28.947
830	62	2026-03-01 00:00:00	17	24	117.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-01 20:48:29.21
831	63	2026-03-01 00:00:00	13	33	88.2km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-01 20:48:29.473
835	67	2026-03-01 00:00:00	7	12	23.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-01 20:48:30.526
837	69	2026-03-01 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-01 20:48:31.052
838	70	2026-03-01 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-01 20:48:31.316
839	71	2026-03-01 00:00:00	10	28	27.1km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-01 20:48:31.579
846	78	2026-03-01 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-01 20:48:33.422
847	79	2026-03-01 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-01 20:48:33.685
850	82	2026-03-01 00:00:00	12	16	39.25km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-01 20:48:34.471
853	85	2026-03-01 00:00:00	52	62	241km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-01 20:48:35.264
855	87	2026-03-01 00:00:00	16	47	130.1km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-03-01 20:48:35.788
856	88	2026-03-01 00:00:00	7	13	31.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-01 20:48:36.051
857	89	2026-03-01 00:00:00	5	5	16km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-01 20:48:36.314
860	92	2026-03-01 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-01 20:48:37.101
861	93	2026-03-01 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-01 20:48:37.363
863	95	2026-03-01 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-01 20:48:37.887
864	96	2026-03-01 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-01 20:48:38.151
870	102	2026-03-01 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-01 20:48:39.727
791	21	2026-03-01 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-01 20:48:18.963
635	17	2026-02-28 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-02-28 21:00:17.402
807	40	2026-03-01 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-01 20:48:23.155
802	34	2026-03-01 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-01 20:48:21.842
806	38	2026-03-01 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-01 20:48:22.892
867	99	2026-03-01 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-01 20:48:38.938
814	46	2026-03-01 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-01 20:48:24.996
840	72	2026-03-01 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-01 20:48:31.842
865	97	2026-03-01 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-01 20:48:38.413
726	14	2026-02-27 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-28 21:00:51.758
721	104	2026-02-28 00:00:00	1	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-02-28 21:00:49.871
7185	155	2026-03-09 00:00:00	27	35	168.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-09 00:00:00
883	24	2026-03-01 00:00:00	2	8	6.5km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-01 20:48:43.142
897	39	2026-03-01 00:00:00	64	74	312.7km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-01 20:48:46.821
620	1	2026-02-28 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-02-28 21:00:11.695
929	4	2026-03-02 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-02 11:25:50.855
931	7	2026-03-02 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-02 11:25:51.78
935	11	2026-03-02 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-02 11:25:53.632
936	12	2026-03-02 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-02 11:25:54.092
941	18	2026-03-02 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-02 11:25:56.402
948	26	2026-03-02 00:00:00	7	14	29km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-02 11:25:59.628
949	27	2026-03-02 00:00:00	7	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-02 11:26:00.088
957	36	2026-03-02 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-02 11:26:03.77
958	37	2026-03-02 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-02 11:26:04.23
960	39	2026-03-02 00:00:00	64	74	312.7km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-02 11:26:05.149
967	131	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-02 11:26:08.371
970	48	2026-03-02 00:00:00	20	26	77.4km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-02 11:26:09.752
971	49	2026-03-02 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-02 11:26:10.213
973	51	2026-03-02 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-02 11:26:11.136
974	52	2026-03-02 00:00:00	9	41	40.5km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-02 11:26:11.597
975	53	2026-03-02 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-02 11:26:12.062
981	59	2026-03-02 00:00:00	28	31	215.1km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-02 11:26:14.825
982	60	2026-03-02 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-02 11:26:15.286
984	62	2026-03-02 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-02 11:26:16.206
985	63	2026-03-02 00:00:00	13	33	88.2km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-02 11:26:16.667
986	64	2026-03-02 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-02 11:26:17.127
991	69	2026-03-02 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-02 11:26:19.43
992	70	2026-03-02 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-02 11:26:19.89
993	71	2026-03-02 00:00:00	9	28	23.6km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-02 11:26:20.35
998	77	2026-03-02 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-02 11:26:22.649
1000	79	2026-03-02 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-02 11:26:23.57
1003	82	2026-03-02 00:00:00	12	16	39.25km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-02 11:26:24.977
1005	85	2026-03-02 00:00:00	52	62	241km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-02 11:26:25.9
1006	87	2026-03-02 00:00:00	16	47	130.1km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-03-02 11:26:26.361
1007	88	2026-03-02 00:00:00	7	13	31.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-02 11:26:26.821
1008	89	2026-03-02 00:00:00	5	5	16km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-02 11:26:27.282
1010	91	2026-03-02 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-02 11:26:28.202
1011	92	2026-03-02 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-02 11:26:28.662
1012	93	2026-03-02 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-02 11:26:29.122
1014	95	2026-03-02 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-02 11:26:30.041
1015	96	2026-03-02 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-02 11:26:30.501
927	2	2026-03-02 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-02 11:25:49.926
933	9	2026-03-02 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-02 11:25:52.705
966	45	2026-03-02 00:00:00	23	59	47.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-02 11:26:07.909
945	153	2026-03-02 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-02 11:25:58.246
999	78	2026-03-02 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-02 11:26:23.11
979	57	2026-03-02 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-02 11:26:13.903
983	61	2026-03-02 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-02 11:26:15.746
989	67	2026-03-02 00:00:00	8	12	24.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-02 11:26:18.508
934	10	2026-03-02 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-02 11:25:53.169
932	8	2026-03-02 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-02 11:25:52.241
8828	22	2026-03-20 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-20 00:00:00
1021	102	2026-03-02 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-02 11:26:33.265
1033	24	2026-03-02 00:00:00	4	8	14.4km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-02 11:26:38.787
1084	7	2026-03-03 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-03 11:23:58.513
1088	11	2026-03-03 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-03 11:23:59.936
1089	12	2026-03-03 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-03 11:24:00.292
1094	18	2026-03-03 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-03 11:24:02.07
942	19	2026-03-02 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-02 11:25:56.863
1100	24	2026-03-03 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-03 11:24:04.207
1102	26	2026-03-03 00:00:00	6	14	13km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-03 11:24:04.919
1104	29	2026-03-03 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-03 11:24:05.633
1112	37	2026-03-03 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-03 11:24:08.478
1113	38	2026-03-03 00:00:00	24	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-03 11:24:08.834
1114	39	2026-03-03 00:00:00	65	74	314.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-03 11:24:09.19
1116	41	2026-03-03 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-03 11:24:09.901
1121	131	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-03 11:24:11.68
1122	46	2026-03-02 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-03 11:24:12.035
1124	48	2026-03-03 00:00:00	20	26	77.4km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-03 11:24:12.745
1125	49	2026-03-03 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-03 11:24:13.1
1127	51	2026-03-03 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-03 11:24:13.81
1128	52	2026-03-03 00:00:00	9	41	40.5km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-03 11:24:14.167
1129	53	2026-03-03 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-03 11:24:14.522
1135	59	2026-03-03 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-03 11:24:16.654
1136	60	2026-03-03 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-03 11:24:17.01
1138	62	2026-03-03 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-03 11:24:17.724
1139	63	2026-03-03 00:00:00	13	33	88.2km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-03 11:24:18.079
1140	64	2026-03-03 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-03 11:24:18.434
1145	69	2026-03-03 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-03 11:24:20.202
1146	70	2026-03-03 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-03 11:24:20.558
1148	72	2026-03-03 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-03 11:24:21.272
1074	86	2026-03-02 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-02 11:26:57.65
875	6	2026-03-01 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-01 20:48:41.042
1065	104	2026-03-02 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-02 11:26:53.511
1103	27	2026-03-03 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-03 11:24:05.279
1083	5	2026-03-03 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-03 11:23:58.156
1079	1	2026-03-03 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-03 11:23:56.693
1082	4	2026-03-03 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-03 11:23:57.794
1093	17	2026-03-03 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-03 11:24:01.715
1111	36	2026-03-03 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-03 11:24:08.123
1101	25	2026-03-03 00:00:00	4	6	36.3km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-03 11:24:04.563
1108	33	2026-03-03 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-03 11:24:07.056
1105	30	2026-03-03 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-03 11:24:05.99
1118	43	2026-03-02 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-03 11:24:10.612
1109	34	2026-03-03 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-03 11:24:07.411
1069	75	2026-03-02 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-02 11:26:55.351
1117	42	2026-03-03 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-03 11:24:10.257
1072	84	2026-03-02 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-02 11:26:56.731
1134	58	2026-03-03 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-03 11:24:16.298
1144	68	2026-03-03 00:00:00	2	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-03 11:24:19.848
1147	71	2026-03-03 00:00:00	9	28	23.6km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-03 11:24:20.918
1056	136	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-02 11:26:49.371
7186	40	2026-03-09 00:00:00	12	19	32km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-09 00:00:00
1154	79	2026-03-03 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-03 11:24:23.401
1157	82	2026-03-03 00:00:00	12	16	39.25km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-03 11:24:24.462
1159	85	2026-03-03 00:00:00	52	62	241km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-03 11:24:25.172
1160	87	2026-03-03 00:00:00	11	47	112.9km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-03-03 11:24:25.528
1165	92	2026-03-03 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-03 11:24:27.297
1166	93	2026-03-03 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-03 11:24:27.652
1168	95	2026-03-03 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-03 11:24:28.361
1169	96	2026-03-03 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-03 11:24:28.715
1173	100	2026-03-02 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-03 11:24:30.133
1175	102	2026-03-03 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-03 11:24:30.845
1176	103	2026-03-02 00:00:00	20	64	49.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-03 11:24:31.199
1237	7	2026-03-04 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-04 11:22:13.42
1239	9	2026-03-04 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-04 11:22:14.313
1241	11	2026-03-04 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-04 11:22:15.198
1242	12	2026-03-04 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-04 11:22:15.64
1247	18	2026-03-04 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-04 11:22:17.846
1248	19	2026-03-04 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-04 11:22:18.287
1249	20	2026-03-04 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-04 11:22:18.727
1251	153	2026-03-04 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-04 11:22:19.608
1253	24	2026-03-04 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-04 11:22:20.495
1255	26	2026-03-04 00:00:00	6	14	13km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-04 11:22:21.378
1257	29	2026-03-04 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-04 11:22:22.259
1265	37	2026-03-04 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-04 11:22:25.785
1266	38	2026-03-04 00:00:00	24	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-04 11:22:26.226
1267	39	2026-03-04 00:00:00	63	74	310.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-04 11:22:26.666
1268	40	2026-03-04 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-04 11:22:27.106
1274	131	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-04 11:22:29.751
1275	46	2026-03-03 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-04 11:22:30.192
1277	48	2026-03-04 00:00:00	20	26	77.4km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-04 11:22:31.071
1278	49	2026-03-04 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-04 11:22:31.513
1279	51	2026-03-04 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-04 11:22:31.953
1280	52	2026-03-04 00:00:00	8	41	24.5km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-04 11:22:32.395
1281	53	2026-03-04 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-04 11:22:32.837
1285	57	2026-03-04 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-04 11:22:34.598
1287	59	2026-03-04 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-04 11:22:35.48
1288	60	2026-03-04 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-04 11:22:35.92
1290	62	2026-03-04 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-04 11:22:36.801
1291	63	2026-03-04 00:00:00	13	33	88.2km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-04 11:22:37.242
1292	64	2026-03-04 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-04 11:22:37.683
1295	67	2026-03-04 00:00:00	8	12	24.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-04 11:22:39.006
1162	89	2026-03-03 00:00:00	4	5	14km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-03 11:24:26.236
1269	41	2026-03-04 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-04 11:22:27.551
1170	97	2026-03-03 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-03 11:24:29.07
1250	21	2026-03-04 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-04 11:22:19.168
1282	54	2026-03-04 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-04 11:22:33.277
1161	88	2026-03-03 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-03 11:24:25.882
1164	91	2026-03-03 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-03 11:24:26.943
1020	101	2026-03-02 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-02 11:26:32.802
1289	61	2026-03-04 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-04 11:22:36.361
1207	134	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-03 11:24:42.179
1297	69	2026-03-04 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-04 11:22:39.888
1298	70	2026-03-04 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-04 11:22:40.331
1300	72	2026-03-04 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-04 11:22:41.211
1149	73	2026-03-03 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-03 11:24:21.625
1152	77	2026-03-03 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-03 11:24:22.694
1306	79	2026-03-04 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-04 11:22:43.86
1309	82	2026-03-04 00:00:00	15	16	58.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-04 11:22:45.18
1311	85	2026-03-04 00:00:00	40	62	188.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-04 11:22:46.064
1312	87	2026-03-04 00:00:00	11	47	112.9km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-03-04 11:22:46.506
1317	92	2026-03-04 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-04 11:22:48.707
1318	93	2026-03-04 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-04 11:22:49.147
1320	95	2026-03-04 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-04 11:22:50.029
7187	41	2026-03-09 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-09 00:00:00
1324	99	2026-03-04 00:00:00	7	9	45km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-04 11:22:51.934
7188	42	2026-03-09 00:00:00	20	22	47.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-09 00:00:00
1328	103	2026-03-03 00:00:00	20	64	49.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-04 11:22:53.697
1388	4	2026-03-05 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-05 11:25:44.71
1390	7	2026-03-05 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-05 11:25:45.515
1392	9	2026-03-05 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-05 11:25:46.318
1394	11	2026-03-05 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-05 11:25:47.121
1400	18	2026-03-05 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-05 11:25:49.53
1401	19	2026-03-05 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-05 11:25:49.931
1402	20	2026-03-05 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-05 11:25:50.335
1404	153	2026-03-05 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-05 11:25:51.139
1406	24	2026-03-05 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-05 11:25:51.942
1408	26	2026-03-05 00:00:00	6	14	13km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-05 11:25:52.746
1410	29	2026-03-05 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-05 11:25:53.548
1411	30	2026-03-05 00:00:00	10	13	35.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-05 11:25:53.948
1418	37	2026-03-05 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-05 11:25:56.755
1419	38	2026-03-05 00:00:00	24	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-05 11:25:57.157
1420	39	2026-03-05 00:00:00	60	74	301.6km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-05 11:25:57.557
1421	40	2026-03-05 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-05 11:25:57.958
1427	131	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-05 11:26:00.361
1428	46	2026-03-04 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-05 11:26:00.764
1431	49	2026-03-05 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-05 11:26:01.965
1434	53	2026-03-05 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-05 11:26:03.169
1438	57	2026-03-05 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-05 11:26:04.773
1440	59	2026-03-05 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-05 11:26:05.576
1441	60	2026-03-05 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-05 11:26:05.976
1407	25	2026-03-05 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-05 11:25:52.343
1423	42	2026-03-05 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-05 11:25:58.76
1385	1	2026-03-05 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-05 11:25:43.475
1395	12	2026-03-05 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-05 11:25:47.522
1359	50	2026-03-04 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-04 11:23:07.359
1415	34	2026-03-05 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-05 11:25:55.551
1432	51	2026-03-05 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-05 11:26:02.366
1426	45	2026-03-05 00:00:00	21	59	39km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-05 11:25:59.961
1430	48	2026-03-05 00:00:00	16	26	57.1km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-05 11:26:01.565
1433	52	2026-03-05 00:00:00	7	41	10.3km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-05 11:26:02.767
1439	58	2026-03-05 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-05 11:26:05.173
1327	102	2026-03-04 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-04 11:22:53.257
1443	62	2026-03-05 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-05 11:26:06.779
1444	63	2026-03-05 00:00:00	12	33	74.6km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-05 11:26:07.187
1445	64	2026-03-05 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-05 11:26:07.586
1448	67	2026-03-05 00:00:00	8	12	24.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-05 11:26:08.789
7189	44	2026-03-09 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-09 00:00:00
1450	70	2026-03-05 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-05 11:26:09.59
1453	73	2026-03-05 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-05 11:26:10.791
1457	78	2026-03-05 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-05 11:26:12.395
1458	79	2026-03-05 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-05 11:26:12.795
1464	85	2026-03-05 00:00:00	40	62	188.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-05 11:26:15.925
1465	87	2026-03-05 00:00:00	11	47	112.9km/272.9km	https://www.nordicfrance.fr/nordicfrance_station/station-du-plateau-de-retord/	2026-03-05 11:26:16.327
1470	92	2026-03-05 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-05 11:26:18.336
1471	93	2026-03-05 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-05 11:26:18.737
1473	95	2026-03-05 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-05 11:26:19.538
1477	99	2026-03-05 00:00:00	8	9	53km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-05 11:26:21.143
1325	100	2026-03-03 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-04 11:22:52.375
1481	103	2026-03-04 00:00:00	20	64	49.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-05 11:26:22.748
1543	5	2026-03-05 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-06 11:20:06.778
1544	7	2026-03-06 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-06 11:20:07.168
1545	8	2026-03-06 00:00:00	28	31	55.2km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-06 11:20:07.56
1546	9	2026-03-06 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-06 11:20:07.95
1553	17	2026-03-05 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-06 11:20:10.674
1554	18	2026-03-06 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-06 11:20:11.066
1556	20	2026-03-06 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-06 11:20:11.844
1560	24	2026-03-06 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-06 11:20:13.425
1562	26	2026-03-06 00:00:00	5	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-06 11:20:14.205
1568	33	2026-03-06 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-06 11:20:16.54
1572	37	2026-03-06 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-06 11:20:18.098
1573	38	2026-03-06 00:00:00	24	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-06 11:20:18.487
1574	39	2026-03-06 00:00:00	59	74	301.6km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-06 11:20:18.876
1576	40	2026-03-06 00:00:00	13	19	34.5km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-06 11:20:22.121
1582	131	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-06 11:20:24.452
1583	46	2026-03-05 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-06 11:20:24.841
1586	49	2026-03-06 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-06 11:20:26.007
1589	53	2026-03-06 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-06 11:20:27.173
1593	57	2026-03-06 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-06 11:20:28.729
1451	71	2026-03-05 00:00:00	8	28	19.4km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-05 11:26:09.99
1452	72	2026-03-05 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-05 11:26:10.391
1456	77	2026-03-05 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-05 11:26:11.994
1461	82	2026-03-05 00:00:00	15	16	58.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-05 11:26:13.995
1463	154	2026-03-05 00:00:00	19	24	118.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-05 11:26:15.526
1321	96	2026-03-04 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-04 11:22:50.612
1475	97	2026-03-05 00:00:00	7	12	13.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-05 11:26:20.34
1542	4	2026-03-06 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-06 11:20:06.379
1564	29	2026-03-06 00:00:00	9	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-06 11:20:14.985
1548	11	2026-03-06 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-06 11:20:08.729
1555	19	2026-03-06 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-06 11:20:11.455
1558	153	2026-03-06 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-06 11:20:12.629
1575	155	2026-03-06 00:00:00	30	35	179.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-06 11:20:21.733
1565	30	2026-03-06 00:00:00	10	13	35.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-06 11:20:15.374
1524	68	2026-03-05 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-05 11:26:39.985
1595	59	2026-03-06 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-06 11:20:29.507
1598	62	2026-03-06 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-06 11:20:30.682
1600	64	2026-03-06 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-06 11:20:31.461
1603	67	2026-03-06 00:00:00	7	12	21.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-06 11:20:32.629
1449	69	2026-03-05 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-05 11:26:09.189
1605	70	2026-03-06 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-06 11:20:33.411
1608	73	2026-03-06 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-06 11:20:34.577
1613	79	2026-03-06 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-06 11:20:36.522
1619	85	2026-03-06 00:00:00	40	62	188.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-06 11:20:38.857
1621	89	2026-03-06 00:00:00	4	5	14km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-06 11:20:39.639
1624	92	2026-03-06 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-06 11:20:40.807
1625	93	2026-03-06 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-06 11:20:41.195
1627	95	2026-03-06 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-06 11:20:41.974
1631	99	2026-03-06 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-06 11:20:43.53
1692	1	2026-03-06 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-07 11:11:19.564
1696	5	2026-03-06 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-07 11:11:20.633
1697	7	2026-03-07 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-07 11:11:20.897
1699	9	2026-03-07 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-07 11:11:21.42
1702	12	2026-03-07 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-07 11:11:22.197
1706	17	2026-03-06 00:00:00	15	15	78.5km/78.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-07 11:11:23.231
1707	18	2026-03-07 00:00:00	12	12	95km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-07 11:11:23.489
1709	20	2026-03-07 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-07 11:11:24.007
1713	24	2026-03-07 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-07 11:11:25.076
1715	26	2026-03-07 00:00:00	5	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-07 11:11:25.593
1721	34	2026-03-06 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-07 11:11:27.148
1723	36	2026-03-07 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-07 11:11:27.668
1724	37	2026-03-07 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-07 11:11:27.926
1725	38	2026-03-07 00:00:00	24	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-07 11:11:28.184
1726	39	2026-03-07 00:00:00	49	74	251.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-07 11:11:28.442
1728	40	2026-03-07 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-07 11:11:28.973
1734	131	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-07 11:11:30.523
1735	46	2026-03-06 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-07 11:11:30.783
1737	48	2026-03-07 00:00:00	12	26	42.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-07 11:11:31.299
1738	49	2026-03-07 00:00:00	13	15	69.4km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-07 11:11:31.557
1740	52	2026-03-07 00:00:00	6	41	3.2km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-07 11:11:32.074
1741	53	2026-03-07 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-07 11:11:32.332
1745	57	2026-03-07 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-07 11:11:33.369
1746	58	2026-03-06 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-07 11:11:33.627
1747	59	2026-03-07 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-07 11:11:33.886
1596	60	2026-03-06 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-06 11:20:29.9
1632	100	2026-03-05 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-06 11:20:43.92
1750	62	2026-03-07 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-07 11:11:34.66
1599	63	2026-03-06 00:00:00	12	33	74.6km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-06 11:20:31.072
1612	78	2026-03-06 00:00:00	25	28	136.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-06 11:20:36.133
1668	136	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-06 11:20:57.922
7190	45	2026-03-09 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-09 00:00:00
1694	3	2026-03-07 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-07 11:11:20.107
1698	8	2026-03-07 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-07 11:11:21.159
1731	43	2026-03-07 00:00:00	5	12	18.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-07 11:11:29.749
1733	45	2026-03-07 00:00:00	21	59	39km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-07 11:11:30.265
1597	61	2026-03-06 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-06 11:20:30.289
1752	64	2026-03-07 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-07 11:11:35.176
7191	46	2026-03-09 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-09 00:00:00
1756	69	2026-03-07 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-07 11:11:36.213
1757	70	2026-03-07 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-07 11:11:36.47
1759	72	2026-03-07 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-07 11:11:36.986
1760	73	2026-03-07 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-07 11:11:37.243
1765	79	2026-03-07 00:00:00	12	23	78km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-07 11:11:38.532
1768	82	2026-03-07 00:00:00	15	16	58.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-07 11:11:39.308
1771	85	2026-03-07 00:00:00	40	62	188.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-07 11:11:40.086
1773	89	2026-03-07 00:00:00	1	5	4km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-07 11:11:40.602
1776	92	2026-03-07 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-07 11:11:41.376
1777	93	2026-03-07 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-07 11:11:41.633
1779	95	2026-03-07 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-07 11:11:42.149
1780	96	2026-03-07 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-07 11:11:42.407
1781	97	2026-03-07 00:00:00	7	12	13.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-07 11:11:42.665
1786	102	2026-03-07 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-07 11:11:43.962
1845	1	2026-03-07 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-08 11:12:18.254
1849	5	2026-03-07 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-08 11:12:19.558
1859	17	2026-03-07 00:00:00	15	15	78.5km/78.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-08 11:12:22.734
1873	34	2026-03-07 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-08 11:12:27.169
1886	46	2026-03-07 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-08 11:12:31.278
1897	58	2026-03-07 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-08 11:12:34.757
1758	71	2026-03-07 00:00:00	7	28	14.9km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-07 11:11:36.728
1763	77	2026-03-07 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-07 11:11:38.017
1770	154	2026-03-07 00:00:00	19	24	118.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-07 11:11:39.828
1783	99	2026-03-07 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-07 11:11:43.183
1804	33	2026-03-07 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-07 11:11:48.606
1846	2	2026-03-08 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-08 11:12:18.596
1850	7	2026-03-08 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-08 11:12:19.876
1852	9	2026-03-08 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-08 11:12:20.512
1854	11	2026-03-08 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-08 11:12:21.148
1855	12	2026-03-08 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-08 11:12:21.467
1860	18	2026-03-08 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-08 11:12:23.05
1861	19	2026-03-08 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-08 11:12:23.367
1862	20	2026-03-08 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-08 11:12:23.683
1863	153	2026-03-08 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-08 11:12:24
1865	24	2026-03-08 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-08 11:12:24.634
1867	26	2026-03-08 00:00:00	5	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-08 11:12:25.268
1870	30	2026-03-08 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-08 11:12:26.218
1876	37	2026-03-08 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-08 11:12:28.117
1877	38	2026-03-08 00:00:00	21	42	58.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-08 11:12:28.433
1879	40	2026-03-08 00:00:00	12	19	32km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-08 11:12:29.064
1888	48	2026-03-08 00:00:00	12	26	42.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-08 11:12:31.91
1889	49	2026-03-08 00:00:00	14	14	62.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-08 11:12:32.226
1890	51	2026-03-08 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-08 11:12:32.542
1891	52	2026-03-08 00:00:00	1	41	2.7km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-08 11:12:32.859
1892	53	2026-03-08 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-08 11:12:33.175
1896	57	2026-03-08 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-08 11:12:34.441
1898	59	2026-03-08 00:00:00	27	31	210km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-08 11:12:35.075
1875	36	2026-03-08 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-08 11:12:27.8
1885	131	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-08 11:12:30.963
7192	47	2026-03-09 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-09 00:00:00
1755	67	2026-03-07 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-07 11:11:35.955
1998	1	2026-03-08 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-08 00:00:00
2000	3	2026-03-08 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-08 00:00:00
2001	4	2026-03-08 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-08 00:00:00
2002	5	2026-03-08 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-08 00:00:00
2004	8	2026-03-08 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-08 00:00:00
2006	10	2026-03-08 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-08 00:00:00
2009	13	2026-03-08 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-08 00:00:00
2010	15	2026-03-08 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-08 00:00:00
2011	16	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-08 00:00:00
2012	17	2026-03-08 00:00:00	15	15	78.5km/78.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-08 00:00:00
2017	22	2026-03-08 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-08 00:00:00
2019	25	2026-03-08 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-08 00:00:00
2021	27	2026-03-08 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-08 00:00:00
2022	29	2026-03-08 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-08 00:00:00
2024	31	2026-03-08 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-08 00:00:00
2025	32	2026-03-08 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-08 00:00:00
2026	34	2026-03-08 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-08 00:00:00
2027	35	2026-03-08 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-08 00:00:00
2030	155	2026-03-08 00:00:00	30	35	179.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-08 00:00:00
2032	41	2026-03-08 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-08 00:00:00
2033	42	2026-03-08 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-08 00:00:00
2034	44	2026-03-08 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-08 00:00:00
2035	45	2026-03-08 00:00:00	9	59	24km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-08 00:00:00
2036	46	2026-03-08 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-08 00:00:00
2037	47	2026-03-08 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-08 00:00:00
2043	54	2026-03-08 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-08 00:00:00
2044	55	2026-03-08 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-08 00:00:00
2045	56	2026-03-08 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-08 00:00:00
1902	63	2026-03-08 00:00:00	10	33	62.3km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-08 11:12:36.345
2048	58	2026-03-08 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-08 00:00:00
1899	60	2026-03-08 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-08 11:12:35.392
1903	64	2026-03-08 00:00:00	20	21	80.6km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-08 11:12:36.662
1907	69	2026-03-08 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-08 11:12:37.93
1908	70	2026-03-08 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-08 11:12:38.247
1910	72	2026-03-08 00:00:00	10	30	21.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-08 11:12:38.882
1911	73	2026-03-08 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-08 11:12:39.198
1915	78	2026-03-08 00:00:00	24	28	129.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-08 11:12:40.467
1916	79	2026-03-08 00:00:00	12	23	78km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-08 11:12:40.784
1919	82	2026-03-08 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-08 11:12:41.737
1922	85	2026-03-08 00:00:00	38	62	169.1km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-08 11:12:42.693
1924	89	2026-03-08 00:00:00	1	5	4km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-08 11:12:43.329
1927	92	2026-03-08 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-08 11:12:44.281
1928	93	2026-03-08 00:00:00	4	4	38km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-08 11:12:44.599
1930	95	2026-03-08 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-08 11:12:45.233
1931	96	2026-03-08 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-08 11:12:45.55
1932	97	2026-03-08 00:00:00	7	12	13.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-08 11:12:45.867
1937	102	2026-03-08 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-08 11:12:47.456
1945	21	2026-03-08 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-08 11:12:49.997
1963	39	2026-03-08 00:00:00	49	74	251.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-08 11:12:55.706
2051	61	2026-03-08 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-08 00:00:00
1901	62	2026-03-08 00:00:00	14	24	99.8km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-08 11:12:36.028
2054	65	2026-03-08 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-08 00:00:00
2055	66	2026-03-08 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-08 00:00:00
2056	67	2026-03-08 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-08 00:00:00
2059	71	2026-03-08 00:00:00	7	28	14.9km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-08 00:00:00
2062	74	2026-03-08 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-08 00:00:00
2063	76	2026-03-08 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-08 00:00:00
2064	77	2026-03-08 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-08 00:00:00
2067	80	2026-03-08 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-08 00:00:00
2068	81	2026-03-08 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-08 00:00:00
2070	83	2026-03-08 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-08 00:00:00
2071	154	2026-03-08 00:00:00	19	24	118.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-08 00:00:00
2073	88	2026-03-08 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-08 00:00:00
2075	90	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-08 00:00:00
2076	91	2026-03-08 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-08 00:00:00
2079	94	2026-03-08 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-08 00:00:00
2083	98	2026-03-08 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-08 00:00:00
2084	99	2026-03-08 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-08 00:00:00
2085	100	2026-03-08 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-08 00:00:00
2086	101	2026-03-08 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-08 00:00:00
2088	107	2026-03-08 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-08 00:00:00
2089	108	2026-03-08 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-08 00:00:00
2090	6	2026-03-08 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-08 00:00:00
2091	109	2026-03-08 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-08 00:00:00
2092	110	2026-03-08 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-08 00:00:00
2093	14	2026-03-08 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-08 00:00:00
2094	111	2026-03-08 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-08 00:00:00
2096	112	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-08 00:00:00
2097	23	2026-03-08 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-08 00:00:00
2098	113	2026-03-08 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-08 00:00:00
2099	114	2026-03-08 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-08 00:00:00
2100	115	2026-03-08 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-08 00:00:00
2101	116	2026-03-08 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-08 00:00:00
2102	28	2026-03-08 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-08 00:00:00
2103	117	2026-03-08 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-08 00:00:00
2104	118	2026-03-08 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-08 00:00:00
2105	119	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-08 00:00:00
2106	33	2026-03-08 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-08 00:00:00
2107	120	2026-03-08 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-08 00:00:00
2108	121	2026-03-08 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-08 00:00:00
2110	122	2026-03-08 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-08 00:00:00
2111	123	2026-03-08 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-08 00:00:00
2112	124	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-08 00:00:00
2113	125	2026-03-08 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-08 00:00:00
2115	126	2026-03-08 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-08 00:00:00
2116	127	2026-03-08 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-08 00:00:00
2117	128	2026-03-08 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-08 00:00:00
2118	43	2026-03-08 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-08 00:00:00
2119	129	2026-03-08 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-08 00:00:00
2120	130	2026-03-08 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-08 00:00:00
2122	132	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-08 00:00:00
2123	133	2026-03-08 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-08 00:00:00
2124	50	2026-03-08 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-08 00:00:00
2125	134	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-08 00:00:00
2126	135	2026-03-08 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-08 00:00:00
2127	136	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-08 00:00:00
2128	137	2026-03-08 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-08 00:00:00
2129	138	2026-03-08 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-08 00:00:00
2130	139	2026-03-08 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-08 00:00:00
2131	140	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-08 00:00:00
2132	141	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-08 00:00:00
2133	142	2026-03-08 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-08 00:00:00
2134	143	2026-03-08 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-08 00:00:00
2135	144	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-08 00:00:00
2136	68	2026-03-08 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-08 00:00:00
2137	104	2026-03-08 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-08 00:00:00
2138	145	2026-03-08 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-08 00:00:00
2139	146	2026-03-08 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-08 00:00:00
2140	147	2026-03-08 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-08 00:00:00
2141	75	2026-03-08 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-08 00:00:00
2142	148	2026-03-08 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-08 00:00:00
2143	105	2026-03-08 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-08 00:00:00
2144	84	2026-03-08 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-08 00:00:00
2145	149	2026-03-08 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-08 00:00:00
2146	86	2026-03-08 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-08 00:00:00
2147	150	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-08 00:00:00
2148	106	2026-03-08 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-08 00:00:00
2149	151	2026-03-08 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-08 00:00:00
2150	152	2026-03-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-08 00:00:00
2151	1	2026-02-26 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-02-26 00:00:00
2152	1	2026-02-27 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-02-27 00:00:00
2153	1	2026-03-01 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-01 00:00:00
2154	1	2026-03-02 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-02 00:00:00
2155	1	2026-03-04 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-04 00:00:00
2156	2	2026-02-24 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-24 00:00:00
2157	2	2026-02-25 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-25 00:00:00
2158	2	2026-02-26 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-26 00:00:00
2159	2	2026-02-27 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-27 00:00:00
2160	2	2026-02-28 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-02-28 00:00:00
2161	2	2026-03-03 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-03 00:00:00
2162	2	2026-03-04 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-04 00:00:00
2163	2	2026-03-05 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-05 00:00:00
2164	2	2026-03-06 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-06 00:00:00
2165	2	2026-03-07 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-07 00:00:00
2166	3	2026-02-25 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-02-25 00:00:00
2167	3	2026-02-26 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-02-26 00:00:00
2168	3	2026-02-27 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-02-27 00:00:00
2169	3	2026-02-28 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-02-28 00:00:00
2170	3	2026-03-01 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-01 00:00:00
2171	3	2026-03-02 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-02 00:00:00
2172	3	2026-03-03 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-03 00:00:00
2173	3	2026-03-04 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-04 00:00:00
2174	3	2026-03-05 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-05 00:00:00
2175	3	2026-03-06 00:00:00	26	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-06 00:00:00
2176	4	2026-02-21 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-21 00:00:00
2177	4	2026-02-22 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-22 00:00:00
2178	4	2026-02-23 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-23 00:00:00
2179	4	2026-02-24 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-24 00:00:00
2180	4	2026-02-25 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-25 00:00:00
2181	4	2026-02-26 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-26 00:00:00
2182	4	2026-02-27 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-27 00:00:00
2183	4	2026-02-28 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-02-28 00:00:00
2184	4	2026-03-01 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-01 00:00:00
2185	4	2026-03-04 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-04 00:00:00
2186	4	2026-03-07 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-07 00:00:00
2187	5	2026-02-26 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-02-26 00:00:00
2188	5	2026-02-27 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-02-27 00:00:00
2189	5	2026-03-01 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-01 00:00:00
2190	5	2026-03-02 00:00:00	16	17	80km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-02 00:00:00
2191	5	2026-03-04 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-04 00:00:00
2192	6	2026-02-23 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-23 00:00:00
2193	6	2026-02-24 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-24 00:00:00
2194	6	2026-02-25 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-25 00:00:00
2195	6	2026-02-27 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-27 00:00:00
2196	6	2026-02-28 00:00:00	2	6	6.8km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-02-28 00:00:00
2197	6	2026-03-02 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-02 00:00:00
2198	6	2026-03-03 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-03 00:00:00
2199	6	2026-03-04 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-04 00:00:00
2200	6	2026-03-05 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-05 00:00:00
2201	6	2026-03-06 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-06 00:00:00
2202	6	2026-03-07 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-07 00:00:00
2203	8	2026-02-25 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-02-25 00:00:00
2204	8	2026-02-26 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-02-26 00:00:00
2205	8	2026-02-27 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-02-27 00:00:00
2206	8	2026-03-01 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-01 00:00:00
2207	8	2026-03-03 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-03 00:00:00
2208	8	2026-03-04 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-04 00:00:00
2209	8	2026-03-05 00:00:00	31	31	73.4km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-05 00:00:00
2210	9	2026-03-03 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-03 00:00:00
2211	10	2026-02-22 00:00:00	9	9	32.1km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-22 00:00:00
2212	10	2026-02-23 00:00:00	9	9	32.1km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-23 00:00:00
2213	10	2026-02-24 00:00:00	9	9	32.1km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-24 00:00:00
2214	10	2026-02-27 00:00:00	5	9	15.8km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-27 00:00:00
2215	10	2026-02-28 00:00:00	5	9	15.8km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-02-28 00:00:00
2216	10	2026-03-01 00:00:00	5	9	15.8km/32.1km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-01 00:00:00
2217	10	2026-03-03 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-03 00:00:00
2218	10	2026-03-04 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-04 00:00:00
2219	10	2026-03-05 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-05 00:00:00
2220	10	2026-03-06 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-06 00:00:00
2221	10	2026-03-07 00:00:00	4	8	14.3km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-07 00:00:00
2222	11	2026-03-07 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-07 00:00:00
2223	12	2026-03-06 00:00:00	9	9	35.75km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-06 00:00:00
2224	13	2026-02-22 00:00:00	11	15	38.45km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-22 00:00:00
2225	13	2026-02-23 00:00:00	11	15	38.45km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-23 00:00:00
2226	13	2026-02-24 00:00:00	11	15	38.45km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-24 00:00:00
2227	13	2026-02-26 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-26 00:00:00
2228	13	2026-02-27 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-27 00:00:00
2229	13	2026-02-28 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-02-28 00:00:00
2230	13	2026-03-01 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-01 00:00:00
2231	13	2026-03-02 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-02 00:00:00
2232	13	2026-03-03 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-03 00:00:00
2233	13	2026-03-04 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-04 00:00:00
2234	13	2026-03-05 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-05 00:00:00
2235	13	2026-03-06 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-06 00:00:00
2236	13	2026-03-07 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-07 00:00:00
2237	14	2026-02-23 00:00:00	5	18	25.5km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-23 00:00:00
2238	14	2026-02-24 00:00:00	5	18	25.5km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-24 00:00:00
2239	14	2026-02-25 00:00:00	5	18	25.5km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-25 00:00:00
2240	14	2026-02-26 00:00:00	5	18	25.5km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-26 00:00:00
2241	14	2026-02-28 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-02-28 00:00:00
2242	14	2026-03-01 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-01 00:00:00
2243	14	2026-03-02 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-02 00:00:00
2244	14	2026-03-03 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-03 00:00:00
2245	14	2026-03-04 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-04 00:00:00
2246	14	2026-03-05 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-05 00:00:00
2247	14	2026-03-06 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-06 00:00:00
2248	14	2026-03-07 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-07 00:00:00
2249	15	2026-02-18 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-18 00:00:00
2250	15	2026-02-19 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-19 00:00:00
2251	15	2026-02-20 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-20 00:00:00
2252	15	2026-02-21 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-21 00:00:00
2253	15	2026-02-22 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-22 00:00:00
2254	15	2026-02-23 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-23 00:00:00
2255	15	2026-02-24 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-24 00:00:00
2256	15	2026-02-25 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-25 00:00:00
2257	15	2026-02-26 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-26 00:00:00
2258	15	2026-02-27 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-27 00:00:00
2259	15	2026-02-28 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-02-28 00:00:00
2260	15	2026-03-01 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-01 00:00:00
2261	15	2026-03-02 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-02 00:00:00
2262	15	2026-03-03 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-03 00:00:00
2263	15	2026-03-04 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-04 00:00:00
2264	15	2026-03-05 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-05 00:00:00
2265	15	2026-03-06 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-06 00:00:00
2266	15	2026-03-07 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-07 00:00:00
2267	16	2026-01-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-01-28 00:00:00
2268	16	2026-01-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-01-29 00:00:00
2269	16	2026-01-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-01-30 00:00:00
2270	16	2026-01-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-01-31 00:00:00
2271	16	2026-02-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-01 00:00:00
2272	16	2026-02-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-02 00:00:00
2273	16	2026-02-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-03 00:00:00
2274	16	2026-02-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-04 00:00:00
2275	16	2026-02-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-05 00:00:00
2276	16	2026-02-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-06 00:00:00
2277	16	2026-02-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-07 00:00:00
2278	16	2026-02-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-08 00:00:00
2279	16	2026-02-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-09 00:00:00
2280	16	2026-02-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-10 00:00:00
2281	16	2026-02-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-11 00:00:00
2282	16	2026-02-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-12 00:00:00
2283	16	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-13 00:00:00
2284	16	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-14 00:00:00
2285	16	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-15 00:00:00
2286	16	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-16 00:00:00
2287	16	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-17 00:00:00
2288	16	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-18 00:00:00
2289	16	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-19 00:00:00
2290	16	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-20 00:00:00
2291	16	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-21 00:00:00
2292	16	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-22 00:00:00
2293	16	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-23 00:00:00
2294	16	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-24 00:00:00
2295	16	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-25 00:00:00
2296	16	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-26 00:00:00
2297	16	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-27 00:00:00
2298	16	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-02-28 00:00:00
2299	16	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-01 00:00:00
2300	16	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-02 00:00:00
2301	16	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-03 00:00:00
2302	16	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-04 00:00:00
2303	16	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-05 00:00:00
2304	16	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-06 00:00:00
2305	16	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-07 00:00:00
2306	17	2026-02-26 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-02-26 00:00:00
2307	17	2026-02-27 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-02-27 00:00:00
2308	17	2026-03-01 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-01 00:00:00
2309	17	2026-03-02 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-02 00:00:00
2310	17	2026-03-04 00:00:00	15	15	73.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-04 00:00:00
2311	19	2026-02-25 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-02-25 00:00:00
2312	19	2026-02-27 00:00:00	11	16	24.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-02-27 00:00:00
2313	19	2026-02-28 00:00:00	11	16	24.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-02-28 00:00:00
2314	19	2026-03-01 00:00:00	11	16	24.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-01 00:00:00
2315	19	2026-03-03 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-03 00:00:00
2316	19	2026-03-07 00:00:00	13	16	39.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-07 00:00:00
2317	20	2026-02-25 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-02-25 00:00:00
2318	20	2026-02-28 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-02-28 00:00:00
2319	20	2026-03-01 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-01 00:00:00
2320	20	2026-03-02 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-02 00:00:00
2321	20	2026-03-03 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-03 00:00:00
2322	21	2026-03-02 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-02 00:00:00
2323	21	2026-03-03 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-03 00:00:00
2324	21	2026-03-05 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-05 00:00:00
2325	21	2026-03-06 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-06 00:00:00
2326	21	2026-03-07 00:00:00	5	27	45km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-07 00:00:00
2327	22	2026-01-22 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-22 00:00:00
2328	22	2026-01-23 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-23 00:00:00
2329	22	2026-01-24 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-24 00:00:00
2330	22	2026-01-25 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-25 00:00:00
2331	22	2026-01-26 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-26 00:00:00
2332	22	2026-01-27 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-27 00:00:00
2333	22	2026-01-28 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-28 00:00:00
2334	22	2026-01-29 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-29 00:00:00
2335	22	2026-01-30 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-30 00:00:00
2336	22	2026-01-31 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-01-31 00:00:00
2337	22	2026-02-01 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-01 00:00:00
2338	22	2026-02-02 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-02 00:00:00
2339	22	2026-02-03 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-03 00:00:00
2340	22	2026-02-04 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-04 00:00:00
2341	22	2026-02-05 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-05 00:00:00
2342	22	2026-02-06 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-06 00:00:00
2343	22	2026-02-07 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-07 00:00:00
2344	22	2026-02-08 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-08 00:00:00
2345	22	2026-02-09 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-09 00:00:00
2346	22	2026-02-10 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-10 00:00:00
2347	22	2026-02-11 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-11 00:00:00
2348	22	2026-02-12 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-12 00:00:00
2349	22	2026-02-13 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-13 00:00:00
2350	22	2026-02-14 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-14 00:00:00
2351	22	2026-02-15 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-15 00:00:00
2352	22	2026-02-16 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-16 00:00:00
2353	22	2026-02-17 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-17 00:00:00
2354	22	2026-02-18 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-18 00:00:00
2355	22	2026-02-19 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-19 00:00:00
2356	22	2026-02-20 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-20 00:00:00
2357	22	2026-02-21 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-21 00:00:00
2358	22	2026-02-22 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-22 00:00:00
2359	22	2026-02-23 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-23 00:00:00
2360	22	2026-02-24 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-24 00:00:00
2361	22	2026-02-25 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-25 00:00:00
2362	22	2026-02-26 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-26 00:00:00
2363	22	2026-02-27 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-27 00:00:00
2364	22	2026-02-28 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-02-28 00:00:00
2365	22	2026-03-01 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-01 00:00:00
2366	22	2026-03-02 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-02 00:00:00
2367	22	2026-03-03 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-03 00:00:00
2368	22	2026-03-04 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-04 00:00:00
2369	22	2026-03-05 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-05 00:00:00
2370	22	2026-03-06 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-06 00:00:00
2371	22	2026-03-07 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-07 00:00:00
2372	23	2026-02-25 00:00:00	3	11	30km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-02-25 00:00:00
2373	23	2026-02-27 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-02-27 00:00:00
2374	23	2026-02-28 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-02-28 00:00:00
2375	23	2026-03-01 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-01 00:00:00
2376	23	2026-03-02 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-02 00:00:00
2377	23	2026-03-03 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-03 00:00:00
2378	23	2026-03-04 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-04 00:00:00
2379	23	2026-03-05 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-05 00:00:00
2380	23	2026-03-06 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-06 00:00:00
2381	23	2026-03-07 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-07 00:00:00
2382	25	2026-02-27 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-02-27 00:00:00
2383	25	2026-02-28 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-02-28 00:00:00
2384	25	2026-03-01 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-01 00:00:00
2385	25	2026-03-02 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-02 00:00:00
2386	25	2026-03-04 00:00:00	4	6	36.3km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-04 00:00:00
2387	25	2026-03-06 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-06 00:00:00
2388	25	2026-03-07 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-07 00:00:00
2389	27	2026-02-25 00:00:00	13	13	57.4km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-02-25 00:00:00
2390	27	2026-03-04 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-04 00:00:00
2391	27	2026-03-05 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-05 00:00:00
2392	27	2026-03-06 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-06 00:00:00
2393	27	2026-03-07 00:00:00	6	13	27km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-07 00:00:00
2394	28	2026-02-21 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-21 00:00:00
2395	28	2026-02-22 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-22 00:00:00
2396	28	2026-02-23 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-23 00:00:00
2397	28	2026-02-24 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-24 00:00:00
2398	28	2026-02-25 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-25 00:00:00
2399	28	2026-02-26 00:00:00	12	19	73.4km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-26 00:00:00
2400	28	2026-02-28 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-02-28 00:00:00
2401	28	2026-03-01 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-01 00:00:00
2402	28	2026-03-02 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-02 00:00:00
2403	28	2026-03-03 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-03 00:00:00
2404	28	2026-03-04 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-04 00:00:00
2405	28	2026-03-05 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-05 00:00:00
2406	28	2026-03-06 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-06 00:00:00
2407	28	2026-03-07 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-07 00:00:00
2408	29	2026-02-24 00:00:00	13	13	67.8km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-24 00:00:00
2409	29	2026-02-25 00:00:00	13	13	67.8km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-25 00:00:00
2410	29	2026-02-28 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-02-28 00:00:00
2411	29	2026-03-01 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-01 00:00:00
2412	29	2026-03-02 00:00:00	12	13	58.7km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-02 00:00:00
2413	29	2026-03-07 00:00:00	9	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-07 00:00:00
2414	30	2026-02-25 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-02-25 00:00:00
2415	30	2026-02-26 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-02-26 00:00:00
2416	30	2026-02-28 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-02-28 00:00:00
2417	30	2026-03-01 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-01 00:00:00
2418	30	2026-03-02 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-02 00:00:00
2419	30	2026-03-04 00:00:00	9	13	28.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-04 00:00:00
2420	30	2026-03-07 00:00:00	10	13	35.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-07 00:00:00
2421	31	2026-01-14 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-14 00:00:00
2422	31	2026-01-15 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-15 00:00:00
2423	31	2026-01-16 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-16 00:00:00
2424	31	2026-01-17 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-17 00:00:00
2425	31	2026-01-18 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-18 00:00:00
2426	31	2026-01-19 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-19 00:00:00
2427	31	2026-01-20 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-20 00:00:00
2428	31	2026-01-21 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-21 00:00:00
2429	31	2026-01-22 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-22 00:00:00
2430	31	2026-01-23 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-23 00:00:00
2431	31	2026-01-24 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-24 00:00:00
2432	31	2026-01-25 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-25 00:00:00
2433	31	2026-01-26 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-26 00:00:00
2434	31	2026-01-27 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-27 00:00:00
2435	31	2026-01-28 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-28 00:00:00
2436	31	2026-01-29 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-29 00:00:00
2437	31	2026-01-30 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-30 00:00:00
2438	31	2026-01-31 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-01-31 00:00:00
2439	31	2026-02-01 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-01 00:00:00
2440	31	2026-02-02 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-02 00:00:00
2441	31	2026-02-03 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-03 00:00:00
2442	31	2026-02-04 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-04 00:00:00
2443	31	2026-02-05 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-05 00:00:00
2444	31	2026-02-06 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-06 00:00:00
2445	31	2026-02-07 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-07 00:00:00
2446	31	2026-02-08 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-08 00:00:00
2447	31	2026-02-09 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-09 00:00:00
2448	31	2026-02-10 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-10 00:00:00
2449	31	2026-02-11 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-11 00:00:00
2450	31	2026-02-12 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-12 00:00:00
2451	31	2026-02-13 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-13 00:00:00
2452	31	2026-02-14 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-14 00:00:00
2453	31	2026-02-15 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-15 00:00:00
2454	31	2026-02-16 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-16 00:00:00
2455	31	2026-02-17 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-17 00:00:00
2456	31	2026-02-18 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-18 00:00:00
2457	31	2026-02-19 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-19 00:00:00
2458	31	2026-02-20 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-20 00:00:00
2459	31	2026-02-21 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-21 00:00:00
2460	31	2026-02-22 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-22 00:00:00
2461	31	2026-02-23 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-23 00:00:00
2462	31	2026-02-24 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-24 00:00:00
2463	31	2026-02-25 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-25 00:00:00
2464	31	2026-02-26 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-26 00:00:00
2465	31	2026-02-27 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-27 00:00:00
2466	31	2026-02-28 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-02-28 00:00:00
2467	31	2026-03-01 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-01 00:00:00
2468	31	2026-03-02 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-02 00:00:00
2469	31	2026-03-03 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-03 00:00:00
2470	31	2026-03-04 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-04 00:00:00
2471	31	2026-03-05 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-05 00:00:00
2472	31	2026-03-06 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-06 00:00:00
2473	31	2026-03-07 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-07 00:00:00
2474	32	2026-02-11 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-11 00:00:00
2475	32	2026-02-12 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-12 00:00:00
2476	32	2026-02-13 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-13 00:00:00
2477	32	2026-02-14 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-14 00:00:00
2478	32	2026-02-15 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-15 00:00:00
2479	32	2026-02-16 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-16 00:00:00
2480	32	2026-02-17 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-17 00:00:00
2481	32	2026-02-18 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-18 00:00:00
2482	32	2026-02-19 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-19 00:00:00
2483	32	2026-02-20 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-20 00:00:00
2484	32	2026-02-21 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-21 00:00:00
2485	32	2026-02-22 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-22 00:00:00
2486	32	2026-02-23 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-23 00:00:00
2487	32	2026-02-24 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-24 00:00:00
2488	32	2026-02-25 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-25 00:00:00
2489	32	2026-02-26 00:00:00	40	46	78.1km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-26 00:00:00
2490	32	2026-02-28 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-02-28 00:00:00
2491	32	2026-03-01 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-01 00:00:00
2492	32	2026-03-02 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-02 00:00:00
2493	32	2026-03-03 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-03 00:00:00
2494	32	2026-03-04 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-04 00:00:00
2495	32	2026-03-05 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-05 00:00:00
2496	32	2026-03-06 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-06 00:00:00
2497	32	2026-03-07 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-07 00:00:00
2498	33	2026-02-26 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-02-26 00:00:00
2499	33	2026-02-27 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-02-27 00:00:00
2500	33	2026-03-01 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-01 00:00:00
2501	33	2026-03-02 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-02 00:00:00
2502	33	2026-03-04 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-04 00:00:00
2503	33	2026-03-05 00:00:00	3	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-05 00:00:00
2504	34	2026-02-25 00:00:00	19	20	123.4km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-02-25 00:00:00
2505	34	2026-02-27 00:00:00	18	20	109.7km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-02-27 00:00:00
2506	34	2026-03-02 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-02 00:00:00
2507	34	2026-03-04 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-04 00:00:00
2508	35	2026-01-29 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-01-29 00:00:00
2509	35	2026-01-30 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-01-30 00:00:00
2510	35	2026-01-31 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-01-31 00:00:00
2511	35	2026-02-01 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-01 00:00:00
2512	35	2026-02-02 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-02 00:00:00
2513	35	2026-02-03 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-03 00:00:00
2514	35	2026-02-04 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-04 00:00:00
2515	35	2026-02-05 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-05 00:00:00
2516	35	2026-02-06 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-06 00:00:00
2517	35	2026-02-07 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-07 00:00:00
2518	35	2026-02-08 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-08 00:00:00
2519	35	2026-02-09 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-09 00:00:00
2520	35	2026-02-10 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-10 00:00:00
2521	35	2026-02-11 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-11 00:00:00
2522	35	2026-02-12 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-12 00:00:00
2523	35	2026-02-13 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-13 00:00:00
2524	35	2026-02-14 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-14 00:00:00
2525	35	2026-02-15 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-15 00:00:00
2526	35	2026-02-16 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-16 00:00:00
2527	35	2026-02-17 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-17 00:00:00
2528	35	2026-02-18 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-18 00:00:00
2529	35	2026-02-19 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-19 00:00:00
2530	35	2026-02-20 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-20 00:00:00
2531	35	2026-02-21 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-21 00:00:00
2532	35	2026-02-22 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-22 00:00:00
2533	35	2026-02-23 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-23 00:00:00
2534	35	2026-02-24 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-24 00:00:00
2535	35	2026-02-25 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-25 00:00:00
2536	35	2026-02-26 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-26 00:00:00
2537	35	2026-02-27 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-27 00:00:00
2538	35	2026-02-28 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-02-28 00:00:00
2539	35	2026-03-01 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-01 00:00:00
2540	35	2026-03-02 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-02 00:00:00
2541	35	2026-03-03 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-03 00:00:00
2542	35	2026-03-04 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-04 00:00:00
2543	35	2026-03-05 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-05 00:00:00
2544	35	2026-03-06 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-06 00:00:00
2545	35	2026-03-07 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-07 00:00:00
2546	36	2026-02-25 00:00:00	12	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-02-25 00:00:00
2547	36	2026-02-27 00:00:00	11	19	83.4km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-02-27 00:00:00
2548	36	2026-03-04 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-04 00:00:00
2549	36	2026-03-05 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-05 00:00:00
2550	36	2026-03-06 00:00:00	10	19	74.5km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-06 00:00:00
2551	38	2026-03-02 00:00:00	23	42	57.1km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-02 00:00:00
2552	40	2026-03-02 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-02 00:00:00
2553	40	2026-03-03 00:00:00	14	19	35.2km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-03 00:00:00
2554	41	2026-02-24 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-24 00:00:00
2555	41	2026-02-25 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-25 00:00:00
2556	41	2026-02-26 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-26 00:00:00
2557	41	2026-02-27 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-27 00:00:00
2558	41	2026-02-28 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-02-28 00:00:00
2559	41	2026-03-01 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-01 00:00:00
2560	41	2026-03-02 00:00:00	8	9	20km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-02 00:00:00
2561	41	2026-03-05 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-05 00:00:00
2562	41	2026-03-06 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-06 00:00:00
2563	41	2026-03-07 00:00:00	3	9	0.8km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-07 00:00:00
2564	42	2026-02-26 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-02-26 00:00:00
2565	42	2026-02-27 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-02-27 00:00:00
2566	42	2026-02-28 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-02-28 00:00:00
2567	42	2026-03-01 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-01 00:00:00
2568	42	2026-03-02 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-02 00:00:00
2569	42	2026-03-04 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-04 00:00:00
2570	42	2026-03-06 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-06 00:00:00
2571	42	2026-03-07 00:00:00	22	22	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-07 00:00:00
2572	43	2026-02-26 00:00:00	12	12	97.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-02-26 00:00:00
2573	43	2026-02-27 00:00:00	12	12	97.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-02-27 00:00:00
2574	43	2026-02-28 00:00:00	12	12	97.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-02-28 00:00:00
2575	43	2026-03-01 00:00:00	12	12	97.3km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-01 00:00:00
2576	43	2026-03-03 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-03 00:00:00
2577	43	2026-03-04 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-04 00:00:00
2578	43	2026-03-05 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-05 00:00:00
2579	43	2026-03-06 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-06 00:00:00
2580	44	2026-01-28 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-01-28 00:00:00
2581	44	2026-01-29 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-01-29 00:00:00
2582	44	2026-01-30 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-01-30 00:00:00
2583	44	2026-01-31 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-01-31 00:00:00
2584	44	2026-02-01 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-01 00:00:00
2585	44	2026-02-02 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-02 00:00:00
2586	44	2026-02-03 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-03 00:00:00
2587	44	2026-02-04 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-04 00:00:00
2588	44	2026-02-05 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-05 00:00:00
2589	44	2026-02-06 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-06 00:00:00
2590	44	2026-02-07 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-07 00:00:00
2591	44	2026-02-08 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-08 00:00:00
2592	44	2026-02-09 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-09 00:00:00
2593	44	2026-02-10 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-10 00:00:00
2594	44	2026-02-11 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-11 00:00:00
2595	44	2026-02-12 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-12 00:00:00
2596	44	2026-02-13 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-13 00:00:00
2597	44	2026-02-14 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-14 00:00:00
2598	44	2026-02-15 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-15 00:00:00
2599	44	2026-02-16 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-16 00:00:00
2600	44	2026-02-17 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-17 00:00:00
2601	44	2026-02-18 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-18 00:00:00
2602	44	2026-02-19 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-19 00:00:00
2603	44	2026-02-20 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-20 00:00:00
2604	44	2026-02-21 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-21 00:00:00
2605	44	2026-02-22 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-22 00:00:00
2606	44	2026-02-23 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-23 00:00:00
2607	44	2026-02-24 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-24 00:00:00
2608	44	2026-02-25 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-25 00:00:00
2609	44	2026-02-26 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-26 00:00:00
2610	44	2026-02-27 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-27 00:00:00
2611	44	2026-02-28 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-02-28 00:00:00
2612	44	2026-03-01 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-01 00:00:00
2613	44	2026-03-02 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-02 00:00:00
2614	44	2026-03-03 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-03 00:00:00
2615	44	2026-03-04 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-04 00:00:00
2616	44	2026-03-05 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-05 00:00:00
2617	44	2026-03-06 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-06 00:00:00
2618	44	2026-03-07 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-07 00:00:00
2619	45	2026-03-03 00:00:00	23	59	47.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-03 00:00:00
2620	45	2026-03-04 00:00:00	23	59	47.5km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-04 00:00:00
2621	45	2026-03-06 00:00:00	21	59	39km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-06 00:00:00
2622	46	2026-02-27 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-02-27 00:00:00
2623	47	2026-01-28 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-01-28 00:00:00
2624	47	2026-01-29 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-01-29 00:00:00
2625	47	2026-01-30 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-01-30 00:00:00
2626	47	2026-01-31 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-01-31 00:00:00
2627	47	2026-02-01 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-01 00:00:00
2628	47	2026-02-02 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-02 00:00:00
2629	47	2026-02-03 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-03 00:00:00
2630	47	2026-02-04 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-04 00:00:00
2631	47	2026-02-05 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-05 00:00:00
2632	47	2026-02-06 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-06 00:00:00
2633	47	2026-02-07 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-07 00:00:00
2634	47	2026-02-08 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-08 00:00:00
2635	47	2026-02-09 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-09 00:00:00
2636	47	2026-02-10 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-10 00:00:00
2637	47	2026-02-11 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-11 00:00:00
2638	47	2026-02-12 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-12 00:00:00
2639	47	2026-02-13 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-13 00:00:00
2640	47	2026-02-14 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-14 00:00:00
2641	47	2026-02-15 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-15 00:00:00
2642	47	2026-02-16 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-16 00:00:00
2643	47	2026-02-17 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-17 00:00:00
2644	47	2026-02-18 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-18 00:00:00
2645	47	2026-02-19 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-19 00:00:00
2646	47	2026-02-20 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-20 00:00:00
2647	47	2026-02-21 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-21 00:00:00
2648	47	2026-02-22 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-22 00:00:00
2649	47	2026-02-23 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-23 00:00:00
2650	47	2026-02-24 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-24 00:00:00
2651	47	2026-02-25 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-25 00:00:00
2652	47	2026-02-26 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-26 00:00:00
2653	47	2026-02-27 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-27 00:00:00
2654	47	2026-02-28 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-02-28 00:00:00
2655	47	2026-03-01 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-01 00:00:00
2656	47	2026-03-02 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-02 00:00:00
2657	47	2026-03-03 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-03 00:00:00
2658	47	2026-03-04 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-04 00:00:00
2659	47	2026-03-05 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-05 00:00:00
2660	47	2026-03-06 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-06 00:00:00
2661	47	2026-03-07 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-07 00:00:00
2662	48	2026-02-28 00:00:00	26	26	77.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-02-28 00:00:00
2663	48	2026-03-06 00:00:00	16	26	57.1km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-06 00:00:00
2664	49	2026-02-25 00:00:00	15	15	70.5km/70.5km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-02-25 00:00:00
2665	50	2026-02-22 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-22 00:00:00
2666	50	2026-02-23 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-23 00:00:00
2667	50	2026-02-24 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-24 00:00:00
2668	50	2026-02-25 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-25 00:00:00
2669	50	2026-02-26 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-26 00:00:00
2670	50	2026-02-27 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-27 00:00:00
2671	50	2026-02-28 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-02-28 00:00:00
2672	50	2026-03-01 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-01 00:00:00
2673	50	2026-03-02 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-02 00:00:00
2674	50	2026-03-03 00:00:00	9	10	56km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-03 00:00:00
2675	50	2026-03-05 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-05 00:00:00
2676	50	2026-03-06 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-06 00:00:00
2677	50	2026-03-07 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-07 00:00:00
2678	51	2026-03-06 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-06 00:00:00
2679	51	2026-03-07 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-07 00:00:00
2680	52	2026-03-06 00:00:00	7	41	10.3km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-06 00:00:00
2681	54	2026-02-18 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-18 00:00:00
2682	54	2026-02-19 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-19 00:00:00
2683	54	2026-02-20 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-20 00:00:00
2684	54	2026-02-21 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-21 00:00:00
2685	54	2026-02-22 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-22 00:00:00
2686	54	2026-02-23 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-23 00:00:00
2687	54	2026-02-24 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-24 00:00:00
2688	54	2026-02-25 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-25 00:00:00
2689	54	2026-02-26 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-26 00:00:00
2690	54	2026-02-27 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-27 00:00:00
2691	54	2026-02-28 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-02-28 00:00:00
2692	54	2026-03-01 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-01 00:00:00
2693	54	2026-03-02 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-02 00:00:00
2694	54	2026-03-03 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-03 00:00:00
2695	54	2026-03-05 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-05 00:00:00
2696	54	2026-03-06 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-06 00:00:00
2697	54	2026-03-07 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-07 00:00:00
2698	55	2026-02-08 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-08 00:00:00
2699	55	2026-02-09 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-09 00:00:00
2700	55	2026-02-10 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-10 00:00:00
2701	55	2026-02-11 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-11 00:00:00
2702	55	2026-02-12 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-12 00:00:00
2703	55	2026-02-13 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-13 00:00:00
2704	55	2026-02-14 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-14 00:00:00
2705	55	2026-02-15 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-15 00:00:00
2706	55	2026-02-16 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-16 00:00:00
2707	55	2026-02-17 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-17 00:00:00
2708	55	2026-02-18 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-18 00:00:00
2709	55	2026-02-19 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-19 00:00:00
2710	55	2026-02-20 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-20 00:00:00
2711	55	2026-02-21 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-21 00:00:00
2712	55	2026-02-22 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-22 00:00:00
2713	55	2026-02-23 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-23 00:00:00
2714	55	2026-02-24 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-24 00:00:00
2715	55	2026-02-25 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-25 00:00:00
2716	55	2026-02-26 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-26 00:00:00
2717	55	2026-02-27 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-27 00:00:00
2718	55	2026-02-28 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-02-28 00:00:00
2719	55	2026-03-01 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-01 00:00:00
2720	55	2026-03-02 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-02 00:00:00
2721	55	2026-03-03 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-03 00:00:00
2722	55	2026-03-04 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-04 00:00:00
2723	55	2026-03-05 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-05 00:00:00
2724	55	2026-03-06 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-06 00:00:00
2725	55	2026-03-07 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-07 00:00:00
2726	56	2026-02-22 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-22 00:00:00
2727	56	2026-02-23 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-23 00:00:00
2728	56	2026-02-24 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-24 00:00:00
2729	56	2026-02-25 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-25 00:00:00
2730	56	2026-02-26 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-26 00:00:00
2731	56	2026-02-27 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-27 00:00:00
2732	56	2026-02-28 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-02-28 00:00:00
2733	56	2026-03-01 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-01 00:00:00
2734	56	2026-03-02 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-02 00:00:00
2735	56	2026-03-03 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-03 00:00:00
2736	56	2026-03-04 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-04 00:00:00
2737	56	2026-03-05 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-05 00:00:00
2738	56	2026-03-06 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-06 00:00:00
2739	56	2026-03-07 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-07 00:00:00
2740	57	2026-03-03 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-03 00:00:00
2741	58	2026-02-26 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-02-26 00:00:00
2742	58	2026-02-27 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-02-27 00:00:00
2743	58	2026-03-01 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-01 00:00:00
2744	58	2026-03-02 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-02 00:00:00
2745	58	2026-03-04 00:00:00	17	17	101km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-04 00:00:00
2746	60	2026-03-07 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-07 00:00:00
2747	61	2026-02-25 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-02-25 00:00:00
2748	61	2026-02-27 00:00:00	7	7	20.8km/20.8km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-02-27 00:00:00
2749	61	2026-02-28 00:00:00	7	7	20.8km/20.8km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-02-28 00:00:00
2750	61	2026-03-03 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-03 00:00:00
2751	61	2026-03-05 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-05 00:00:00
2752	61	2026-03-07 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-07 00:00:00
2753	63	2026-02-28 00:00:00	17	33	94.1km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-02-28 00:00:00
2754	63	2026-03-07 00:00:00	12	33	74.6km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-07 00:00:00
2755	64	2026-03-01 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-01 00:00:00
2756	65	2026-02-25 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-02-25 00:00:00
2757	65	2026-02-26 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-02-26 00:00:00
2758	65	2026-02-27 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-02-27 00:00:00
2759	65	2026-02-28 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-02-28 00:00:00
2760	65	2026-03-01 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-01 00:00:00
2761	65	2026-03-02 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-02 00:00:00
2762	65	2026-03-03 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-03 00:00:00
2763	65	2026-03-04 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-04 00:00:00
2764	65	2026-03-05 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-05 00:00:00
2765	65	2026-03-06 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-06 00:00:00
2766	65	2026-03-07 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-07 00:00:00
2767	66	2026-02-27 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-02-27 00:00:00
2768	66	2026-02-28 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-02-28 00:00:00
2769	66	2026-03-01 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-01 00:00:00
2770	66	2026-03-02 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-02 00:00:00
2771	66	2026-03-03 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-03 00:00:00
2772	66	2026-03-04 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-04 00:00:00
2773	66	2026-03-05 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-05 00:00:00
2774	66	2026-03-06 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-06 00:00:00
2775	66	2026-03-07 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-07 00:00:00
2776	67	2026-02-27 00:00:00	7	12	23.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-02-27 00:00:00
2777	67	2026-02-28 00:00:00	7	12	23.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-02-28 00:00:00
2778	67	2026-03-03 00:00:00	8	12	24.4km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-03 00:00:00
2779	68	2026-02-26 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-02-26 00:00:00
2780	68	2026-02-27 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-02-27 00:00:00
2781	68	2026-02-28 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-02-28 00:00:00
2782	68	2026-03-01 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-01 00:00:00
2783	68	2026-03-02 00:00:00	4	31	0.05km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-02 00:00:00
2784	68	2026-03-04 00:00:00	2	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-04 00:00:00
2785	68	2026-03-06 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-06 00:00:00
2786	68	2026-03-07 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-07 00:00:00
2787	69	2026-03-06 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-06 00:00:00
2788	71	2026-02-25 00:00:00	16	28	51.3km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-02-25 00:00:00
2789	71	2026-02-26 00:00:00	16	28	51.3km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-02-26 00:00:00
2790	71	2026-03-04 00:00:00	9	28	23.6km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-04 00:00:00
2791	71	2026-03-06 00:00:00	8	28	19.4km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-06 00:00:00
2792	72	2026-02-26 00:00:00	28	30	96.6km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-02-26 00:00:00
2793	72	2026-03-02 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-02 00:00:00
2794	72	2026-03-06 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-06 00:00:00
2795	73	2026-02-27 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-02-27 00:00:00
2796	73	2026-03-01 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-01 00:00:00
2797	73	2026-03-02 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-02 00:00:00
2798	73	2026-03-04 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-04 00:00:00
2799	74	2026-01-12 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-12 00:00:00
2800	74	2026-01-13 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-13 00:00:00
2801	74	2026-01-14 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-14 00:00:00
2802	74	2026-01-15 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-15 00:00:00
2803	74	2026-01-16 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-16 00:00:00
2804	74	2026-01-17 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-17 00:00:00
2805	74	2026-01-18 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-18 00:00:00
2806	74	2026-01-19 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-19 00:00:00
2807	74	2026-01-20 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-20 00:00:00
2808	74	2026-01-21 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-21 00:00:00
2809	74	2026-01-22 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-22 00:00:00
2810	74	2026-01-23 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-23 00:00:00
2811	74	2026-01-24 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-24 00:00:00
2812	74	2026-01-25 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-25 00:00:00
2813	74	2026-01-26 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-26 00:00:00
2814	74	2026-01-27 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-27 00:00:00
2815	74	2026-01-28 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-28 00:00:00
2816	74	2026-01-29 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-29 00:00:00
2817	74	2026-01-30 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-30 00:00:00
2818	74	2026-01-31 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-01-31 00:00:00
2819	74	2026-02-01 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-01 00:00:00
2820	74	2026-02-02 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-02 00:00:00
2821	74	2026-02-03 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-03 00:00:00
2822	74	2026-02-04 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-04 00:00:00
2823	74	2026-02-05 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-05 00:00:00
2824	74	2026-02-06 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-06 00:00:00
2825	74	2026-02-07 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-07 00:00:00
2826	74	2026-02-08 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-08 00:00:00
2827	74	2026-02-09 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-09 00:00:00
2828	74	2026-02-10 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-10 00:00:00
2829	74	2026-02-11 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-11 00:00:00
2830	74	2026-02-12 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-12 00:00:00
2831	74	2026-02-13 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-13 00:00:00
2832	74	2026-02-14 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-14 00:00:00
2833	74	2026-02-15 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-15 00:00:00
2834	74	2026-02-16 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-16 00:00:00
2835	74	2026-02-17 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-17 00:00:00
2836	74	2026-02-18 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-18 00:00:00
2837	74	2026-02-19 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-19 00:00:00
2838	74	2026-02-20 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-20 00:00:00
2839	74	2026-02-21 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-21 00:00:00
2840	74	2026-02-22 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-22 00:00:00
2841	74	2026-02-23 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-23 00:00:00
2842	74	2026-02-24 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-24 00:00:00
2843	74	2026-02-25 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-25 00:00:00
2844	74	2026-02-26 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-26 00:00:00
2845	74	2026-02-27 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-27 00:00:00
2846	74	2026-02-28 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-02-28 00:00:00
2847	74	2026-03-01 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-01 00:00:00
2848	74	2026-03-02 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-02 00:00:00
2849	74	2026-03-03 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-03 00:00:00
2850	74	2026-03-04 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-04 00:00:00
2851	74	2026-03-05 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-05 00:00:00
2852	74	2026-03-06 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-06 00:00:00
2853	74	2026-03-07 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-07 00:00:00
2854	75	2026-01-22 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-22 00:00:00
2855	75	2026-01-23 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-23 00:00:00
2856	75	2026-01-24 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-24 00:00:00
2857	75	2026-01-25 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-25 00:00:00
2858	75	2026-01-26 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-26 00:00:00
2859	75	2026-01-27 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-27 00:00:00
2860	75	2026-01-28 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-28 00:00:00
2861	75	2026-01-29 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-29 00:00:00
2862	75	2026-01-30 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-30 00:00:00
2863	75	2026-01-31 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-01-31 00:00:00
2864	75	2026-02-01 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-01 00:00:00
2865	75	2026-02-02 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-02 00:00:00
2866	75	2026-02-03 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-03 00:00:00
2867	75	2026-02-04 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-04 00:00:00
2868	75	2026-02-05 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-05 00:00:00
2869	75	2026-02-06 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-06 00:00:00
2870	75	2026-02-07 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-07 00:00:00
2871	75	2026-02-08 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-08 00:00:00
2872	75	2026-02-09 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-09 00:00:00
2873	75	2026-02-10 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-10 00:00:00
2874	75	2026-02-11 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-11 00:00:00
2875	75	2026-02-12 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-12 00:00:00
2876	75	2026-02-13 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-13 00:00:00
2877	75	2026-02-14 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-14 00:00:00
2878	75	2026-02-15 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-15 00:00:00
2879	75	2026-02-16 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-16 00:00:00
2880	75	2026-02-17 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-17 00:00:00
2881	75	2026-02-18 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-18 00:00:00
2882	75	2026-02-19 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-19 00:00:00
2883	75	2026-02-20 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-20 00:00:00
2884	75	2026-02-21 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-21 00:00:00
2885	75	2026-02-22 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-22 00:00:00
2886	75	2026-02-23 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-23 00:00:00
2887	75	2026-02-24 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-24 00:00:00
2888	75	2026-02-25 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-25 00:00:00
2889	75	2026-02-26 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-26 00:00:00
2890	75	2026-02-27 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-27 00:00:00
2891	75	2026-02-28 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-02-28 00:00:00
2892	75	2026-03-01 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-01 00:00:00
2893	75	2026-03-03 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-03 00:00:00
2894	75	2026-03-04 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-04 00:00:00
2895	75	2026-03-05 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-05 00:00:00
2896	75	2026-03-06 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-06 00:00:00
2897	75	2026-03-07 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-07 00:00:00
2898	76	2026-02-20 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-20 00:00:00
2899	76	2026-02-21 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-21 00:00:00
2900	76	2026-02-22 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-22 00:00:00
2901	76	2026-02-23 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-23 00:00:00
2902	76	2026-02-24 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-24 00:00:00
2903	76	2026-02-25 00:00:00	13	15	72.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-25 00:00:00
2904	76	2026-02-28 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-02-28 00:00:00
2905	76	2026-03-01 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-01 00:00:00
2906	76	2026-03-02 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-02 00:00:00
2907	76	2026-03-03 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-03 00:00:00
2908	76	2026-03-04 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-04 00:00:00
2909	76	2026-03-05 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-05 00:00:00
2910	76	2026-03-06 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-06 00:00:00
2911	76	2026-03-07 00:00:00	14	15	79.55km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-07 00:00:00
2912	77	2026-02-24 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-24 00:00:00
2913	77	2026-02-25 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-02-25 00:00:00
2914	77	2026-03-01 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-01 00:00:00
2915	77	2026-03-04 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-04 00:00:00
2916	77	2026-03-06 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-06 00:00:00
2917	78	2026-02-27 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-02-27 00:00:00
2918	78	2026-03-03 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-03 00:00:00
2919	78	2026-03-04 00:00:00	26	28	142.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-04 00:00:00
2920	78	2026-03-07 00:00:00	25	28	136.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-07 00:00:00
2921	80	2026-02-14 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-14 00:00:00
2922	80	2026-02-15 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-15 00:00:00
2923	80	2026-02-16 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-16 00:00:00
2924	80	2026-02-17 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-17 00:00:00
2925	80	2026-02-18 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-18 00:00:00
2926	80	2026-02-19 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-19 00:00:00
2927	80	2026-02-20 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-20 00:00:00
2928	80	2026-02-21 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-21 00:00:00
2929	80	2026-02-22 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-22 00:00:00
2930	80	2026-02-23 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-23 00:00:00
2931	80	2026-02-24 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-24 00:00:00
2932	80	2026-02-25 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-25 00:00:00
2933	80	2026-02-26 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-26 00:00:00
2934	80	2026-02-27 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-27 00:00:00
2935	80	2026-02-28 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-02-28 00:00:00
2936	80	2026-03-01 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-01 00:00:00
2937	80	2026-03-02 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-02 00:00:00
2938	80	2026-03-03 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-03 00:00:00
2939	80	2026-03-04 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-04 00:00:00
2940	80	2026-03-05 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-05 00:00:00
2941	80	2026-03-06 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-06 00:00:00
2942	80	2026-03-07 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-07 00:00:00
2943	81	2026-01-28 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-01-28 00:00:00
2944	81	2026-01-29 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-01-29 00:00:00
2945	81	2026-01-30 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-01-30 00:00:00
2946	81	2026-01-31 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-01-31 00:00:00
2947	81	2026-02-01 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-01 00:00:00
2948	81	2026-02-02 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-02 00:00:00
2949	81	2026-02-03 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-03 00:00:00
2950	81	2026-02-04 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-04 00:00:00
2951	81	2026-02-05 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-05 00:00:00
2952	81	2026-02-06 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-06 00:00:00
2953	81	2026-02-07 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-07 00:00:00
2954	81	2026-02-08 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-08 00:00:00
2955	81	2026-02-09 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-09 00:00:00
2956	81	2026-02-10 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-10 00:00:00
2957	81	2026-02-11 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-11 00:00:00
2958	81	2026-02-12 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-12 00:00:00
2959	81	2026-02-13 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-13 00:00:00
2960	81	2026-02-14 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-14 00:00:00
2961	81	2026-02-15 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-15 00:00:00
2962	81	2026-02-16 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-16 00:00:00
2963	81	2026-02-17 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-17 00:00:00
2964	81	2026-02-18 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-18 00:00:00
2965	81	2026-02-19 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-19 00:00:00
2966	81	2026-02-20 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-20 00:00:00
2967	81	2026-02-21 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-21 00:00:00
2968	81	2026-02-22 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-22 00:00:00
2969	81	2026-02-23 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-23 00:00:00
2970	81	2026-02-24 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-24 00:00:00
2971	81	2026-02-25 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-25 00:00:00
2972	81	2026-02-26 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-26 00:00:00
2973	81	2026-02-27 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-27 00:00:00
2974	81	2026-02-28 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-02-28 00:00:00
2975	81	2026-03-01 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-01 00:00:00
2976	81	2026-03-02 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-02 00:00:00
2977	81	2026-03-03 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-03 00:00:00
2978	81	2026-03-04 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-04 00:00:00
2979	81	2026-03-05 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-05 00:00:00
2980	81	2026-03-06 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-06 00:00:00
2981	81	2026-03-07 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-07 00:00:00
2982	82	2026-02-25 00:00:00	14	16	41.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-02-25 00:00:00
2983	82	2026-02-28 00:00:00	14	16	41.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-02-28 00:00:00
2984	82	2026-03-06 00:00:00	15	16	58.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-06 00:00:00
2985	83	2026-02-07 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-07 00:00:00
2986	83	2026-02-08 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-08 00:00:00
2987	83	2026-02-09 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-09 00:00:00
2988	83	2026-02-10 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-10 00:00:00
2989	83	2026-02-11 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-11 00:00:00
2990	83	2026-02-12 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-12 00:00:00
2991	83	2026-02-13 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-13 00:00:00
2992	83	2026-02-14 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-14 00:00:00
2993	83	2026-02-15 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-15 00:00:00
2994	83	2026-02-16 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-16 00:00:00
2995	83	2026-02-17 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-17 00:00:00
2996	83	2026-02-18 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-18 00:00:00
2997	83	2026-02-19 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-19 00:00:00
2998	83	2026-02-20 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-20 00:00:00
2999	83	2026-02-21 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-21 00:00:00
3000	83	2026-02-22 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-22 00:00:00
3001	83	2026-02-23 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-23 00:00:00
3002	83	2026-02-24 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-24 00:00:00
3003	83	2026-02-25 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-25 00:00:00
3004	83	2026-02-26 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-26 00:00:00
3005	83	2026-02-27 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-27 00:00:00
3006	83	2026-02-28 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-02-28 00:00:00
3007	83	2026-03-01 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-01 00:00:00
3008	83	2026-03-02 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-02 00:00:00
3009	83	2026-03-03 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-03 00:00:00
3010	83	2026-03-04 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-04 00:00:00
3011	83	2026-03-05 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-05 00:00:00
3012	83	2026-03-06 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-06 00:00:00
3013	83	2026-03-07 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-07 00:00:00
3014	84	2026-02-22 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-22 00:00:00
3015	84	2026-02-23 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-23 00:00:00
3016	84	2026-02-24 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-24 00:00:00
3017	84	2026-02-25 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-25 00:00:00
3018	84	2026-02-26 00:00:00	8	9	46.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-26 00:00:00
3019	84	2026-02-28 00:00:00	6	9	21.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-02-28 00:00:00
3020	84	2026-03-01 00:00:00	6	9	21.6km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-01 00:00:00
3021	84	2026-03-03 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-03 00:00:00
3022	84	2026-03-04 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-04 00:00:00
3023	84	2026-03-05 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-05 00:00:00
3024	84	2026-03-06 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-06 00:00:00
3025	84	2026-03-07 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-07 00:00:00
3026	86	2026-02-25 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-02-25 00:00:00
3027	86	2026-02-26 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-02-26 00:00:00
3028	86	2026-02-27 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-02-27 00:00:00
3029	86	2026-02-28 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-02-28 00:00:00
3030	86	2026-03-01 00:00:00	5	18	37km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-01 00:00:00
3031	86	2026-03-03 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-03 00:00:00
3032	86	2026-03-04 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-04 00:00:00
3033	86	2026-03-05 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-05 00:00:00
3034	86	2026-03-06 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-06 00:00:00
3035	86	2026-03-07 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-07 00:00:00
3036	88	2026-02-25 00:00:00	13	13	62.5km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-02-25 00:00:00
3037	88	2026-03-04 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-04 00:00:00
3038	88	2026-03-05 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-05 00:00:00
3039	88	2026-03-06 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-06 00:00:00
3040	88	2026-03-07 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-07 00:00:00
3041	89	2026-03-04 00:00:00	4	5	14km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-04 00:00:00
3042	89	2026-03-05 00:00:00	4	5	14km/16km	https://www.nordicfrance.fr/nordicfrance_station/trois-fours/	2026-03-05 00:00:00
3043	90	2026-01-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-01-28 00:00:00
3044	90	2026-01-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-01-29 00:00:00
3045	90	2026-01-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-01-30 00:00:00
3046	90	2026-01-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-01-31 00:00:00
3047	90	2026-02-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-01 00:00:00
3048	90	2026-02-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-02 00:00:00
3049	90	2026-02-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-03 00:00:00
3050	90	2026-02-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-04 00:00:00
3051	90	2026-02-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-05 00:00:00
3052	90	2026-02-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-06 00:00:00
3053	90	2026-02-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-07 00:00:00
3054	90	2026-02-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-08 00:00:00
3055	90	2026-02-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-09 00:00:00
3056	90	2026-02-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-10 00:00:00
3057	90	2026-02-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-11 00:00:00
3058	90	2026-02-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-12 00:00:00
3059	90	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-13 00:00:00
3060	90	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-14 00:00:00
3061	90	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-15 00:00:00
3062	90	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-16 00:00:00
3063	90	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-17 00:00:00
3064	90	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-18 00:00:00
3065	90	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-19 00:00:00
3066	90	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-20 00:00:00
3067	90	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-21 00:00:00
3068	90	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-22 00:00:00
3069	90	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-23 00:00:00
3070	90	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-24 00:00:00
3071	90	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-25 00:00:00
3072	90	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-26 00:00:00
3073	90	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-27 00:00:00
3074	90	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-02-28 00:00:00
3075	90	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-01 00:00:00
3076	90	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-02 00:00:00
3077	90	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-03 00:00:00
3078	90	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-04 00:00:00
3079	90	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-05 00:00:00
3080	90	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-06 00:00:00
3081	90	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-07 00:00:00
3082	91	2026-02-25 00:00:00	14	15	78.2km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-02-25 00:00:00
3083	91	2026-02-26 00:00:00	14	15	78.2km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-02-26 00:00:00
3084	91	2026-02-28 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-02-28 00:00:00
3085	91	2026-03-01 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-01 00:00:00
3086	91	2026-03-04 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-04 00:00:00
3087	91	2026-03-05 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-05 00:00:00
3088	91	2026-03-06 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-06 00:00:00
3089	91	2026-03-07 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-07 00:00:00
3090	94	2026-02-25 00:00:00	2	5	2.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-02-25 00:00:00
3091	94	2026-02-27 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-02-27 00:00:00
3092	94	2026-02-28 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-02-28 00:00:00
3093	94	2026-03-01 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-01 00:00:00
3094	94	2026-03-02 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-02 00:00:00
3095	94	2026-03-03 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-03 00:00:00
3096	94	2026-03-04 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-04 00:00:00
3097	94	2026-03-05 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-05 00:00:00
3098	94	2026-03-06 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-06 00:00:00
3099	94	2026-03-07 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-07 00:00:00
3100	96	2026-03-05 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-05 00:00:00
3101	96	2026-03-06 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-06 00:00:00
3102	97	2026-03-02 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-02 00:00:00
3103	97	2026-03-04 00:00:00	9	12	18.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-04 00:00:00
3104	97	2026-03-06 00:00:00	7	12	13.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-06 00:00:00
3105	98	2026-02-07 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-07 00:00:00
3106	98	2026-02-08 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-08 00:00:00
3107	98	2026-02-09 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-09 00:00:00
3108	98	2026-02-10 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-10 00:00:00
3109	98	2026-02-11 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-11 00:00:00
3110	98	2026-02-12 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-12 00:00:00
3111	98	2026-02-13 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-13 00:00:00
3112	98	2026-02-14 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-14 00:00:00
3113	98	2026-02-15 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-15 00:00:00
3114	98	2026-02-16 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-16 00:00:00
3115	98	2026-02-17 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-17 00:00:00
3116	98	2026-02-18 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-18 00:00:00
3117	98	2026-02-19 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-19 00:00:00
3118	98	2026-02-20 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-20 00:00:00
3119	98	2026-02-21 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-21 00:00:00
3120	98	2026-02-22 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-22 00:00:00
3121	98	2026-02-23 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-23 00:00:00
3122	98	2026-02-24 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-24 00:00:00
3123	98	2026-02-25 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-25 00:00:00
3124	98	2026-02-26 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-26 00:00:00
3125	98	2026-02-27 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-27 00:00:00
3126	98	2026-02-28 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-02-28 00:00:00
3127	98	2026-03-01 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-01 00:00:00
3128	98	2026-03-02 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-02 00:00:00
3129	98	2026-03-03 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-03 00:00:00
3130	98	2026-03-04 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-04 00:00:00
3131	98	2026-03-05 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-05 00:00:00
3132	98	2026-03-06 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-06 00:00:00
3133	98	2026-03-07 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-07 00:00:00
3134	99	2026-02-26 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-02-26 00:00:00
3135	99	2026-02-27 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-02-27 00:00:00
3136	99	2026-02-28 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-02-28 00:00:00
3137	99	2026-03-02 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-02 00:00:00
3138	99	2026-03-03 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-03 00:00:00
3139	100	2026-02-28 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-02-28 00:00:00
3140	100	2026-03-01 00:00:00	10	38	31.7km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-01 00:00:00
3141	100	2026-03-04 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-04 00:00:00
3142	100	2026-03-06 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-06 00:00:00
3143	100	2026-03-07 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-07 00:00:00
3144	101	2026-02-24 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-24 00:00:00
3145	101	2026-02-25 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-25 00:00:00
3146	101	2026-02-26 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-26 00:00:00
3147	101	2026-02-27 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-27 00:00:00
3148	101	2026-02-28 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-02-28 00:00:00
3149	101	2026-03-01 00:00:00	12	14	59.8km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-01 00:00:00
3150	101	2026-03-03 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-03 00:00:00
3151	101	2026-03-04 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-04 00:00:00
3152	101	2026-03-05 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-05 00:00:00
3153	101	2026-03-06 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-06 00:00:00
3154	101	2026-03-07 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-07 00:00:00
3155	102	2026-03-05 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-05 00:00:00
3156	102	2026-03-06 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-06 00:00:00
3157	103	2026-02-25 00:00:00	32	64	73.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-02-25 00:00:00
3158	103	2026-02-26 00:00:00	32	64	73.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-02-26 00:00:00
3159	103	2026-02-27 00:00:00	32	64	73.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-02-27 00:00:00
3160	103	2026-03-01 00:00:00	19	64	49.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-01 00:00:00
3161	104	2026-02-27 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-02-27 00:00:00
3162	104	2026-03-01 00:00:00	1	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-01 00:00:00
3163	104	2026-03-03 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-03 00:00:00
3164	104	2026-03-04 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-04 00:00:00
3165	104	2026-03-05 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-05 00:00:00
3166	104	2026-03-06 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-06 00:00:00
3167	104	2026-03-07 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-07 00:00:00
3168	105	2026-02-26 00:00:00	5	20	34.5km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-02-26 00:00:00
3169	105	2026-02-28 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-02-28 00:00:00
3170	105	2026-03-01 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-01 00:00:00
3171	105	2026-03-02 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-02 00:00:00
3172	105	2026-03-03 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-03 00:00:00
3173	105	2026-03-04 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-04 00:00:00
3174	105	2026-03-05 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-05 00:00:00
3175	105	2026-03-06 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-06 00:00:00
3176	105	2026-03-07 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-07 00:00:00
3177	106	2026-02-25 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-02-25 00:00:00
3178	106	2026-02-27 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-02-27 00:00:00
3179	106	2026-02-28 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-02-28 00:00:00
3180	106	2026-03-01 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-01 00:00:00
3181	106	2026-03-02 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-02 00:00:00
3182	106	2026-03-03 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-03 00:00:00
3183	106	2026-03-04 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-04 00:00:00
3184	106	2026-03-05 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-05 00:00:00
3185	106	2026-03-06 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-06 00:00:00
3186	106	2026-03-07 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-07 00:00:00
3187	107	2026-02-18 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-18 00:00:00
3188	107	2026-02-19 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-19 00:00:00
3189	107	2026-02-20 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-20 00:00:00
3190	107	2026-02-21 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-21 00:00:00
3191	107	2026-02-22 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-22 00:00:00
3192	107	2026-02-23 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-23 00:00:00
3193	107	2026-02-24 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-24 00:00:00
3194	107	2026-02-25 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-25 00:00:00
3195	107	2026-02-26 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-26 00:00:00
3196	107	2026-02-27 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-27 00:00:00
3197	107	2026-02-28 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-02-28 00:00:00
3198	107	2026-03-01 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-01 00:00:00
3199	107	2026-03-02 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-02 00:00:00
3200	107	2026-03-03 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-03 00:00:00
3201	107	2026-03-04 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-04 00:00:00
3202	107	2026-03-05 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-05 00:00:00
3203	107	2026-03-06 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-06 00:00:00
3204	107	2026-03-07 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-07 00:00:00
3205	108	2026-02-23 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-23 00:00:00
3206	108	2026-02-24 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-24 00:00:00
3207	108	2026-02-25 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-25 00:00:00
3208	108	2026-02-26 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-26 00:00:00
3209	108	2026-02-27 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-27 00:00:00
3210	108	2026-02-28 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-02-28 00:00:00
3211	108	2026-03-01 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-01 00:00:00
3212	108	2026-03-02 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-02 00:00:00
3213	108	2026-03-03 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-03 00:00:00
3214	108	2026-03-04 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-04 00:00:00
3215	108	2026-03-05 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-05 00:00:00
3216	108	2026-03-06 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-06 00:00:00
3217	108	2026-03-07 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-07 00:00:00
3218	109	2026-01-19 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-19 00:00:00
3219	109	2026-01-20 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-20 00:00:00
3220	109	2026-01-21 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-21 00:00:00
3221	109	2026-01-22 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-22 00:00:00
3222	109	2026-01-23 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-23 00:00:00
3223	109	2026-01-24 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-24 00:00:00
3224	109	2026-01-25 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-25 00:00:00
3225	109	2026-01-26 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-26 00:00:00
3226	109	2026-01-27 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-27 00:00:00
3227	109	2026-01-28 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-28 00:00:00
3228	109	2026-01-29 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-29 00:00:00
3229	109	2026-01-30 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-30 00:00:00
3230	109	2026-01-31 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-01-31 00:00:00
3231	109	2026-02-01 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-01 00:00:00
3232	109	2026-02-02 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-02 00:00:00
3233	109	2026-02-03 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-03 00:00:00
3234	109	2026-02-04 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-04 00:00:00
3235	109	2026-02-05 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-05 00:00:00
3236	109	2026-02-06 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-06 00:00:00
3237	109	2026-02-07 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-07 00:00:00
3238	109	2026-02-08 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-08 00:00:00
3239	109	2026-02-09 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-09 00:00:00
3240	109	2026-02-10 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-10 00:00:00
3241	109	2026-02-11 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-11 00:00:00
3242	109	2026-02-12 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-12 00:00:00
3243	109	2026-02-13 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-13 00:00:00
3244	109	2026-02-14 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-14 00:00:00
3245	109	2026-02-15 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-15 00:00:00
3246	109	2026-02-16 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-16 00:00:00
3247	109	2026-02-17 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-17 00:00:00
3248	109	2026-02-18 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-18 00:00:00
3249	109	2026-02-19 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-19 00:00:00
3250	109	2026-02-20 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-20 00:00:00
3251	109	2026-02-21 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-21 00:00:00
3252	109	2026-02-22 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-22 00:00:00
3253	109	2026-02-23 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-23 00:00:00
3254	109	2026-02-24 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-24 00:00:00
3255	109	2026-02-25 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-25 00:00:00
3256	109	2026-02-26 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-26 00:00:00
3257	109	2026-02-27 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-27 00:00:00
3258	109	2026-02-28 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-02-28 00:00:00
3259	109	2026-03-01 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-01 00:00:00
3260	109	2026-03-02 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-02 00:00:00
3261	109	2026-03-03 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-03 00:00:00
3262	109	2026-03-04 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-04 00:00:00
3263	109	2026-03-05 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-05 00:00:00
3264	109	2026-03-06 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-06 00:00:00
3265	109	2026-03-07 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-07 00:00:00
8829	24	2026-03-20 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-20 00:00:00
8830	25	2026-03-20 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-20 00:00:00
8831	30	2026-03-20 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-20 00:00:00
8832	31	2026-03-20 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-20 00:00:00
8833	34	2026-03-20 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-20 00:00:00
8834	38	2026-03-20 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-20 00:00:00
3267	110	2026-03-10 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-10 00:00:00
3268	110	2026-03-11 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-11 00:00:00
3269	110	2026-03-12 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-12 00:00:00
3270	110	2026-03-13 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-13 00:00:00
3271	110	2026-03-14 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-14 00:00:00
3272	110	2026-03-15 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-15 00:00:00
3273	110	2026-03-16 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-16 00:00:00
3274	110	2026-03-17 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-17 00:00:00
3275	110	2026-03-18 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-18 00:00:00
3276	110	2026-03-19 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-19 00:00:00
8835	39	2026-03-20 00:00:00	28	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-20 00:00:00
8836	155	2026-03-20 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-20 00:00:00
8837	41	2026-03-20 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-20 00:00:00
8838	42	2026-03-20 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-20 00:00:00
8839	44	2026-03-20 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-20 00:00:00
8840	45	2026-03-20 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-20 00:00:00
8841	46	2026-03-20 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-20 00:00:00
8842	47	2026-03-20 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-20 00:00:00
8843	156	2026-03-20 00:00:00	18	18	35.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-20 00:00:00
8844	48	2026-03-20 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-20 00:00:00
8845	49	2026-03-20 00:00:00	11	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-20 00:00:00
8846	51	2026-03-20 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-20 00:00:00
8847	53	2026-03-20 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-20 00:00:00
8848	54	2026-03-20 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-20 00:00:00
8849	55	2026-03-20 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-20 00:00:00
8850	56	2026-03-20 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-20 00:00:00
8851	57	2026-03-20 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-20 00:00:00
8852	58	2026-03-20 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-20 00:00:00
8853	59	2026-03-20 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-20 00:00:00
8854	61	2026-03-20 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-20 00:00:00
8855	64	2026-03-20 00:00:00	16	21	69.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-20 00:00:00
8856	65	2026-03-20 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-20 00:00:00
8857	66	2026-03-20 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-20 00:00:00
8858	67	2026-03-20 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-20 00:00:00
8859	69	2026-03-20 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-20 00:00:00
8860	70	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-20 00:00:00
8861	71	2026-03-20 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-20 00:00:00
8862	72	2026-03-20 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-20 00:00:00
8863	73	2026-03-20 00:00:00	20	21	54.6km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-20 00:00:00
8864	74	2026-03-20 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-20 00:00:00
8865	78	2026-03-20 00:00:00	17	28	96.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-20 00:00:00
8866	79	2026-03-20 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-20 00:00:00
8867	80	2026-03-20 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-20 00:00:00
8868	81	2026-03-20 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-20 00:00:00
8869	82	2026-03-20 00:00:00	10	16	41.95km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-20 00:00:00
8870	83	2026-03-20 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-20 00:00:00
8871	85	2026-03-20 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-20 00:00:00
8872	90	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-20 00:00:00
8873	91	2026-03-20 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-20 00:00:00
8874	92	2026-03-20 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-20 00:00:00
8875	94	2026-03-20 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-20 00:00:00
8876	95	2026-03-20 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-20 00:00:00
8877	96	2026-03-20 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-20 00:00:00
8878	97	2026-03-20 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-20 00:00:00
8879	98	2026-03-20 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-20 00:00:00
8880	99	2026-03-20 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-20 00:00:00
8881	100	2026-03-20 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-20 00:00:00
8882	101	2026-03-20 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-20 00:00:00
8883	102	2026-03-20 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-20 00:00:00
8884	103	2026-03-20 00:00:00	19	64	49.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-20 00:00:00
8885	62	2026-03-20 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-20 00:00:00
8886	107	2026-03-20 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-20 00:00:00
8887	108	2026-03-20 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-20 00:00:00
8888	6	2026-03-20 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-20 00:00:00
8889	109	2026-03-20 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-20 00:00:00
8890	13	2026-03-20 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-20 00:00:00
8891	110	2026-03-20 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-20 00:00:00
8892	14	2026-03-20 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-20 00:00:00
8893	111	2026-03-20 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-20 00:00:00
8894	21	2026-03-20 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-20 00:00:00
8895	153	2026-03-20 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-20 00:00:00
8896	112	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-20 00:00:00
8897	23	2026-03-20 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-20 00:00:00
8898	113	2026-03-20 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-20 00:00:00
8899	114	2026-03-20 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-20 00:00:00
8900	115	2026-03-20 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-20 00:00:00
8901	26	2026-03-20 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-20 00:00:00
8902	116	2026-03-20 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-20 00:00:00
8903	27	2026-03-20 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-20 00:00:00
8904	28	2026-03-20 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-20 00:00:00
8905	117	2026-03-20 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-20 00:00:00
8906	29	2026-03-20 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-20 00:00:00
8907	118	2026-03-20 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-20 00:00:00
8908	119	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-20 00:00:00
8909	32	2026-03-20 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-20 00:00:00
8910	33	2026-03-20 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-20 00:00:00
8911	120	2026-03-20 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-20 00:00:00
8912	35	2026-03-20 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-20 00:00:00
8913	121	2026-03-20 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-20 00:00:00
8914	36	2026-03-20 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-20 00:00:00
8915	122	2026-03-20 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-20 00:00:00
8916	123	2026-03-20 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-20 00:00:00
8917	37	2026-03-20 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-20 00:00:00
8918	124	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-20 00:00:00
8919	125	2026-03-20 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-20 00:00:00
8920	126	2026-03-20 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-20 00:00:00
8921	40	2026-03-20 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-20 00:00:00
8922	127	2026-03-20 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-20 00:00:00
8923	128	2026-03-20 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-20 00:00:00
8924	43	2026-03-20 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-20 00:00:00
8925	129	2026-03-20 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-20 00:00:00
8926	130	2026-03-20 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-20 00:00:00
8927	131	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-20 00:00:00
8928	132	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-20 00:00:00
8929	133	2026-03-20 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-20 00:00:00
8930	50	2026-03-20 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-20 00:00:00
8931	134	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-20 00:00:00
8932	135	2026-03-20 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-20 00:00:00
8933	137	2026-03-20 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-20 00:00:00
8934	52	2026-03-20 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-20 00:00:00
8935	138	2026-03-20 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-20 00:00:00
8936	139	2026-03-20 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-20 00:00:00
8937	140	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-20 00:00:00
8938	141	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-20 00:00:00
8939	60	2026-03-20 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-20 00:00:00
8940	63	2026-03-20 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-20 00:00:00
8941	142	2026-03-20 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-20 00:00:00
8942	143	2026-03-20 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-20 00:00:00
8943	144	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-20 00:00:00
8944	68	2026-03-20 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-20 00:00:00
8945	104	2026-03-20 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-20 00:00:00
8946	145	2026-03-20 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-20 00:00:00
8947	146	2026-03-20 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-20 00:00:00
8948	147	2026-03-20 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-20 00:00:00
8949	75	2026-03-20 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-20 00:00:00
8950	76	2026-03-20 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-20 00:00:00
8951	77	2026-03-20 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-20 00:00:00
8952	148	2026-03-20 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-20 00:00:00
8953	105	2026-03-20 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-20 00:00:00
8954	154	2026-03-20 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-20 00:00:00
8955	84	2026-03-20 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-20 00:00:00
8956	149	2026-03-20 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-20 00:00:00
8957	86	2026-03-20 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-20 00:00:00
8958	150	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-20 00:00:00
8959	88	2026-03-20 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-20 00:00:00
8960	106	2026-03-20 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-20 00:00:00
8961	151	2026-03-20 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-20 00:00:00
8962	93	2026-03-20 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-20 00:00:00
8963	152	2026-03-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-20 00:00:00
11024	118	2026-04-11 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-04-11 07:41:49.362
11025	119	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-04-11 07:41:49.886
11026	30	2026-04-11 00:00:00	0	13	0km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-04-11 07:41:50.408
11027	32	2026-04-11 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-04-11 07:41:50.929
11028	33	2026-04-11 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-04-11 07:41:51.45
11029	120	2026-04-11 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-04-11 07:41:51.971
11030	35	2026-04-11 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-04-11 07:41:52.494
11031	121	2026-04-11 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-04-11 07:41:53.016
11032	36	2026-04-11 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-04-11 07:41:53.537
11033	122	2026-04-11 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-04-11 07:41:54.059
11035	37	2026-04-11 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-04-11 07:41:55.102
11036	38	2026-04-11 00:00:00	0	42	0km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-04-11 07:41:55.625
11037	124	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-04-11 07:41:56.146
11038	125	2026-04-11 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-04-11 07:41:56.668
11039	39	2026-04-11 00:00:00	0	74	0km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-04-11 07:41:57.19
11040	126	2026-04-11 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-04-11 07:41:57.712
11041	40	2026-04-11 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-04-11 07:41:58.233
11042	127	2026-04-11 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-04-11 07:41:58.755
11043	41	2026-04-11 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-04-11 07:41:59.277
11044	128	2026-04-11 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-04-11 07:41:59.799
11045	42	2026-04-11 00:00:00	13	22	31.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-04-11 07:42:00.322
11046	43	2026-04-11 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-04-11 07:42:00.843
11047	44	2026-04-11 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-04-11 07:42:01.366
11048	129	2026-04-11 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-04-11 07:42:01.887
11049	130	2026-04-11 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-04-11 07:42:02.408
11050	131	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-04-11 07:42:02.931
11051	46	2026-04-11 00:00:00	0	12	0km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-04-11 07:42:03.452
8964	1	2026-03-21 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-21 00:00:00
8965	2	2026-03-21 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-21 00:00:00
8966	3	2026-03-21 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-21 00:00:00
8967	4	2026-03-21 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-21 00:00:00
8968	5	2026-03-21 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-21 00:00:00
3462	111	2026-02-06 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-06 00:00:00
3463	111	2026-02-07 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-07 00:00:00
3464	111	2026-02-08 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-08 00:00:00
3465	111	2026-02-09 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-09 00:00:00
3466	111	2026-02-10 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-10 00:00:00
3467	111	2026-02-11 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-11 00:00:00
3468	111	2026-02-12 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-12 00:00:00
3469	111	2026-02-13 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-13 00:00:00
3470	111	2026-02-14 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-14 00:00:00
3471	111	2026-02-15 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-15 00:00:00
3472	111	2026-02-16 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-16 00:00:00
3473	111	2026-02-17 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-17 00:00:00
3474	111	2026-02-18 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-18 00:00:00
3475	111	2026-02-19 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-19 00:00:00
3476	111	2026-02-20 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-20 00:00:00
3477	111	2026-02-21 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-21 00:00:00
3478	111	2026-02-22 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-22 00:00:00
3479	111	2026-02-23 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-23 00:00:00
3480	111	2026-02-24 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-24 00:00:00
3481	111	2026-02-25 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-25 00:00:00
3482	111	2026-02-26 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-26 00:00:00
3483	111	2026-02-27 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-27 00:00:00
3484	111	2026-02-28 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-02-28 00:00:00
3485	111	2026-03-01 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-01 00:00:00
3486	111	2026-03-02 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-02 00:00:00
3487	111	2026-03-03 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-03 00:00:00
3488	111	2026-03-04 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-04 00:00:00
3489	111	2026-03-05 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-05 00:00:00
3490	111	2026-03-06 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-06 00:00:00
3491	111	2026-03-07 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-07 00:00:00
8969	7	2026-03-21 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-21 00:00:00
8970	8	2026-03-21 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-21 00:00:00
8971	9	2026-03-21 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-21 00:00:00
8972	10	2026-03-21 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-21 00:00:00
8973	11	2026-03-21 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-21 00:00:00
8974	12	2026-03-21 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-21 00:00:00
3493	112	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-10 00:00:00
3494	112	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-11 00:00:00
3495	112	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-12 00:00:00
3496	112	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-13 00:00:00
3497	112	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-14 00:00:00
3498	112	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-15 00:00:00
3500	112	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-17 00:00:00
3501	112	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-18 00:00:00
3502	112	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-19 00:00:00
8975	15	2026-03-21 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-21 00:00:00
8976	16	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-21 00:00:00
8977	17	2026-03-21 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-21 00:00:00
8978	18	2026-03-21 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-21 00:00:00
8979	19	2026-03-21 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-21 00:00:00
8980	20	2026-03-21 00:00:00	24	25	76.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-21 00:00:00
8981	22	2026-03-21 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-21 00:00:00
8982	24	2026-03-21 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-21 00:00:00
8983	25	2026-03-21 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-21 00:00:00
8984	30	2026-03-21 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-21 00:00:00
8985	31	2026-03-21 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-21 00:00:00
8986	34	2026-03-21 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-21 00:00:00
8987	38	2026-03-21 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-21 00:00:00
8988	39	2026-03-21 00:00:00	28	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-21 00:00:00
8989	155	2026-03-21 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-21 00:00:00
8990	41	2026-03-21 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-21 00:00:00
8991	42	2026-03-21 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-21 00:00:00
8992	44	2026-03-21 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-21 00:00:00
8993	45	2026-03-21 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-21 00:00:00
8994	46	2026-03-21 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-21 00:00:00
8995	47	2026-03-21 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-21 00:00:00
8996	156	2026-03-21 00:00:00	18	18	35.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-21 00:00:00
8997	48	2026-03-21 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-21 00:00:00
8998	49	2026-03-21 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-21 00:00:00
8999	51	2026-03-21 00:00:00	12	14	23.7km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-21 00:00:00
9000	53	2026-03-21 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-21 00:00:00
9001	54	2026-03-21 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-21 00:00:00
9002	55	2026-03-21 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-21 00:00:00
9003	56	2026-03-21 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-21 00:00:00
9004	57	2026-03-21 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-21 00:00:00
9005	58	2026-03-21 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-21 00:00:00
9006	59	2026-03-21 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-21 00:00:00
9007	61	2026-03-21 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-21 00:00:00
9008	64	2026-03-21 00:00:00	17	21	71.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-21 00:00:00
9009	65	2026-03-21 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-21 00:00:00
9010	66	2026-03-21 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-21 00:00:00
9011	67	2026-03-21 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-21 00:00:00
9012	69	2026-03-21 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-21 00:00:00
9013	70	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-21 00:00:00
9014	71	2026-03-21 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-21 00:00:00
9015	72	2026-03-21 00:00:00	28	30	95.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-21 00:00:00
9016	73	2026-03-21 00:00:00	18	21	49.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-21 00:00:00
9017	74	2026-03-21 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-21 00:00:00
9018	78	2026-03-21 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-21 00:00:00
9019	79	2026-03-21 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-21 00:00:00
9020	80	2026-03-21 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-21 00:00:00
9021	81	2026-03-21 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-21 00:00:00
9022	82	2026-03-21 00:00:00	10	16	41.95km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-21 00:00:00
9023	83	2026-03-21 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-21 00:00:00
9024	85	2026-03-21 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-21 00:00:00
9025	90	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-21 00:00:00
9026	91	2026-03-21 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-21 00:00:00
9027	92	2026-03-21 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-21 00:00:00
9028	94	2026-03-21 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-21 00:00:00
9029	95	2026-03-21 00:00:00	9	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-21 00:00:00
9030	96	2026-03-21 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-21 00:00:00
9031	97	2026-03-21 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-21 00:00:00
9032	98	2026-03-21 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-21 00:00:00
9033	99	2026-03-21 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-21 00:00:00
9034	100	2026-03-21 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-21 00:00:00
9035	101	2026-03-21 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-21 00:00:00
9036	102	2026-03-21 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-21 00:00:00
9037	103	2026-03-21 00:00:00	18	64	46.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-21 00:00:00
9038	62	2026-03-21 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-21 00:00:00
9039	107	2026-03-21 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-21 00:00:00
9040	108	2026-03-21 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-21 00:00:00
9041	6	2026-03-21 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-21 00:00:00
9042	109	2026-03-21 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-21 00:00:00
9043	13	2026-03-21 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-21 00:00:00
9044	110	2026-03-21 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-21 00:00:00
9045	14	2026-03-21 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-21 00:00:00
9046	111	2026-03-21 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-21 00:00:00
9047	21	2026-03-21 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-21 00:00:00
9048	153	2026-03-21 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-21 00:00:00
9049	112	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-21 00:00:00
9050	23	2026-03-21 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-21 00:00:00
9051	113	2026-03-21 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-21 00:00:00
9052	114	2026-03-21 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-21 00:00:00
9053	115	2026-03-21 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-21 00:00:00
9054	26	2026-03-21 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-21 00:00:00
9055	116	2026-03-21 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-21 00:00:00
9056	27	2026-03-21 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-21 00:00:00
9057	28	2026-03-21 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-21 00:00:00
9058	117	2026-03-21 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-21 00:00:00
9059	29	2026-03-21 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-21 00:00:00
9060	118	2026-03-21 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-21 00:00:00
9061	119	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-21 00:00:00
9062	32	2026-03-21 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-21 00:00:00
9063	33	2026-03-21 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-21 00:00:00
9064	120	2026-03-21 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-21 00:00:00
9065	35	2026-03-21 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-21 00:00:00
9066	121	2026-03-21 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-21 00:00:00
9067	36	2026-03-21 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-21 00:00:00
9068	122	2026-03-21 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-21 00:00:00
9069	123	2026-03-21 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-21 00:00:00
9070	37	2026-03-21 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-21 00:00:00
9071	124	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-21 00:00:00
9072	125	2026-03-21 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-21 00:00:00
9073	126	2026-03-21 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-21 00:00:00
9074	40	2026-03-21 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-21 00:00:00
9075	127	2026-03-21 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-21 00:00:00
9076	128	2026-03-21 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-21 00:00:00
9077	43	2026-03-21 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-21 00:00:00
9078	129	2026-03-21 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-21 00:00:00
9079	130	2026-03-21 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-21 00:00:00
9080	131	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-21 00:00:00
9081	132	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-21 00:00:00
9082	133	2026-03-21 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-21 00:00:00
9083	50	2026-03-21 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-21 00:00:00
9084	134	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-21 00:00:00
9085	135	2026-03-21 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-21 00:00:00
9086	137	2026-03-21 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-21 00:00:00
9087	52	2026-03-21 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-21 00:00:00
9088	138	2026-03-21 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-21 00:00:00
9089	139	2026-03-21 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-21 00:00:00
9090	140	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-21 00:00:00
9091	141	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-21 00:00:00
9092	60	2026-03-21 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-21 00:00:00
9093	63	2026-03-21 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-21 00:00:00
9094	142	2026-03-21 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-21 00:00:00
9095	143	2026-03-21 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-21 00:00:00
9096	144	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-21 00:00:00
9097	68	2026-03-21 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-21 00:00:00
9098	104	2026-03-21 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-21 00:00:00
9099	145	2026-03-21 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-21 00:00:00
9100	146	2026-03-21 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-21 00:00:00
9101	147	2026-03-21 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-21 00:00:00
9102	75	2026-03-21 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-21 00:00:00
9103	76	2026-03-21 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-21 00:00:00
9104	77	2026-03-21 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-21 00:00:00
9105	148	2026-03-21 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-21 00:00:00
9106	105	2026-03-21 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-21 00:00:00
9107	154	2026-03-21 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-21 00:00:00
9108	84	2026-03-21 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-21 00:00:00
9109	149	2026-03-21 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-21 00:00:00
9110	86	2026-03-21 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-21 00:00:00
9111	150	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-21 00:00:00
9112	88	2026-03-21 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-21 00:00:00
9113	106	2026-03-21 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-21 00:00:00
9114	151	2026-03-21 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-21 00:00:00
9115	93	2026-03-21 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-21 00:00:00
9116	152	2026-03-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-21 00:00:00
11053	48	2026-04-11 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-04-11 07:42:04.497
11054	133	2026-04-11 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-04-11 07:42:05.019
11055	50	2026-04-11 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-04-11 07:42:05.542
11056	134	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-04-11 07:42:06.065
11057	135	2026-04-11 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-04-11 07:42:06.587
11058	51	2026-04-11 00:00:00	6	14	5.5km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-04-11 07:42:07.108
11059	137	2026-04-11 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-04-11 07:42:07.63
11060	52	2026-04-11 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-04-11 07:42:08.152
11061	53	2026-04-11 00:00:00	0	13	0km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-04-11 07:42:08.675
11062	103	2026-04-11 00:00:00	7	64	18.85km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-04-11 07:42:09.197
11063	138	2026-04-11 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-04-11 07:42:09.719
11064	57	2026-04-11 00:00:00	0	27	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-04-11 07:42:10.243
11065	139	2026-04-11 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-04-11 07:42:10.764
3673	113	2026-03-10 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-10 00:00:00
3674	113	2026-03-11 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-11 00:00:00
3675	113	2026-03-12 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-12 00:00:00
3676	113	2026-03-13 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-13 00:00:00
3677	113	2026-03-14 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-14 00:00:00
3678	113	2026-03-15 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-15 00:00:00
3679	113	2026-03-16 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-16 00:00:00
11067	140	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-04-11 07:42:11.811
9119	3	2026-03-22 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-22 16:31:24.202
9120	4	2026-03-22 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-22 16:31:24.273
9122	7	2026-03-22 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-22 16:31:24.311
9123	8	2026-03-22 00:00:00	26	31	66.9km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-22 16:31:24.354
9124	9	2026-03-22 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-22 16:31:24.396
9125	10	2026-03-22 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-22 16:31:24.428
9126	11	2026-03-22 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-22 16:31:24.457
9127	12	2026-03-22 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-22 16:31:24.488
9128	15	2026-03-22 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-22 16:31:24.518
9129	16	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-22 16:31:24.546
9130	17	2026-03-22 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-22 16:31:24.576
9131	18	2026-03-22 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-22 16:31:24.606
9132	19	2026-03-22 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-22 16:31:24.631
9133	20	2026-03-22 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-22 16:31:24.659
9134	22	2026-03-22 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-22 16:31:24.689
9135	24	2026-03-22 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-22 16:31:24.721
9136	25	2026-03-22 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-22 16:31:24.749
9138	31	2026-03-22 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-22 16:31:24.813
9139	34	2026-03-22 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-22 16:31:24.843
9140	38	2026-03-22 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-22 16:31:24.872
9141	39	2026-03-22 00:00:00	28	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-22 16:31:24.9
9142	155	2026-03-22 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-22 16:31:24.928
9143	41	2026-03-22 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-22 16:31:24.956
9144	42	2026-03-22 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-22 16:31:24.981
9145	44	2026-03-22 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-22 16:31:25.013
9146	45	2026-03-22 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-22 16:31:25.043
9147	46	2026-03-22 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-22 16:31:25.069
9148	47	2026-03-22 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-22 16:31:25.099
9149	156	2026-03-22 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-22 16:31:25.131
9150	48	2026-03-22 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-22 16:31:25.161
9151	49	2026-03-22 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-22 16:31:25.19
9152	51	2026-03-22 00:00:00	12	14	23.7km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-22 16:31:25.222
9153	53	2026-03-22 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-22 16:31:25.25
9154	54	2026-03-22 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-22 16:31:25.284
9155	55	2026-03-22 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-22 16:31:25.312
9156	56	2026-03-22 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-22 16:31:25.339
9157	57	2026-03-22 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-22 16:31:25.368
9159	59	2026-03-22 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-22 16:31:25.399
9161	64	2026-03-22 00:00:00	17	21	71.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-22 16:31:25.454
9117	1	2026-03-22 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-22 16:31:26.354
9121	5	2026-03-22 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-22 16:31:26.454
9158	58	2026-03-22 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-22 16:31:27.962
9163	66	2026-03-22 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-22 16:31:25.514
9164	67	2026-03-22 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-22 16:31:25.545
9165	69	2026-03-22 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-22 16:31:25.578
9166	70	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-22 16:31:25.611
3681	113	2026-03-18 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-18 00:00:00
3682	113	2026-03-19 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-19 00:00:00
9167	71	2026-03-22 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-22 16:31:25.642
9168	72	2026-03-22 00:00:00	28	30	95.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-22 16:31:25.674
9169	73	2026-03-22 00:00:00	18	21	49.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-22 16:31:25.704
9170	74	2026-03-22 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-22 16:31:25.734
9171	78	2026-03-22 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-22 16:31:25.763
9172	79	2026-03-22 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-22 16:31:25.796
9173	80	2026-03-22 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-22 16:31:25.827
9174	81	2026-03-22 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-22 16:31:25.855
9175	82	2026-03-22 00:00:00	9	16	26.95km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-22 16:31:25.882
9176	83	2026-03-22 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-22 16:31:25.912
9177	85	2026-03-22 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-22 16:31:25.942
9178	90	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-22 16:31:25.974
9179	91	2026-03-22 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-22 16:31:26.002
9181	94	2026-03-22 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-22 16:31:26.03
9182	95	2026-03-22 00:00:00	8	16	28km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-22 16:31:26.063
9183	96	2026-03-22 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-22 16:31:26.091
9184	97	2026-03-22 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-22 16:31:26.121
9185	98	2026-03-22 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-22 16:31:26.151
9186	99	2026-03-22 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-22 16:31:26.183
9188	101	2026-03-22 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-22 16:31:26.237
9189	102	2026-03-22 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-22 16:31:26.267
9190	103	2026-03-22 00:00:00	33	64	83.57km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-22 16:31:26.298
9191	62	2026-03-22 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-22 16:31:26.327
9192	107	2026-03-22 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-22 16:31:26.387
9193	108	2026-03-22 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-22 16:31:26.42
9194	6	2026-03-22 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-22 16:31:26.485
9195	109	2026-03-22 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-22 16:31:26.52
9196	13	2026-03-22 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-22 16:31:26.553
9197	110	2026-03-22 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-22 16:31:26.587
9198	14	2026-03-22 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-22 16:31:26.62
9199	111	2026-03-22 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-22 16:31:26.656
9200	21	2026-03-22 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-22 16:31:26.69
9201	153	2026-03-22 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-22 16:31:26.722
9202	112	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-22 16:31:26.756
9203	23	2026-03-22 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-22 16:31:26.786
9204	113	2026-03-22 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-22 16:31:26.817
9205	114	2026-03-22 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-22 16:31:26.855
9206	115	2026-03-22 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-22 16:31:26.888
9207	26	2026-03-22 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-22 16:31:26.916
9208	116	2026-03-22 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-22 16:31:26.943
9209	27	2026-03-22 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-22 16:31:26.972
9210	28	2026-03-22 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-22 16:31:26.999
9180	92	2026-03-22 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-22 16:31:28.747
9212	29	2026-03-22 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-22 16:31:27.055
9213	118	2026-03-22 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-22 16:31:27.084
9214	119	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-22 16:31:27.111
9215	32	2026-03-22 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-22 16:31:27.138
9216	33	2026-03-22 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-22 16:31:27.168
9217	120	2026-03-22 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-22 16:31:27.198
9218	35	2026-03-22 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-22 16:31:27.224
9219	121	2026-03-22 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-22 16:31:27.252
9220	36	2026-03-22 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-22 16:31:27.278
9221	122	2026-03-22 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-22 16:31:27.308
9222	123	2026-03-22 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-22 16:31:27.338
9223	37	2026-03-22 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-22 16:31:27.367
9224	124	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-22 16:31:27.393
9225	125	2026-03-22 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-22 16:31:27.418
9226	126	2026-03-22 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-22 16:31:27.457
9227	40	2026-03-22 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-22 16:31:27.484
9228	127	2026-03-22 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-22 16:31:27.515
9229	128	2026-03-22 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-22 16:31:27.546
9230	43	2026-03-22 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-22 16:31:27.579
9231	129	2026-03-22 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-22 16:31:27.608
9232	130	2026-03-22 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-22 16:31:27.638
9233	131	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-22 16:31:27.666
9234	132	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-22 16:31:27.696
9235	133	2026-03-22 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-22 16:31:27.724
9237	134	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-22 16:31:27.784
9238	135	2026-03-22 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-22 16:31:27.812
9239	137	2026-03-22 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-22 16:31:27.84
9240	52	2026-03-22 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-22 16:31:27.871
9241	138	2026-03-22 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-22 16:31:27.902
9242	139	2026-03-22 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-22 16:31:27.931
9243	140	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-22 16:31:27.994
9244	141	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-22 16:31:28.024
9245	60	2026-03-22 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-22 16:31:28.053
9246	63	2026-03-22 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-22 16:31:28.083
9247	142	2026-03-22 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-22 16:31:28.115
9248	143	2026-03-22 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-22 16:31:28.148
9249	144	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-22 16:31:28.179
9250	68	2026-03-22 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-22 16:31:28.211
9251	104	2026-03-22 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-22 16:31:28.241
9252	145	2026-03-22 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-22 16:31:28.273
9253	146	2026-03-22 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-22 16:31:28.302
9254	147	2026-03-22 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-22 16:31:28.334
9255	75	2026-03-22 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-22 16:31:28.366
9256	76	2026-03-22 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-22 16:31:28.394
9257	77	2026-03-22 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-22 16:31:28.425
9258	148	2026-03-22 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-22 16:31:28.455
9259	105	2026-03-22 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-22 16:31:28.486
9260	154	2026-03-22 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-22 16:31:28.518
9261	84	2026-03-22 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-22 16:31:28.548
9262	149	2026-03-22 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-22 16:31:28.578
9263	86	2026-03-22 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-22 16:31:28.603
9264	150	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-22 16:31:28.632
9265	88	2026-03-22 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-22 16:31:28.663
9266	106	2026-03-22 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-22 16:31:28.689
9267	151	2026-03-22 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-22 16:31:28.717
9268	93	2026-03-22 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-22 16:31:28.778
9269	152	2026-03-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-22 16:31:28.81
11071	62	2026-04-11 00:00:00	0	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-04-11 07:42:13.905
11072	63	2026-04-11 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-04-11 07:42:14.426
11073	142	2026-04-11 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-04-11 07:42:14.948
11074	64	2026-04-11 00:00:00	0	21	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-04-11 07:42:15.47
11075	65	2026-04-11 00:00:00	0	22	0km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-04-11 07:42:15.991
11076	143	2026-04-11 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-04-11 07:42:16.513
11077	144	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-04-11 07:42:17.037
11078	67	2026-04-11 00:00:00	0	12	0km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-04-11 07:42:17.559
11079	68	2026-04-11 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-04-11 07:42:18.079
11080	69	2026-04-11 00:00:00	0	12	0km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-11 07:42:18.601
11081	104	2026-04-11 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-04-11 07:42:19.122
11082	145	2026-04-11 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-04-11 07:42:19.643
11083	146	2026-04-11 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-04-11 07:42:20.165
11084	70	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-04-11 07:42:20.687
11085	71	2026-04-11 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-04-11 07:42:21.208
11086	72	2026-04-11 00:00:00	0	30	0km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-04-11 07:42:21.73
11087	147	2026-04-11 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-04-11 07:42:22.251
11088	73	2026-04-11 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-04-11 07:42:22.773
11089	74	2026-04-11 00:00:00	0	6	0km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-04-11 07:42:23.295
11090	75	2026-04-11 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-04-11 07:42:23.816
11091	76	2026-04-11 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-04-11 07:42:24.338
11092	77	2026-04-11 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-04-11 07:42:24.859
11093	148	2026-04-11 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-04-11 07:42:25.38
11094	105	2026-04-11 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-04-11 07:42:25.902
11095	78	2026-04-11 00:00:00	0	28	0km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-04-11 07:42:26.424
11096	82	2026-04-11 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-04-11 07:42:26.947
11097	154	2026-04-11 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-04-11 07:42:27.469
11098	84	2026-04-11 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-04-11 07:42:27.99
11099	149	2026-04-11 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-04-11 07:42:28.511
11100	86	2026-04-11 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-04-11 07:42:29.033
11101	150	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-04-11 07:42:29.555
11102	88	2026-04-11 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-04-11 07:42:30.076
11103	106	2026-04-11 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-04-11 07:42:30.598
11104	151	2026-04-11 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-04-11 07:42:31.12
11105	92	2026-04-11 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-04-11 07:42:31.641
11106	93	2026-04-11 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-04-11 07:42:32.162
11107	95	2026-04-11 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-04-11 07:42:32.685
11108	152	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-04-11 07:42:33.206
11109	96	2026-04-11 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-04-11 07:42:33.728
11110	97	2026-04-11 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-04-11 07:42:34.249
9118	2	2026-03-22 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-22 16:31:24.146
9137	30	2026-03-22 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-22 16:31:24.783
9160	61	2026-03-22 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-22 16:31:25.428
9162	65	2026-03-22 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-22 16:31:25.482
9187	100	2026-03-22 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-22 16:31:26.209
9211	117	2026-03-22 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-22 16:31:27.025
9236	50	2026-03-22 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-22 16:31:27.754
10962	19	2026-04-11 00:00:00	9	16	26.6km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-04-11 07:41:16.974
10984	100	2026-04-11 00:00:00	0	38	0km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-04-11 07:41:28.476
11023	29	2026-04-11 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-04-11 07:41:48.839
11034	123	2026-04-11 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-04-11 07:41:54.581
11052	132	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-04-11 07:42:03.975
11066	58	2026-04-11 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-04-11 07:42:11.286
11068	141	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-04-11 07:42:12.336
11069	59	2026-04-11 00:00:00	0	27	0km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-04-11 07:42:12.858
11070	60	2026-04-11 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-04-11 07:42:13.383
9270	2	2026-03-23 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-23 11:36:32.345
9271	3	2026-03-23 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-23 11:36:32.982
9272	4	2026-03-23 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-23 11:36:33.594
9273	8	2026-03-23 00:00:00	27	31	67.2km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-23 11:36:34.204
9274	9	2026-03-23 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-23 11:36:34.811
9275	10	2026-03-23 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-23 11:36:35.416
9276	11	2026-03-23 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-23 11:36:36.023
9277	12	2026-03-23 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-23 11:36:36.627
9278	15	2026-03-23 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-23 11:36:37.238
9279	16	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-23 11:36:37.846
9280	17	2026-03-23 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-23 11:36:38.451
9281	18	2026-03-23 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-23 11:36:39.058
9282	19	2026-03-23 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-23 11:36:39.663
9283	20	2026-03-23 00:00:00	24	25	82.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-23 11:36:40.272
9284	22	2026-03-23 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-23 11:36:40.88
9285	24	2026-03-23 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-23 11:36:41.485
9286	25	2026-03-23 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-23 11:36:42.092
9287	30	2026-03-23 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-23 11:36:42.699
9288	31	2026-03-23 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-23 11:36:43.304
9289	34	2026-03-23 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-23 11:36:43.912
9290	38	2026-03-23 00:00:00	14	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-23 11:36:44.517
9291	39	2026-03-23 00:00:00	28	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-23 11:36:45.123
9292	155	2026-03-23 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-23 11:36:45.731
9293	41	2026-03-23 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-23 11:36:46.34
9294	42	2026-03-23 00:00:00	18	22	41.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-23 11:36:46.949
9295	44	2026-03-23 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-23 11:36:47.555
9296	45	2026-03-23 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-23 11:36:48.161
9297	46	2026-03-23 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-23 11:36:48.767
9298	47	2026-03-23 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-23 11:36:49.372
9299	156	2026-03-23 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-23 11:36:49.977
9300	48	2026-03-23 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-23 11:36:50.583
9301	49	2026-03-23 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-23 11:36:51.189
9302	51	2026-03-23 00:00:00	12	14	23.7km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-23 11:36:51.797
9303	53	2026-03-23 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-23 11:36:52.411
9304	54	2026-03-23 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-23 11:36:53.016
9305	55	2026-03-23 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-23 11:36:53.622
9306	56	2026-03-23 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-23 11:36:54.227
9307	57	2026-03-23 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-23 11:36:54.832
9308	59	2026-03-23 00:00:00	24	31	165km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-23 11:36:55.445
9309	61	2026-03-23 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-23 11:36:56.05
9310	64	2026-03-23 00:00:00	9	21	45.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-23 11:36:56.656
9311	65	2026-03-23 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-23 11:36:57.264
9312	66	2026-03-23 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-23 11:36:57.876
3943	114	2026-03-10 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-10 00:00:00
3944	114	2026-03-11 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-11 00:00:00
3945	114	2026-03-12 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-12 00:00:00
3946	114	2026-03-13 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-13 00:00:00
3947	114	2026-03-14 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-14 00:00:00
3948	114	2026-03-15 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-15 00:00:00
3949	114	2026-03-16 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-16 00:00:00
3950	114	2026-03-17 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-17 00:00:00
3951	114	2026-03-18 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-18 00:00:00
3952	114	2026-03-19 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-19 00:00:00
9313	67	2026-03-23 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-23 11:36:58.497
9314	70	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-23 11:36:59.104
9315	71	2026-03-23 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-23 11:36:59.71
9316	72	2026-03-23 00:00:00	27	30	93.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-23 11:37:00.318
9317	73	2026-03-23 00:00:00	18	21	49.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-23 11:37:00.925
9318	74	2026-03-23 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-23 11:37:01.535
9319	78	2026-03-23 00:00:00	16	28	97.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-23 11:37:02.147
9320	79	2026-03-23 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-23 11:37:02.754
9321	80	2026-03-23 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-23 11:37:03.365
9322	81	2026-03-23 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-23 11:37:03.971
9323	83	2026-03-23 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-23 11:37:04.588
9324	85	2026-03-23 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-23 11:37:05.193
9325	90	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-23 11:37:05.798
9326	91	2026-03-23 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-23 11:37:06.409
9327	94	2026-03-23 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-23 11:37:07.017
9328	95	2026-03-23 00:00:00	0	16	0km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-23 11:37:07.623
9329	96	2026-03-23 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-23 11:37:08.228
9330	97	2026-03-23 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-23 11:37:08.834
9331	98	2026-03-23 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-23 11:37:09.446
9332	99	2026-03-23 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-23 11:37:10.059
9333	100	2026-03-23 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-23 11:37:10.668
9334	101	2026-03-23 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-23 11:37:11.276
9335	102	2026-03-23 00:00:00	14	15	30.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-23 11:37:11.882
9336	62	2026-03-23 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-23 11:37:12.49
9337	1	2026-03-23 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-23 11:37:13.099
9338	107	2026-03-23 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-23 11:37:13.706
9339	108	2026-03-23 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-23 11:37:14.313
9340	5	2026-03-23 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-23 11:37:14.921
9341	6	2026-03-23 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-23 11:37:15.527
9342	7	2026-03-23 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-23 11:37:16.134
9343	109	2026-03-23 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-23 11:37:16.741
9344	13	2026-03-23 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-23 11:37:17.347
9345	110	2026-03-23 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-23 11:37:17.953
9346	14	2026-03-23 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-23 11:37:18.559
9347	111	2026-03-23 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-23 11:37:19.168
9348	21	2026-03-23 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-23 11:37:19.779
9349	153	2026-03-23 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-23 11:37:20.387
9350	112	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-23 11:37:20.992
9351	23	2026-03-23 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-23 11:37:21.598
9352	113	2026-03-23 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-23 11:37:22.205
9353	114	2026-03-23 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-23 11:37:22.812
9354	115	2026-03-23 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-23 11:37:23.418
9355	26	2026-03-23 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-23 11:37:24.024
9356	116	2026-03-23 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-23 11:37:24.629
9357	27	2026-03-23 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-23 11:37:25.234
9358	28	2026-03-23 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-23 11:37:25.84
9359	117	2026-03-23 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-23 11:37:26.446
9360	29	2026-03-23 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-23 11:37:27.057
9361	118	2026-03-23 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-23 11:37:27.664
9362	119	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-23 11:37:28.269
9363	32	2026-03-23 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-23 11:37:28.877
9364	33	2026-03-23 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-23 11:37:29.482
9365	120	2026-03-23 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-23 11:37:30.087
9366	35	2026-03-23 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-23 11:37:30.692
9367	121	2026-03-23 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-23 11:37:31.297
9368	36	2026-03-23 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-23 11:37:31.903
9369	123	2026-03-23 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-23 11:37:32.51
9370	122	2026-03-23 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-23 11:37:33.115
9371	37	2026-03-23 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-23 11:37:33.725
9372	124	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-23 11:37:34.334
9373	125	2026-03-23 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-23 11:37:34.939
9374	126	2026-03-23 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-23 11:37:35.545
9375	40	2026-03-23 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-23 11:37:36.151
9376	127	2026-03-23 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-23 11:37:36.762
9377	128	2026-03-23 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-23 11:37:37.369
9378	43	2026-03-23 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-23 11:37:37.975
9379	129	2026-03-23 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-23 11:37:38.581
9380	130	2026-03-23 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-23 11:37:39.189
9381	131	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-23 11:37:39.797
9382	132	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-23 11:37:40.404
9383	133	2026-03-23 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-23 11:37:41.014
9384	50	2026-03-23 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-23 11:37:41.619
9385	134	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-23 11:37:42.226
9386	135	2026-03-23 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-23 11:37:42.833
9387	137	2026-03-23 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-23 11:37:43.441
9388	52	2026-03-23 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-23 11:37:44.049
9389	103	2026-03-23 00:00:00	20	64	51.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-23 11:37:44.655
9390	138	2026-03-23 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-23 11:37:45.261
9391	139	2026-03-23 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-23 11:37:45.867
9392	58	2026-03-23 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-23 11:37:46.472
9393	140	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-23 11:37:47.078
9394	141	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-23 11:37:47.684
9395	60	2026-03-23 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-23 11:37:48.289
9396	63	2026-03-23 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-23 11:37:48.895
9397	142	2026-03-23 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-23 11:37:49.502
9398	143	2026-03-23 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-23 11:37:50.109
9399	144	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-23 11:37:50.715
9400	68	2026-03-23 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-23 11:37:51.324
9401	104	2026-03-23 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-23 11:37:51.931
9402	145	2026-03-23 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-23 11:37:52.539
9403	146	2026-03-23 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-23 11:37:53.145
9404	147	2026-03-23 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-23 11:37:53.751
9405	75	2026-03-23 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-23 11:37:54.359
9406	76	2026-03-23 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-23 11:37:54.965
9407	77	2026-03-23 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-23 11:37:55.573
9408	148	2026-03-23 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-23 11:37:56.18
9409	105	2026-03-23 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-23 11:37:56.787
9410	82	2026-03-23 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-23 11:37:57.393
9411	154	2026-03-23 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-23 11:37:58
9412	84	2026-03-23 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-23 11:37:58.606
9413	149	2026-03-23 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-23 11:37:59.211
9414	86	2026-03-23 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-23 11:37:59.817
9415	150	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-23 11:38:00.424
9416	88	2026-03-23 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-23 11:38:01.03
9417	106	2026-03-23 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-23 11:38:01.637
9418	151	2026-03-23 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-23 11:38:02.246
9419	92	2026-03-23 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-23 11:38:02.853
9420	93	2026-03-23 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-23 11:38:03.46
9421	152	2026-03-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-23 11:38:04.066
9422	2	2026-03-24 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-24 11:37:12.347
9423	3	2026-03-24 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-24 11:37:12.809
9424	8	2026-03-24 00:00:00	26	31	66.9km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-24 11:37:13.258
9425	9	2026-03-24 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-24 11:37:13.701
9426	10	2026-03-24 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-24 11:37:14.142
9427	11	2026-03-24 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-24 11:37:14.584
9428	12	2026-03-24 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-24 11:37:15.023
9429	15	2026-03-24 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-24 11:37:15.464
9430	16	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-24 11:37:15.907
9431	17	2026-03-24 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-24 11:37:16.348
9432	18	2026-03-24 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-24 11:37:16.787
9433	19	2026-03-24 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-24 11:37:17.226
9434	20	2026-03-24 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-24 11:37:17.667
9435	22	2026-03-24 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-24 11:37:18.108
9436	24	2026-03-24 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-24 11:37:18.547
9437	25	2026-03-24 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-24 11:37:18.986
9438	30	2026-03-24 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-24 11:37:19.428
9439	31	2026-03-24 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-24 11:37:19.867
9440	34	2026-03-24 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-24 11:37:20.308
9441	38	2026-03-24 00:00:00	14	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-24 11:37:20.748
9442	39	2026-03-24 00:00:00	28	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-24 11:37:21.19
9443	155	2026-03-24 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-24 11:37:21.632
9444	41	2026-03-24 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-24 11:37:22.072
9445	42	2026-03-24 00:00:00	18	22	41.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-24 11:37:22.512
9446	44	2026-03-24 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-24 11:37:22.954
9447	45	2026-03-24 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-24 11:37:23.393
9448	46	2026-03-24 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-24 11:37:23.834
9449	47	2026-03-24 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-24 11:37:24.273
9450	156	2026-03-24 00:00:00	14	18	29.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-24 11:37:24.712
9451	49	2026-03-24 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-24 11:37:25.152
9452	51	2026-03-24 00:00:00	12	14	23.7km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-24 11:37:25.594
9453	53	2026-03-24 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-24 11:37:26.035
9454	54	2026-03-24 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-24 11:37:26.477
9455	55	2026-03-24 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-24 11:37:26.916
9456	56	2026-03-24 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-24 11:37:27.357
9457	57	2026-03-24 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-24 11:37:27.797
9458	59	2026-03-24 00:00:00	24	31	165km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-24 11:37:28.237
9459	61	2026-03-24 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-24 11:37:28.677
9460	64	2026-03-24 00:00:00	15	21	68.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-24 11:37:29.117
9461	65	2026-03-24 00:00:00	17	22	70.1km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-24 11:37:29.556
9462	66	2026-03-24 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-24 11:37:29.996
9463	67	2026-03-24 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-24 11:37:30.435
9464	70	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-24 11:37:30.876
9465	72	2026-03-24 00:00:00	28	30	97.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-24 11:37:31.315
9466	74	2026-03-24 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-24 11:37:31.756
9467	78	2026-03-24 00:00:00	17	28	100.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-24 11:37:32.195
9468	79	2026-03-24 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-24 11:37:32.639
9469	80	2026-03-24 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-24 11:37:33.078
9470	81	2026-03-24 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-24 11:37:33.518
9471	83	2026-03-24 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-24 11:37:33.959
9472	85	2026-03-24 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-24 11:37:34.399
9473	90	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-24 11:37:34.841
9474	91	2026-03-24 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-24 11:37:35.282
9475	94	2026-03-24 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-24 11:37:35.728
9476	95	2026-03-24 00:00:00	0	16	0km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-24 11:37:36.171
9477	97	2026-03-24 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-24 11:37:36.612
9478	98	2026-03-24 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-24 11:37:37.052
9479	99	2026-03-24 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-24 11:37:37.492
9480	100	2026-03-24 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-24 11:37:37.939
9481	101	2026-03-24 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-24 11:37:38.383
9482	102	2026-03-24 00:00:00	14	15	30.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-24 11:37:38.823
9483	62	2026-03-24 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-24 11:37:39.261
4213	115	2026-02-25 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-02-25 00:00:00
4214	115	2026-02-26 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-02-26 00:00:00
4215	115	2026-02-27 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-02-27 00:00:00
4216	115	2026-02-28 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-02-28 00:00:00
4217	115	2026-03-01 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-01 00:00:00
4218	115	2026-03-02 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-02 00:00:00
4219	115	2026-03-03 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-03 00:00:00
4220	115	2026-03-04 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-04 00:00:00
4221	115	2026-03-05 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-05 00:00:00
4222	115	2026-03-06 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-06 00:00:00
4223	115	2026-03-07 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-07 00:00:00
9484	1	2026-03-24 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-24 11:37:39.7
9485	4	2026-03-24 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-24 11:37:40.14
9486	107	2026-03-24 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-24 11:37:40.58
9487	108	2026-03-24 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-24 11:37:41.019
9488	5	2026-03-24 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-24 11:37:41.459
9489	6	2026-03-24 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-24 11:37:41.899
9490	7	2026-03-24 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-24 11:37:42.338
9491	109	2026-03-24 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-24 11:37:42.778
9492	13	2026-03-24 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-24 11:37:43.218
9493	110	2026-03-24 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-24 11:37:43.657
9494	14	2026-03-24 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-24 11:37:44.096
9495	111	2026-03-24 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-24 11:37:44.535
9496	21	2026-03-24 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-24 11:37:44.975
9497	153	2026-03-24 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-24 11:37:45.414
9498	112	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-24 11:37:45.854
9499	23	2026-03-24 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-24 11:37:46.293
9500	113	2026-03-24 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-24 11:37:46.733
9501	114	2026-03-24 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-24 11:37:47.174
4225	116	2026-03-10 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-10 00:00:00
4226	116	2026-03-11 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-11 00:00:00
4227	116	2026-03-12 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-12 00:00:00
4228	116	2026-03-13 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-13 00:00:00
4229	116	2026-03-14 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-14 00:00:00
4230	116	2026-03-15 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-15 00:00:00
4231	116	2026-03-16 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-16 00:00:00
4232	116	2026-03-17 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-17 00:00:00
4233	116	2026-03-18 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-18 00:00:00
4234	116	2026-03-19 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-19 00:00:00
9502	115	2026-03-24 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-24 11:37:47.614
9503	26	2026-03-24 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-24 11:37:48.056
9504	116	2026-03-24 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-24 11:37:48.496
9505	27	2026-03-24 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-24 11:37:48.936
9506	28	2026-03-24 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-24 11:37:49.375
9507	117	2026-03-24 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-24 11:37:49.815
9508	29	2026-03-24 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-24 11:37:50.257
9509	118	2026-03-24 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-24 11:37:50.696
9510	119	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-24 11:37:51.137
9511	32	2026-03-24 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-24 11:37:51.576
9512	33	2026-03-24 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-24 11:37:52.015
9513	120	2026-03-24 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-24 11:37:52.456
9514	35	2026-03-24 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-24 11:37:52.895
9515	121	2026-03-24 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-24 11:37:53.335
9516	36	2026-03-24 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-24 11:37:53.775
9517	122	2026-03-24 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-24 11:37:54.215
9518	123	2026-03-24 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-24 11:37:54.654
9519	37	2026-03-24 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-24 11:37:55.093
9520	124	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-24 11:37:55.534
9521	125	2026-03-24 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-24 11:37:55.974
9522	126	2026-03-24 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-24 11:37:56.414
9523	40	2026-03-24 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-24 11:37:56.853
9524	127	2026-03-24 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-24 11:37:57.294
9525	128	2026-03-24 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-24 11:37:57.734
9526	43	2026-03-24 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-24 11:37:58.173
9527	129	2026-03-24 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-24 11:37:58.614
9528	130	2026-03-24 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-24 11:37:59.056
9529	131	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-24 11:37:59.497
9530	132	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-24 11:37:59.938
9531	48	2026-03-24 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-24 11:38:00.377
9532	133	2026-03-24 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-24 11:38:00.818
9533	50	2026-03-24 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-24 11:38:01.261
9534	134	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-24 11:38:01.701
9535	135	2026-03-24 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-24 11:38:02.14
9536	137	2026-03-24 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-24 11:38:02.585
9537	52	2026-03-24 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-24 11:38:03.025
9538	103	2026-03-24 00:00:00	16	64	36.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-24 11:38:03.464
9539	138	2026-03-24 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-24 11:38:03.903
9540	139	2026-03-24 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-24 11:38:04.35
9541	58	2026-03-24 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-24 11:38:04.789
9542	140	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-24 11:38:05.229
9543	141	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-24 11:38:05.669
9544	60	2026-03-24 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-24 11:38:06.108
9545	63	2026-03-24 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-24 11:38:06.551
9546	142	2026-03-24 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-24 11:38:06.992
9547	143	2026-03-24 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-24 11:38:07.433
9548	144	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-24 11:38:07.874
9549	68	2026-03-24 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-24 11:38:08.313
9550	104	2026-03-24 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-24 11:38:08.751
9551	145	2026-03-24 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-24 11:38:09.193
9552	146	2026-03-24 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-24 11:38:09.632
9553	71	2026-03-24 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-24 11:38:10.071
9554	147	2026-03-24 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-24 11:38:10.512
9555	73	2026-03-24 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-24 11:38:10.952
9556	75	2026-03-24 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-24 11:38:11.398
9557	76	2026-03-24 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-24 11:38:11.838
9558	77	2026-03-24 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-24 11:38:12.277
9559	148	2026-03-24 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-24 11:38:12.717
9560	105	2026-03-24 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-24 11:38:13.158
9561	82	2026-03-24 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-24 11:38:13.6
9562	154	2026-03-24 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-24 11:38:14.039
9563	84	2026-03-24 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-24 11:38:14.479
9564	149	2026-03-24 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-24 11:38:14.918
9565	86	2026-03-24 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-24 11:38:15.356
9566	150	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-24 11:38:15.797
9567	88	2026-03-24 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-24 11:38:16.238
9568	106	2026-03-24 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-24 11:38:16.678
9569	151	2026-03-24 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-24 11:38:17.117
9570	92	2026-03-24 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-24 11:38:17.555
9571	93	2026-03-24 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-24 11:38:17.994
9572	152	2026-03-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-24 11:38:18.433
9573	96	2026-03-24 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-24 11:38:18.872
9574	2	2026-03-25 00:00:00	3	9	20km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-25 11:33:47.488
9575	3	2026-03-25 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-25 11:33:48.043
9576	8	2026-03-25 00:00:00	26	31	66.9km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-25 11:33:48.586
9577	9	2026-03-25 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-25 11:33:49.186
9578	10	2026-03-25 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-25 11:33:49.722
9579	11	2026-03-25 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-25 11:33:50.257
9580	12	2026-03-25 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-25 11:33:50.793
9581	15	2026-03-25 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-25 11:33:51.329
9582	16	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-25 11:33:51.865
9583	17	2026-03-25 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-25 11:33:52.401
9584	18	2026-03-25 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-25 11:33:52.935
9585	19	2026-03-25 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-25 11:33:53.471
9586	20	2026-03-25 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-25 11:33:54.005
9587	22	2026-03-25 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-25 11:33:54.54
9588	24	2026-03-25 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-25 11:33:55.075
9589	25	2026-03-25 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-25 11:33:55.608
9590	30	2026-03-25 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-25 11:33:56.145
9591	31	2026-03-25 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-25 11:33:56.679
9592	34	2026-03-25 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-25 11:33:57.213
9593	38	2026-03-25 00:00:00	14	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-25 11:33:57.749
9594	39	2026-03-25 00:00:00	21	74	131.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-25 11:33:58.284
9595	155	2026-03-25 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-25 11:33:58.819
9596	41	2026-03-25 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-25 11:33:59.353
9597	42	2026-03-25 00:00:00	17	22	40.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-25 11:33:59.887
9598	44	2026-03-25 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-25 11:34:00.424
9599	45	2026-03-25 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-25 11:34:00.961
9600	46	2026-03-25 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-25 11:34:01.496
9601	47	2026-03-25 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-25 11:34:02.032
9602	156	2026-03-25 00:00:00	13	18	28.85km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-25 11:34:02.566
9603	49	2026-03-25 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-25 11:34:03.1
9604	51	2026-03-25 00:00:00	12	14	23.7km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-25 11:34:03.637
9605	53	2026-03-25 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-25 11:34:04.174
9606	54	2026-03-25 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-25 11:34:04.708
9607	55	2026-03-25 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-25 11:34:05.243
9608	56	2026-03-25 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-25 11:34:05.778
9609	57	2026-03-25 00:00:00	21	27	63.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-25 11:34:06.312
9610	59	2026-03-25 00:00:00	24	31	165km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-25 11:34:06.847
9611	61	2026-03-25 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-25 11:34:07.382
9612	64	2026-03-25 00:00:00	15	21	68.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-25 11:34:07.916
9613	65	2026-03-25 00:00:00	17	22	70.1km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-25 11:34:08.452
9614	66	2026-03-25 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-25 11:34:08.988
9615	67	2026-03-25 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-25 11:34:09.522
9616	70	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-25 11:34:10.064
9617	72	2026-03-25 00:00:00	28	30	97.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-25 11:34:10.6
9618	74	2026-03-25 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-25 11:34:11.136
9619	78	2026-03-25 00:00:00	14	28	93.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-25 11:34:11.671
9620	79	2026-03-25 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-25 11:34:12.209
9621	80	2026-03-25 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-25 11:34:12.745
9622	81	2026-03-25 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-25 11:34:13.281
9623	83	2026-03-25 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-25 11:34:13.816
9624	85	2026-03-25 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-25 11:34:14.351
9625	90	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-25 11:34:14.886
9626	91	2026-03-25 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-25 11:34:15.42
9627	94	2026-03-25 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-25 11:34:15.956
9628	95	2026-03-25 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-25 11:34:16.49
9629	96	2026-03-25 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-25 11:34:17.024
9630	97	2026-03-25 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-25 11:34:17.559
9631	98	2026-03-25 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-25 11:34:18.093
9632	99	2026-03-25 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-25 11:34:18.628
9633	100	2026-03-25 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-25 11:34:19.163
9634	101	2026-03-25 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-25 11:34:19.699
9635	102	2026-03-25 00:00:00	14	15	30.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-25 11:34:20.233
9636	62	2026-03-25 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-25 11:34:20.769
9637	1	2026-03-25 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-25 11:34:21.304
9638	4	2026-03-25 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-25 11:34:21.838
9639	107	2026-03-25 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-25 11:34:22.373
9640	108	2026-03-25 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-25 11:34:22.907
9641	5	2026-03-25 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-25 11:34:23.441
9642	6	2026-03-25 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-25 11:34:23.977
9643	7	2026-03-25 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-25 11:34:24.512
9644	109	2026-03-25 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-25 11:34:25.046
9645	13	2026-03-25 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-25 11:34:25.581
9646	110	2026-03-25 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-25 11:34:26.116
9647	14	2026-03-25 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-25 11:34:26.649
9648	111	2026-03-25 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-25 11:34:27.183
9649	21	2026-03-25 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-25 11:34:27.716
9650	153	2026-03-25 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-25 11:34:28.249
9651	112	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-25 11:34:28.781
9652	23	2026-03-25 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-25 11:34:29.315
9653	113	2026-03-25 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-25 11:34:29.851
9654	114	2026-03-25 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-25 11:34:30.387
9655	115	2026-03-25 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-25 11:34:30.923
9656	26	2026-03-25 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-25 11:34:31.456
9657	116	2026-03-25 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-25 11:34:31.991
9658	27	2026-03-25 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-25 11:34:32.525
9659	28	2026-03-25 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-25 11:34:33.058
9660	117	2026-03-25 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-25 11:34:33.594
9661	29	2026-03-25 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-25 11:34:34.128
9662	118	2026-03-25 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-25 11:34:34.663
9663	119	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-25 11:34:35.196
9664	32	2026-03-25 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-25 11:34:35.73
9665	33	2026-03-25 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-25 11:34:36.263
9666	120	2026-03-25 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-25 11:34:36.797
9667	35	2026-03-25 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-25 11:34:37.331
9668	121	2026-03-25 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-25 11:34:37.865
9669	36	2026-03-25 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-25 11:34:38.399
9670	122	2026-03-25 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-25 11:34:38.933
9671	123	2026-03-25 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-25 11:34:39.467
9672	37	2026-03-25 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-25 11:34:40.001
9673	124	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-25 11:34:40.536
9674	125	2026-03-25 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-25 11:34:41.069
9675	126	2026-03-25 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-25 11:34:41.603
9676	40	2026-03-25 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-25 11:34:42.139
9677	127	2026-03-25 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-25 11:34:42.676
9678	128	2026-03-25 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-25 11:34:43.211
9679	43	2026-03-25 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-25 11:34:43.746
9680	129	2026-03-25 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-25 11:34:44.281
9681	130	2026-03-25 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-25 11:34:44.814
9682	131	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-25 11:34:45.347
9683	132	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-25 11:34:45.88
9684	48	2026-03-25 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-25 11:34:46.415
9685	133	2026-03-25 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-25 11:34:46.95
9686	50	2026-03-25 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-25 11:34:47.483
9687	134	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-25 11:34:48.017
9688	135	2026-03-25 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-25 11:34:48.551
9689	137	2026-03-25 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-25 11:34:49.085
9690	52	2026-03-25 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-25 11:34:49.62
9691	103	2026-03-25 00:00:00	16	64	36.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-25 11:34:50.154
9692	138	2026-03-25 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-25 11:34:50.688
9693	139	2026-03-25 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-25 11:34:51.222
9694	58	2026-03-25 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-25 11:34:51.757
9695	140	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-25 11:34:52.291
9696	141	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-25 11:34:52.827
9697	60	2026-03-25 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-25 11:34:53.36
9698	63	2026-03-25 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-25 11:34:53.893
9699	142	2026-03-25 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-25 11:34:54.428
9700	143	2026-03-25 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-25 11:34:54.964
9701	144	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-25 11:34:55.498
9702	68	2026-03-25 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-25 11:34:56.032
9703	104	2026-03-25 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-25 11:34:56.565
9704	145	2026-03-25 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-25 11:34:57.102
9705	146	2026-03-25 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-25 11:34:57.635
9706	71	2026-03-25 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-25 11:34:58.169
9707	147	2026-03-25 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-25 11:34:58.702
9708	73	2026-03-25 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-25 11:34:59.236
9709	75	2026-03-25 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-25 11:34:59.77
9710	76	2026-03-25 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-25 11:35:00.304
9711	77	2026-03-25 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-25 11:35:00.837
9712	148	2026-03-25 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-25 11:35:01.371
9713	105	2026-03-25 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-25 11:35:01.905
9714	82	2026-03-25 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-25 11:35:02.439
9715	154	2026-03-25 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-25 11:35:02.971
9716	84	2026-03-25 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-25 11:35:03.504
9717	149	2026-03-25 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-25 11:35:04.037
9718	86	2026-03-25 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-25 11:35:04.571
9719	150	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-25 11:35:05.105
9720	88	2026-03-25 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-25 11:35:05.64
9721	106	2026-03-25 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-25 11:35:06.174
9722	151	2026-03-25 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-25 11:35:06.708
9723	92	2026-03-25 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-25 11:35:07.242
9724	93	2026-03-25 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-25 11:35:07.776
9725	152	2026-03-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-25 11:35:08.309
9726	2	2026-03-26 00:00:00	3	9	20km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-26 11:40:58.213
9727	3	2026-03-26 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-26 11:40:58.727
9728	8	2026-03-26 00:00:00	18	31	37.1km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-26 11:40:59.223
9729	9	2026-03-26 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-26 11:40:59.713
9730	11	2026-03-26 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-26 11:41:00.205
9731	12	2026-03-26 00:00:00	5	9	20.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-26 11:41:00.698
9732	15	2026-03-26 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-26 11:41:01.191
9733	16	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-26 11:41:01.681
9734	17	2026-03-26 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-26 11:41:02.172
9735	18	2026-03-26 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-26 11:41:02.661
9736	19	2026-03-26 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-26 11:41:03.151
9737	20	2026-03-26 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-26 11:41:03.642
9738	22	2026-03-26 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-26 11:41:04.132
9739	24	2026-03-26 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-26 11:41:04.622
9740	25	2026-03-26 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-26 11:41:05.112
9741	30	2026-03-26 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-26 11:41:05.602
9742	31	2026-03-26 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-26 11:41:06.094
9743	34	2026-03-26 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-26 11:41:06.591
9744	38	2026-03-26 00:00:00	9	42	14.2km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-26 11:41:07.084
9745	39	2026-03-26 00:00:00	21	74	131.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-26 11:41:07.575
9746	155	2026-03-26 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-26 11:41:08.065
4508	117	2026-02-12 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-12 00:00:00
4509	117	2026-02-13 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-13 00:00:00
4510	117	2026-02-14 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-14 00:00:00
4511	117	2026-02-15 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-15 00:00:00
4512	117	2026-02-16 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-16 00:00:00
4513	117	2026-02-17 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-17 00:00:00
4514	117	2026-02-18 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-18 00:00:00
4515	117	2026-02-19 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-19 00:00:00
4516	117	2026-02-20 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-20 00:00:00
4517	117	2026-02-21 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-21 00:00:00
4518	117	2026-02-22 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-22 00:00:00
4519	117	2026-02-23 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-23 00:00:00
4520	117	2026-02-24 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-24 00:00:00
4521	117	2026-02-25 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-25 00:00:00
4522	117	2026-02-26 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-26 00:00:00
4523	117	2026-02-27 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-27 00:00:00
4524	117	2026-02-28 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-02-28 00:00:00
4525	117	2026-03-01 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-01 00:00:00
4526	117	2026-03-02 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-02 00:00:00
4527	117	2026-03-03 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-03 00:00:00
4528	117	2026-03-04 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-04 00:00:00
4529	117	2026-03-05 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-05 00:00:00
4530	117	2026-03-06 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-06 00:00:00
4531	117	2026-03-07 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-07 00:00:00
9747	42	2026-03-26 00:00:00	16	22	36.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-26 11:41:08.554
4533	118	2026-03-10 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-10 00:00:00
4534	118	2026-03-11 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-11 00:00:00
4535	118	2026-03-12 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-12 00:00:00
4536	118	2026-03-13 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-13 00:00:00
4537	118	2026-03-14 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-14 00:00:00
9748	44	2026-03-26 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-26 11:41:09.046
9749	45	2026-03-26 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-26 11:41:09.535
9750	46	2026-03-26 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-26 11:41:10.025
9751	47	2026-03-26 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-26 11:41:10.514
9752	49	2026-03-26 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-26 11:41:11.004
9753	51	2026-03-26 00:00:00	10	14	20.9km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-26 11:41:11.495
9754	53	2026-03-26 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-26 11:41:11.988
9755	54	2026-03-26 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-26 11:41:12.479
9756	55	2026-03-26 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-26 11:41:12.969
9757	56	2026-03-26 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-26 11:41:13.46
9758	57	2026-03-26 00:00:00	20	27	61.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-26 11:41:13.95
9759	59	2026-03-26 00:00:00	24	31	165km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-26 11:41:14.439
9760	61	2026-03-26 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-26 11:41:14.928
9761	64	2026-03-26 00:00:00	13	21	58.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-26 11:41:15.419
9762	65	2026-03-26 00:00:00	8	22	41km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-26 11:41:15.909
9763	66	2026-03-26 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-26 11:41:16.401
9764	67	2026-03-26 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-26 11:41:16.891
9765	69	2026-03-26 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-26 11:41:17.383
9766	70	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-26 11:41:17.873
9767	72	2026-03-26 00:00:00	28	30	96.6km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-26 11:41:18.364
9768	74	2026-03-26 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-26 11:41:18.853
9769	78	2026-03-26 00:00:00	14	28	93.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-26 11:41:19.342
9770	79	2026-03-26 00:00:00	0	23	0km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-26 11:41:19.832
9771	80	2026-03-26 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-26 11:41:20.322
9772	81	2026-03-26 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-26 11:41:20.812
9773	83	2026-03-26 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-26 11:41:21.303
9774	85	2026-03-26 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-26 11:41:21.792
9775	90	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-26 11:41:22.288
9776	91	2026-03-26 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-26 11:41:22.777
9777	94	2026-03-26 00:00:00	3	5	9.2km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-26 11:41:23.267
9778	95	2026-03-26 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-26 11:41:23.757
9779	97	2026-03-26 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-26 11:41:24.246
9780	98	2026-03-26 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-26 11:41:24.734
9781	99	2026-03-26 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-26 11:41:25.227
9782	100	2026-03-26 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-26 11:41:25.718
9783	101	2026-03-26 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-26 11:41:26.208
9784	156	2026-03-26 00:00:00	13	18	28.85km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-26 11:41:26.697
9785	102	2026-03-26 00:00:00	14	15	30.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-26 11:41:27.187
9786	62	2026-03-26 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-26 11:41:27.676
9787	1	2026-03-26 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-26 11:41:28.165
9788	4	2026-03-26 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-26 11:41:28.653
9789	107	2026-03-26 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-26 11:41:29.146
9790	108	2026-03-26 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-26 11:41:29.635
4592	119	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-10 00:00:00
4593	119	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-11 00:00:00
4594	119	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-12 00:00:00
4595	119	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-13 00:00:00
4596	119	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-14 00:00:00
4538	118	2026-03-15 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-15 00:00:00
4539	118	2026-03-16 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-16 00:00:00
4540	118	2026-03-17 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-17 00:00:00
4541	118	2026-03-18 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-18 00:00:00
4542	118	2026-03-19 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-19 00:00:00
9791	5	2026-03-26 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-26 11:41:30.127
9792	6	2026-03-26 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-26 11:41:30.617
9793	7	2026-03-26 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-26 11:41:31.107
9794	10	2026-03-26 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-26 11:41:31.597
9795	109	2026-03-26 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-26 11:41:32.088
9796	13	2026-03-26 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-26 11:41:32.577
9797	110	2026-03-26 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-26 11:41:33.067
9798	14	2026-03-26 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-26 11:41:33.563
9799	111	2026-03-26 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-26 11:41:34.052
9800	21	2026-03-26 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-26 11:41:34.541
9801	153	2026-03-26 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-26 11:41:35.03
9802	112	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-26 11:41:35.518
9803	23	2026-03-26 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-26 11:41:36.006
9804	113	2026-03-26 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-26 11:41:36.497
9805	114	2026-03-26 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-26 11:41:36.992
9806	115	2026-03-26 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-26 11:41:37.484
9807	26	2026-03-26 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-26 11:41:37.974
9808	116	2026-03-26 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-26 11:41:38.464
9809	27	2026-03-26 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-26 11:41:38.953
9810	28	2026-03-26 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-26 11:41:39.442
9811	117	2026-03-26 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-26 11:41:39.933
9812	29	2026-03-26 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-26 11:41:40.423
9813	118	2026-03-26 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-26 11:41:40.914
9814	119	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-26 11:41:41.403
9815	32	2026-03-26 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-26 11:41:41.894
9816	33	2026-03-26 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-26 11:41:42.383
9817	120	2026-03-26 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-26 11:41:42.873
9818	35	2026-03-26 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-26 11:41:43.364
9819	121	2026-03-26 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-26 11:41:43.854
9820	36	2026-03-26 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-26 11:41:44.344
9821	122	2026-03-26 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-26 11:41:44.833
9822	123	2026-03-26 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-26 11:41:45.323
9823	37	2026-03-26 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-26 11:41:45.813
9824	124	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-26 11:41:46.303
9825	125	2026-03-26 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-26 11:41:46.792
9826	126	2026-03-26 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-26 11:41:47.282
9827	40	2026-03-26 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-26 11:41:47.77
9828	127	2026-03-26 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-26 11:41:48.261
9829	41	2026-03-26 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-26 11:41:48.749
9830	128	2026-03-26 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-26 11:41:49.239
9831	43	2026-03-26 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-26 11:41:49.729
9832	129	2026-03-26 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-26 11:41:50.219
9833	130	2026-03-26 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-26 11:41:50.708
9834	131	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-26 11:41:51.198
9835	132	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-26 11:41:51.688
9836	48	2026-03-26 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-26 11:41:52.177
4599	119	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-17 00:00:00
4600	119	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-18 00:00:00
4601	119	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-19 00:00:00
9837	133	2026-03-26 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-26 11:41:52.666
9838	50	2026-03-26 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-26 11:41:53.156
9839	134	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-26 11:41:53.647
9840	135	2026-03-26 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-26 11:41:54.137
9841	137	2026-03-26 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-26 11:41:54.628
9842	52	2026-03-26 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-26 11:41:55.119
9843	103	2026-03-26 00:00:00	16	64	36.22km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-26 11:41:55.607
9844	138	2026-03-26 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-26 11:41:56.097
9845	139	2026-03-26 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-26 11:41:56.587
9846	58	2026-03-26 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-26 11:41:57.078
9847	140	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-26 11:41:57.569
9848	141	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-26 11:41:58.06
9849	60	2026-03-26 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-26 11:41:58.549
9850	63	2026-03-26 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-26 11:41:59.039
9851	142	2026-03-26 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-26 11:41:59.531
9852	143	2026-03-26 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-26 11:42:00.02
9853	144	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-26 11:42:00.511
9854	68	2026-03-26 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-26 11:42:01
9855	104	2026-03-26 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-26 11:42:01.488
9856	145	2026-03-26 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-26 11:42:01.98
9857	146	2026-03-26 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-26 11:42:02.47
9858	71	2026-03-26 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-26 11:42:02.959
9859	147	2026-03-26 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-26 11:42:03.448
9860	73	2026-03-26 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-26 11:42:03.937
9861	75	2026-03-26 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-26 11:42:04.425
9862	76	2026-03-26 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-26 11:42:04.914
9863	77	2026-03-26 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-26 11:42:05.402
9864	148	2026-03-26 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-26 11:42:05.891
9865	105	2026-03-26 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-26 11:42:06.382
9866	82	2026-03-26 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-26 11:42:06.871
9867	154	2026-03-26 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-26 11:42:07.359
9868	84	2026-03-26 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-26 11:42:07.848
9869	149	2026-03-26 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-26 11:42:08.337
9870	86	2026-03-26 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-26 11:42:08.825
9871	150	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-26 11:42:09.316
9872	88	2026-03-26 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-26 11:42:09.805
9873	106	2026-03-26 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-26 11:42:10.294
9874	151	2026-03-26 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-26 11:42:10.783
9875	92	2026-03-26 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-26 11:42:11.275
9876	93	2026-03-26 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-26 11:42:11.764
9877	152	2026-03-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-26 11:42:12.254
9878	96	2026-03-26 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-26 11:42:12.744
9879	2	2026-03-27 00:00:00	3	9	20km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-27 11:34:02.005
9880	3	2026-03-27 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-27 11:34:02.382
9881	8	2026-03-27 00:00:00	26	31	66.9km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-27 11:34:02.747
9882	9	2026-03-27 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-27 11:34:03.106
9883	11	2026-03-27 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-27 11:34:03.464
9884	12	2026-03-27 00:00:00	5	9	20.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-27 11:34:03.823
9885	15	2026-03-27 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-27 11:34:04.182
9886	16	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-27 11:34:04.539
9887	17	2026-03-27 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-27 11:34:04.896
9888	18	2026-03-27 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-27 11:34:05.255
9889	19	2026-03-27 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-27 11:34:05.611
9890	20	2026-03-27 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-27 11:34:05.968
9891	22	2026-03-27 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-27 11:34:06.326
9892	24	2026-03-27 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-27 11:34:06.685
9893	25	2026-03-27 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-27 11:34:07.043
9894	30	2026-03-27 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-27 11:34:07.402
9895	31	2026-03-27 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-27 11:34:07.76
9896	34	2026-03-27 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-27 11:34:08.119
9897	38	2026-03-27 00:00:00	12	42	22.8km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-27 11:34:08.477
9898	39	2026-03-27 00:00:00	22	74	132.6km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-27 11:34:08.834
9899	155	2026-03-27 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-27 11:34:09.194
9900	42	2026-03-27 00:00:00	17	22	40.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-27 11:34:09.554
9901	44	2026-03-27 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-27 11:34:09.911
9902	45	2026-03-27 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-27 11:34:10.269
9903	46	2026-03-27 00:00:00	10	12	63.2km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-27 11:34:10.625
9904	47	2026-03-27 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-27 11:34:10.981
9905	49	2026-03-27 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-27 11:34:11.337
9906	51	2026-03-27 00:00:00	10	14	20.9km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-27 11:34:11.695
9907	53	2026-03-27 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-27 11:34:12.053
9908	54	2026-03-27 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-27 11:34:12.414
9909	55	2026-03-27 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-27 11:34:12.77
9910	56	2026-03-27 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-27 11:34:13.127
9911	57	2026-03-27 00:00:00	20	27	61.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-27 11:34:13.482
9912	59	2026-03-27 00:00:00	24	31	165km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-27 11:34:13.839
9913	61	2026-03-27 00:00:00	2	2	7.7km/7.7km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-27 11:34:14.196
9914	64	2026-03-27 00:00:00	14	21	62.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-27 11:34:14.552
9915	65	2026-03-27 00:00:00	8	22	41km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-27 11:34:14.908
9916	66	2026-03-27 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-27 11:34:15.264
9917	67	2026-03-27 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-27 11:34:15.62
9918	69	2026-03-27 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-27 11:34:15.976
9919	70	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-27 11:34:16.332
9920	72	2026-03-27 00:00:00	28	30	96.6km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-27 11:34:16.687
9921	74	2026-03-27 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-27 11:34:17.044
9922	78	2026-03-27 00:00:00	15	28	91.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-27 11:34:17.4
9923	79	2026-03-27 00:00:00	10	23	40.5km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-27 11:34:17.757
9924	80	2026-03-27 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-27 11:34:18.113
9925	81	2026-03-27 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-27 11:34:18.472
9926	83	2026-03-27 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-27 11:34:18.83
9927	85	2026-03-27 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-27 11:34:19.189
9928	90	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-27 11:34:19.547
9929	91	2026-03-27 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-27 11:34:19.903
9930	94	2026-03-27 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-27 11:34:20.26
9931	95	2026-03-27 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-27 11:34:20.616
9932	97	2026-03-27 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-27 11:34:20.976
9933	98	2026-03-27 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-27 11:34:21.333
9934	99	2026-03-27 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-27 11:34:21.69
9935	100	2026-03-27 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-27 11:34:22.046
9936	101	2026-03-27 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-27 11:34:22.403
9937	156	2026-03-27 00:00:00	13	18	28.85km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-27 11:34:22.759
9938	102	2026-03-27 00:00:00	11	15	20.7km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-27 11:34:23.119
9939	62	2026-03-27 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-27 11:34:23.475
9940	1	2026-03-27 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-27 11:34:23.831
9941	4	2026-03-27 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-27 11:34:24.187
9942	107	2026-03-27 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-27 11:34:24.543
9943	108	2026-03-27 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-27 11:34:24.899
9944	5	2026-03-27 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-27 11:34:25.255
9945	6	2026-03-27 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-27 11:34:25.615
9946	7	2026-03-27 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-27 11:34:25.971
9947	10	2026-03-27 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-27 11:34:26.331
9948	109	2026-03-27 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-27 11:34:26.688
9949	13	2026-03-27 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-27 11:34:27.045
9950	110	2026-03-27 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-27 11:34:27.402
9951	14	2026-03-27 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-27 11:34:27.757
9952	111	2026-03-27 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-27 11:34:28.113
9953	21	2026-03-27 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-27 11:34:28.469
9954	153	2026-03-27 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-27 11:34:28.824
9955	112	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-27 11:34:29.179
9956	23	2026-03-27 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-27 11:34:29.536
9957	113	2026-03-27 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-27 11:34:29.894
9958	114	2026-03-27 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-27 11:34:30.254
9959	115	2026-03-27 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-27 11:34:30.61
9960	26	2026-03-27 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-27 11:34:30.966
9961	116	2026-03-27 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-27 11:34:31.323
9962	27	2026-03-27 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-27 11:34:31.679
9963	28	2026-03-27 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-27 11:34:32.035
9964	117	2026-03-27 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-27 11:34:32.39
9965	29	2026-03-27 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-27 11:34:32.747
9966	118	2026-03-27 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-27 11:34:33.103
9967	119	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-27 11:34:33.459
9968	32	2026-03-27 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-27 11:34:33.815
9969	33	2026-03-27 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-27 11:34:34.172
9970	120	2026-03-27 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-27 11:34:34.528
9971	35	2026-03-27 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-27 11:34:34.887
9972	121	2026-03-27 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-27 11:34:35.243
9973	36	2026-03-27 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-27 11:34:35.599
9974	122	2026-03-27 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-27 11:34:35.954
9975	123	2026-03-27 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-27 11:34:36.31
9976	37	2026-03-27 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-27 11:34:36.667
9977	124	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-27 11:34:37.024
9978	125	2026-03-27 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-27 11:34:37.38
9979	126	2026-03-27 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-27 11:34:37.736
9980	40	2026-03-27 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-27 11:34:38.092
9981	127	2026-03-27 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-27 11:34:38.447
9982	41	2026-03-27 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-27 11:34:38.803
9983	128	2026-03-27 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-27 11:34:39.16
9984	43	2026-03-27 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-27 11:34:39.516
9985	129	2026-03-27 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-27 11:34:39.875
9986	130	2026-03-27 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-27 11:34:40.23
9987	131	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-27 11:34:40.585
9988	132	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-27 11:34:40.942
9989	48	2026-03-27 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-27 11:34:41.298
9990	133	2026-03-27 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-27 11:34:41.654
9991	50	2026-03-27 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-27 11:34:42.009
9992	134	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-27 11:34:42.364
9993	135	2026-03-27 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-27 11:34:42.72
9994	137	2026-03-27 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-27 11:34:43.078
9995	52	2026-03-27 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-27 11:34:43.434
9996	103	2026-03-27 00:00:00	31	64	77.37km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-27 11:34:43.79
9997	138	2026-03-27 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-27 11:34:44.145
9998	139	2026-03-27 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-27 11:34:44.501
9999	58	2026-03-27 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-27 11:34:44.857
10000	140	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-27 11:34:45.213
10001	141	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-27 11:34:45.57
4812	120	2026-01-20 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-20 00:00:00
4813	120	2026-01-21 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-21 00:00:00
4814	120	2026-01-22 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-22 00:00:00
4815	120	2026-01-23 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-23 00:00:00
4816	120	2026-01-24 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-24 00:00:00
4817	120	2026-01-25 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-25 00:00:00
4818	120	2026-01-26 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-26 00:00:00
4819	120	2026-01-27 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-27 00:00:00
4820	120	2026-01-28 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-28 00:00:00
4821	120	2026-01-29 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-29 00:00:00
4822	120	2026-01-30 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-30 00:00:00
4823	120	2026-01-31 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-01-31 00:00:00
4824	120	2026-02-01 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-01 00:00:00
4825	120	2026-02-02 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-02 00:00:00
4826	120	2026-02-03 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-03 00:00:00
4827	120	2026-02-04 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-04 00:00:00
4828	120	2026-02-05 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-05 00:00:00
4829	120	2026-02-06 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-06 00:00:00
4830	120	2026-02-07 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-07 00:00:00
4831	120	2026-02-08 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-08 00:00:00
4832	120	2026-02-09 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-09 00:00:00
4833	120	2026-02-10 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-10 00:00:00
4834	120	2026-02-11 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-11 00:00:00
4835	120	2026-02-12 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-12 00:00:00
4836	120	2026-02-13 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-13 00:00:00
4837	120	2026-02-14 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-14 00:00:00
4838	120	2026-02-15 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-15 00:00:00
4839	120	2026-02-16 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-16 00:00:00
4840	120	2026-02-17 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-17 00:00:00
4841	120	2026-02-18 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-18 00:00:00
4842	120	2026-02-19 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-19 00:00:00
4843	120	2026-02-20 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-20 00:00:00
4844	120	2026-02-21 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-21 00:00:00
4845	120	2026-02-22 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-22 00:00:00
4846	120	2026-02-23 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-23 00:00:00
4847	120	2026-02-24 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-24 00:00:00
4848	120	2026-02-25 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-25 00:00:00
10002	60	2026-03-27 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-27 11:34:45.927
4849	120	2026-02-26 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-26 00:00:00
4850	120	2026-02-27 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-27 00:00:00
4851	120	2026-02-28 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-02-28 00:00:00
4852	120	2026-03-01 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-01 00:00:00
4853	120	2026-03-02 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-02 00:00:00
4854	120	2026-03-03 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-03 00:00:00
4855	120	2026-03-04 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-04 00:00:00
4856	120	2026-03-05 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-05 00:00:00
4857	120	2026-03-06 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-06 00:00:00
4858	120	2026-03-07 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-07 00:00:00
4859	121	2026-02-05 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-05 00:00:00
4860	121	2026-02-06 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-06 00:00:00
4861	121	2026-02-07 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-07 00:00:00
4862	121	2026-02-08 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-08 00:00:00
4863	121	2026-02-09 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-09 00:00:00
4864	121	2026-02-10 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-10 00:00:00
4865	121	2026-02-11 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-11 00:00:00
4866	121	2026-02-12 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-12 00:00:00
4867	121	2026-02-13 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-13 00:00:00
4868	121	2026-02-14 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-14 00:00:00
4869	121	2026-02-15 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-15 00:00:00
4870	121	2026-02-16 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-16 00:00:00
4871	121	2026-02-17 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-17 00:00:00
4872	121	2026-02-18 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-18 00:00:00
4873	121	2026-02-19 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-19 00:00:00
4874	121	2026-02-20 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-20 00:00:00
4875	121	2026-02-21 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-21 00:00:00
4876	121	2026-02-22 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-22 00:00:00
4877	121	2026-02-23 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-23 00:00:00
4878	121	2026-02-24 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-24 00:00:00
4879	121	2026-02-25 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-25 00:00:00
4880	121	2026-02-26 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-26 00:00:00
4881	121	2026-02-27 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-27 00:00:00
4882	121	2026-02-28 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-02-28 00:00:00
4883	121	2026-03-01 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-01 00:00:00
4884	121	2026-03-02 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-02 00:00:00
4885	121	2026-03-03 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-03 00:00:00
4886	121	2026-03-04 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-04 00:00:00
4887	121	2026-03-05 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-05 00:00:00
4888	121	2026-03-06 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-06 00:00:00
4889	121	2026-03-07 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-07 00:00:00
10003	63	2026-03-27 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-27 11:34:46.283
10004	142	2026-03-27 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-27 11:34:46.642
10005	143	2026-03-27 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-27 11:34:46.999
10006	144	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-27 11:34:47.355
4904	123	2026-02-12 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-12 00:00:00
4905	123	2026-02-13 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-13 00:00:00
4891	122	2026-03-10 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-10 00:00:00
4892	122	2026-03-11 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-11 00:00:00
4893	122	2026-03-12 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-12 00:00:00
4894	122	2026-03-13 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-13 00:00:00
4895	122	2026-03-14 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-14 00:00:00
4896	122	2026-03-15 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-15 00:00:00
4897	122	2026-03-16 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-16 00:00:00
4898	122	2026-03-17 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-17 00:00:00
4899	122	2026-03-18 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-18 00:00:00
4900	122	2026-03-19 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-19 00:00:00
4906	123	2026-02-14 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-14 00:00:00
4907	123	2026-02-15 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-15 00:00:00
4908	123	2026-02-16 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-16 00:00:00
4909	123	2026-02-17 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-17 00:00:00
4910	123	2026-02-18 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-18 00:00:00
4911	123	2026-02-19 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-19 00:00:00
4912	123	2026-02-20 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-20 00:00:00
4913	123	2026-02-21 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-21 00:00:00
4914	123	2026-02-22 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-22 00:00:00
4915	123	2026-02-23 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-23 00:00:00
4916	123	2026-02-24 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-24 00:00:00
4917	123	2026-02-25 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-25 00:00:00
4918	123	2026-02-26 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-26 00:00:00
4919	123	2026-02-27 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-27 00:00:00
4920	123	2026-02-28 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-02-28 00:00:00
4921	123	2026-03-01 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-01 00:00:00
4922	123	2026-03-02 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-02 00:00:00
4923	123	2026-03-03 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-03 00:00:00
4924	123	2026-03-04 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-04 00:00:00
4925	123	2026-03-05 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-05 00:00:00
4926	123	2026-03-06 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-06 00:00:00
4927	123	2026-03-07 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-07 00:00:00
4928	124	2026-02-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-03 00:00:00
4929	124	2026-02-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-04 00:00:00
4930	124	2026-02-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-05 00:00:00
4931	124	2026-02-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-06 00:00:00
4932	124	2026-02-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-07 00:00:00
4933	124	2026-02-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-08 00:00:00
4934	124	2026-02-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-09 00:00:00
4935	124	2026-02-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-10 00:00:00
4936	124	2026-02-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-11 00:00:00
4937	124	2026-02-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-12 00:00:00
4938	124	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-13 00:00:00
4939	124	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-14 00:00:00
4940	124	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-15 00:00:00
4941	124	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-16 00:00:00
4942	124	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-17 00:00:00
4943	124	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-18 00:00:00
4944	124	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-19 00:00:00
4945	124	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-20 00:00:00
4946	124	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-21 00:00:00
4947	124	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-22 00:00:00
4948	124	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-23 00:00:00
4949	124	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-24 00:00:00
4950	124	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-25 00:00:00
4951	124	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-26 00:00:00
4952	124	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-27 00:00:00
4953	124	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-02-28 00:00:00
4954	124	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-01 00:00:00
4955	124	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-02 00:00:00
4956	124	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-03 00:00:00
4957	124	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-04 00:00:00
4958	124	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-05 00:00:00
4959	124	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-06 00:00:00
4960	124	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-07 00:00:00
4961	125	2026-02-26 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-02-26 00:00:00
4962	125	2026-02-27 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-02-27 00:00:00
4963	125	2026-02-28 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-02-28 00:00:00
4964	125	2026-03-01 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-01 00:00:00
4965	125	2026-03-02 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-02 00:00:00
4966	125	2026-03-03 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-03 00:00:00
4967	125	2026-03-04 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-04 00:00:00
4968	125	2026-03-05 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-05 00:00:00
4969	125	2026-03-06 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-06 00:00:00
4970	125	2026-03-07 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-07 00:00:00
10007	68	2026-03-27 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-27 11:34:47.713
10008	104	2026-03-27 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-27 11:34:48.07
10009	145	2026-03-27 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-27 11:34:48.426
10010	146	2026-03-27 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-27 11:34:48.783
10011	71	2026-03-27 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-27 11:34:49.139
10012	147	2026-03-27 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-27 11:34:49.495
10013	73	2026-03-27 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-27 11:34:49.852
10014	75	2026-03-27 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-27 11:34:50.209
10015	76	2026-03-27 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-27 11:34:50.565
10016	77	2026-03-27 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-27 11:34:50.92
10017	148	2026-03-27 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-27 11:34:51.277
10018	105	2026-03-27 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-27 11:34:51.633
10019	82	2026-03-27 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-27 11:34:51.988
10020	154	2026-03-27 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-27 11:34:52.343
10021	84	2026-03-27 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-27 11:34:52.699
10022	149	2026-03-27 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-27 11:34:53.055
10023	86	2026-03-27 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-27 11:34:53.411
10024	150	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-27 11:34:53.767
10025	88	2026-03-27 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-27 11:34:54.123
10026	106	2026-03-27 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-27 11:34:54.482
10027	151	2026-03-27 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-27 11:34:54.838
10028	92	2026-03-27 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-27 11:34:55.194
10029	93	2026-03-27 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-27 11:34:55.55
10030	152	2026-03-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-27 11:34:55.905
10031	96	2026-03-27 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-27 11:34:56.261
4972	126	2026-03-10 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-10 00:00:00
4974	126	2026-03-12 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-12 00:00:00
4975	126	2026-03-13 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-13 00:00:00
4976	126	2026-03-14 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-14 00:00:00
4977	126	2026-03-15 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-15 00:00:00
4978	126	2026-03-16 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-16 00:00:00
4979	126	2026-03-17 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-17 00:00:00
4980	126	2026-03-18 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-18 00:00:00
4981	126	2026-03-19 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-19 00:00:00
10032	2	2026-03-28 00:00:00	3	9	20km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-28 11:18:57.666
10033	3	2026-03-28 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-28 11:18:58.123
10034	8	2026-03-28 00:00:00	27	31	67.2km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-28 11:18:58.572
10035	9	2026-03-28 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-28 11:18:59.014
10036	11	2026-03-28 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-28 11:18:59.452
10037	12	2026-03-28 00:00:00	5	9	20.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-28 11:18:59.892
10038	15	2026-03-28 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-28 11:19:00.332
10039	17	2026-03-28 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-28 11:19:00.77
10040	18	2026-03-28 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-28 11:19:01.208
10041	19	2026-03-28 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-28 11:19:01.648
10042	20	2026-03-28 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-28 11:19:02.085
10043	22	2026-03-28 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-28 11:19:02.524
10044	24	2026-03-28 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-28 11:19:02.961
10045	25	2026-03-28 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-28 11:19:03.398
10046	30	2026-03-28 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-28 11:19:03.837
10047	31	2026-03-28 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-28 11:19:04.274
10048	34	2026-03-28 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-28 11:19:04.713
10049	38	2026-03-28 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-28 11:19:05.15
10050	39	2026-03-28 00:00:00	26	74	158.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-28 11:19:05.591
10051	155	2026-03-28 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-28 11:19:06.031
10052	42	2026-03-28 00:00:00	17	22	40.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-28 11:19:06.469
10053	45	2026-03-28 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-28 11:19:06.907
10054	46	2026-03-28 00:00:00	10	12	63.2km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-28 11:19:07.344
10055	47	2026-03-28 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-28 11:19:07.783
10056	49	2026-03-28 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-28 11:19:08.219
10057	51	2026-03-28 00:00:00	10	14	28.4km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-28 11:19:08.658
10058	53	2026-03-28 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-28 11:19:09.095
10059	54	2026-03-28 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-28 11:19:09.532
10060	55	2026-03-28 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-28 11:19:09.972
10061	56	2026-03-28 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-28 11:19:10.409
10062	57	2026-03-28 00:00:00	19	27	57.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-28 11:19:10.846
10063	59	2026-03-28 00:00:00	24	27	165km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-28 11:19:11.283
10064	61	2026-03-28 00:00:00	2	2	7.7km/7.7km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-28 11:19:11.721
10065	64	2026-03-28 00:00:00	15	21	68.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-28 11:19:12.158
10066	65	2026-03-28 00:00:00	8	22	41km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-28 11:19:12.599
10067	66	2026-03-28 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-28 11:19:13.037
10068	67	2026-03-28 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-28 11:19:13.475
10069	69	2026-03-28 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-28 11:19:13.913
10070	70	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-28 11:19:14.349
10071	72	2026-03-28 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-28 11:19:14.786
10072	74	2026-03-28 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-28 11:19:15.225
10073	78	2026-03-28 00:00:00	16	28	97.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-28 11:19:15.661
10074	79	2026-03-28 00:00:00	11	23	47.5km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-28 11:19:16.1
10075	80	2026-03-28 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-28 11:19:16.537
10076	83	2026-03-28 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-28 11:19:16.976
10077	85	2026-03-28 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-28 11:19:17.412
10078	90	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-28 11:19:17.851
10079	91	2026-03-28 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-28 11:19:18.287
10080	94	2026-03-28 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-28 11:19:18.724
10081	95	2026-03-28 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-28 11:19:19.16
10082	96	2026-03-28 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-28 11:19:19.598
10083	99	2026-03-28 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-28 11:19:20.036
10084	100	2026-03-28 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-28 11:19:20.474
10085	101	2026-03-28 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-28 11:19:20.912
10086	156	2026-03-28 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-28 11:19:21.35
10087	102	2026-03-28 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-28 11:19:21.786
10088	103	2026-03-28 00:00:00	23	64	60.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-28 11:19:22.223
10089	62	2026-03-28 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-28 11:19:22.66
10090	81	2026-03-28 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-28 11:19:23.096
10091	1	2026-03-28 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-28 11:19:23.533
10092	4	2026-03-28 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-28 11:19:23.969
10093	107	2026-03-28 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-28 11:19:24.407
10094	108	2026-03-28 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-28 11:19:24.843
10095	5	2026-03-28 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-28 11:19:25.281
10096	6	2026-03-28 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-28 11:19:25.718
10097	7	2026-03-28 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-28 11:19:26.155
10098	98	2026-03-28 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-28 11:19:26.592
10099	10	2026-03-28 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-28 11:19:27.028
10100	109	2026-03-28 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-28 11:19:27.465
10101	13	2026-03-28 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-28 11:19:27.902
10102	110	2026-03-28 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-28 11:19:28.338
10103	14	2026-03-28 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-28 11:19:28.775
10104	16	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-28 11:19:29.211
10105	111	2026-03-28 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-28 11:19:29.647
10106	21	2026-03-28 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-28 11:19:30.084
10107	153	2026-03-28 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-28 11:19:30.521
10108	112	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-28 11:19:30.957
10109	23	2026-03-28 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-28 11:19:31.396
10110	113	2026-03-28 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-28 11:19:31.833
10111	114	2026-03-28 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-28 11:19:32.271
10112	115	2026-03-28 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-28 11:19:32.714
10113	26	2026-03-28 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-28 11:19:33.152
10114	116	2026-03-28 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-28 11:19:33.589
10115	27	2026-03-28 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-28 11:19:34.025
10116	28	2026-03-28 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-28 11:19:34.462
10117	117	2026-03-28 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-28 11:19:34.9
10118	29	2026-03-28 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-28 11:19:35.336
10119	118	2026-03-28 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-28 11:19:35.773
10120	119	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-28 11:19:36.21
10121	32	2026-03-28 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-28 11:19:36.647
10122	33	2026-03-28 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-28 11:19:37.084
10123	120	2026-03-28 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-28 11:19:37.521
10124	35	2026-03-28 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-28 11:19:37.957
10125	121	2026-03-28 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-28 11:19:38.395
10126	36	2026-03-28 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-28 11:19:38.831
10127	122	2026-03-28 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-28 11:19:39.267
10128	123	2026-03-28 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-28 11:19:39.708
10129	37	2026-03-28 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-28 11:19:40.144
10130	124	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-28 11:19:40.581
10131	125	2026-03-28 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-28 11:19:41.017
10132	126	2026-03-28 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-28 11:19:41.454
10133	40	2026-03-28 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-28 11:19:41.89
10134	127	2026-03-28 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-28 11:19:42.33
10135	41	2026-03-28 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-28 11:19:42.768
10136	128	2026-03-28 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-28 11:19:43.206
10137	43	2026-03-28 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-28 11:19:43.642
10138	44	2026-03-28 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-28 11:19:44.079
10139	129	2026-03-28 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-28 11:19:44.517
10140	130	2026-03-28 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-28 11:19:44.954
10141	131	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-28 11:19:45.391
10142	132	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-28 11:19:45.828
10143	48	2026-03-28 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-28 11:19:46.264
10144	133	2026-03-28 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-28 11:19:46.702
10145	50	2026-03-28 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-28 11:19:47.138
10146	134	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-28 11:19:47.574
10147	135	2026-03-28 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-28 11:19:48.012
10148	137	2026-03-28 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-28 11:19:48.449
10149	52	2026-03-28 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-28 11:19:48.886
10150	138	2026-03-28 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-28 11:19:49.322
10151	139	2026-03-28 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-28 11:19:49.759
10152	58	2026-03-28 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-28 11:19:50.197
10153	140	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-28 11:19:50.639
10154	141	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-28 11:19:51.079
10155	60	2026-03-28 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-28 11:19:51.516
10156	63	2026-03-28 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-28 11:19:51.952
10157	142	2026-03-28 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-28 11:19:52.391
10158	143	2026-03-28 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-28 11:19:52.829
10159	144	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-28 11:19:53.266
10160	68	2026-03-28 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-28 11:19:53.702
10161	104	2026-03-28 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-28 11:19:54.138
10162	145	2026-03-28 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-28 11:19:54.575
10163	146	2026-03-28 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-28 11:19:55.012
10164	71	2026-03-28 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-28 11:19:55.448
10165	147	2026-03-28 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-28 11:19:55.886
10166	73	2026-03-28 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-28 11:19:56.322
10167	75	2026-03-28 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-28 11:19:56.758
10168	76	2026-03-28 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-28 11:19:57.194
10169	77	2026-03-28 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-28 11:19:57.63
10170	148	2026-03-28 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-28 11:19:58.067
10171	105	2026-03-28 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-28 11:19:58.503
10172	82	2026-03-28 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-28 11:19:58.942
10173	154	2026-03-28 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-28 11:19:59.379
10174	84	2026-03-28 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-28 11:19:59.817
10175	149	2026-03-28 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-28 11:20:00.254
10176	86	2026-03-28 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-28 11:20:00.693
10177	150	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-28 11:20:01.134
10178	88	2026-03-28 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-28 11:20:01.57
10179	106	2026-03-28 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-28 11:20:02.008
10180	151	2026-03-28 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-28 11:20:02.445
10181	92	2026-03-28 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-28 11:20:02.882
10182	93	2026-03-28 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-28 11:20:03.319
10183	152	2026-03-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-28 11:20:03.755
10184	97	2026-03-28 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-28 11:20:04.191
10185	2	2026-03-29 00:00:00	3	9	20km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-29 11:19:43.32
10186	3	2026-03-29 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-29 11:19:43.963
10187	8	2026-03-29 00:00:00	17	31	30.6km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-29 11:19:44.591
10188	9	2026-03-29 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-29 11:19:45.216
10189	11	2026-03-29 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-29 11:19:45.84
10190	12	2026-03-29 00:00:00	5	9	20.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-29 11:19:46.464
10191	15	2026-03-29 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-29 11:19:47.088
10192	17	2026-03-29 00:00:00	13	15	59.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-29 11:19:47.71
10193	18	2026-03-29 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-29 11:19:48.333
10194	19	2026-03-29 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-29 11:19:48.955
10195	20	2026-03-29 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-29 11:19:49.577
10196	22	2026-03-29 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-29 11:19:50.199
10197	24	2026-03-29 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-29 11:19:50.821
10198	25	2026-03-29 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-29 11:19:51.444
10199	30	2026-03-29 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-29 11:19:52.068
10200	31	2026-03-29 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-29 11:19:52.691
10201	34	2026-03-29 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-29 11:19:53.313
10202	38	2026-03-29 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-29 11:19:53.935
10203	39	2026-03-29 00:00:00	26	74	158.4km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-29 11:19:54.559
10204	155	2026-03-29 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-29 11:19:55.184
10205	42	2026-03-29 00:00:00	17	22	40.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-29 11:19:55.805
10206	45	2026-03-29 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-29 11:19:56.429
10207	46	2026-03-29 00:00:00	10	12	63.2km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-29 11:19:57.05
10208	47	2026-03-29 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-29 11:19:57.674
10209	49	2026-03-29 00:00:00	10	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-29 11:19:58.297
10210	51	2026-03-29 00:00:00	10	14	28.4km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-29 11:19:58.922
10211	53	2026-03-29 00:00:00	9	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-29 11:19:59.545
10212	54	2026-03-29 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-29 11:20:00.167
10213	55	2026-03-29 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-29 11:20:00.789
10214	56	2026-03-29 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-29 11:20:01.411
10215	57	2026-03-29 00:00:00	19	27	57.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-29 11:20:02.033
10216	59	2026-03-29 00:00:00	24	27	165km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-29 11:20:02.657
10217	61	2026-03-29 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-29 11:20:03.279
10218	64	2026-03-29 00:00:00	15	21	68.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-29 11:20:03.902
10219	65	2026-03-29 00:00:00	8	22	41km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-29 11:20:04.524
10220	66	2026-03-29 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-29 11:20:05.146
10221	67	2026-03-29 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-29 11:20:05.77
10222	69	2026-03-29 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-29 11:20:06.395
10223	70	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-29 11:20:07.019
10224	72	2026-03-29 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-29 11:20:07.642
10225	74	2026-03-29 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-29 11:20:08.265
10226	78	2026-03-29 00:00:00	16	28	97.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-29 11:20:08.886
10227	79	2026-03-29 00:00:00	12	23	74.5km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-29 11:20:09.51
10228	80	2026-03-29 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-29 11:20:10.131
10229	83	2026-03-29 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-29 11:20:10.755
10230	85	2026-03-29 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-29 11:20:11.377
10231	90	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-29 11:20:12.002
10232	91	2026-03-29 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-29 11:20:12.624
10233	94	2026-03-29 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-29 11:20:13.246
10234	95	2026-03-29 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-29 11:20:13.87
10235	96	2026-03-29 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-29 11:20:14.491
10236	99	2026-03-29 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-29 11:20:15.113
10237	100	2026-03-29 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-29 11:20:15.736
10238	101	2026-03-29 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-29 11:20:16.359
10239	156	2026-03-29 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-29 11:20:16.981
10240	102	2026-03-29 00:00:00	11	15	20.7km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-29 11:20:17.603
10241	103	2026-03-29 00:00:00	22	64	58.42km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-29 11:20:18.224
10242	62	2026-03-29 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-29 11:20:18.845
10243	81	2026-03-29 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-29 11:20:19.466
10244	1	2026-03-29 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-29 11:20:20.088
10245	4	2026-03-29 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-29 11:20:20.709
10246	107	2026-03-29 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-29 11:20:21.332
10247	108	2026-03-29 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-29 11:20:21.954
10248	5	2026-03-29 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-29 11:20:22.576
10249	6	2026-03-29 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-29 11:20:23.198
10250	7	2026-03-29 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-29 11:20:23.819
10251	98	2026-03-29 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-29 11:20:24.44
10252	10	2026-03-29 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-29 11:20:25.062
10253	109	2026-03-29 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-29 11:20:25.686
10254	13	2026-03-29 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-29 11:20:26.308
10255	110	2026-03-29 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-29 11:20:26.929
10256	14	2026-03-29 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-29 11:20:27.551
10257	16	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-29 11:20:28.173
10258	111	2026-03-29 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-29 11:20:28.796
10259	21	2026-03-29 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-29 11:20:29.417
10260	153	2026-03-29 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-29 11:20:30.04
10261	112	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-29 11:20:30.661
10262	23	2026-03-29 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-29 11:20:31.282
10263	113	2026-03-29 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-29 11:20:31.906
10264	114	2026-03-29 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-29 11:20:32.531
10265	115	2026-03-29 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-29 11:20:33.154
10266	26	2026-03-29 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-29 11:20:33.777
10267	116	2026-03-29 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-29 11:20:34.398
10268	27	2026-03-29 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-29 11:20:35.02
10269	28	2026-03-29 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-29 11:20:35.641
10270	117	2026-03-29 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-29 11:20:36.264
10271	29	2026-03-29 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-29 11:20:36.885
10272	118	2026-03-29 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-29 11:20:37.512
10273	119	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-29 11:20:38.133
10274	32	2026-03-29 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-29 11:20:38.755
10275	33	2026-03-29 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-29 11:20:39.378
10276	120	2026-03-29 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-29 11:20:40
10277	35	2026-03-29 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-29 11:20:40.621
10278	121	2026-03-29 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-29 11:20:41.243
10279	36	2026-03-29 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-29 11:20:41.864
10280	122	2026-03-29 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-29 11:20:42.486
10281	123	2026-03-29 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-29 11:20:43.107
10282	37	2026-03-29 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-29 11:20:43.73
10283	124	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-29 11:20:44.351
10284	125	2026-03-29 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-29 11:20:44.973
10285	126	2026-03-29 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-29 11:20:45.595
10286	40	2026-03-29 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-29 11:20:46.216
10287	127	2026-03-29 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-29 11:20:46.839
10288	41	2026-03-29 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-29 11:20:47.461
10289	128	2026-03-29 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-29 11:20:48.083
10290	43	2026-03-29 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-29 11:20:48.704
10291	44	2026-03-29 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-29 11:20:49.327
10292	129	2026-03-29 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-29 11:20:49.948
10293	130	2026-03-29 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-29 11:20:50.573
10294	131	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-29 11:20:51.194
10295	132	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-29 11:20:51.815
10296	48	2026-03-29 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-29 11:20:52.436
10297	133	2026-03-29 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-29 11:20:53.058
10298	50	2026-03-29 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-29 11:20:53.679
10299	134	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-29 11:20:54.3
10300	135	2026-03-29 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-29 11:20:54.922
10301	137	2026-03-29 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-29 11:20:55.545
10302	52	2026-03-29 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-29 11:20:56.166
10303	138	2026-03-29 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-29 11:20:56.787
10304	139	2026-03-29 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-29 11:20:57.409
10305	58	2026-03-29 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-29 11:20:58.03
10306	140	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-29 11:20:58.654
10307	141	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-29 11:20:59.275
10308	60	2026-03-29 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-29 11:20:59.897
10309	63	2026-03-29 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-29 11:21:00.517
10310	142	2026-03-29 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-29 11:21:01.14
5265	127	2026-01-13 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-13 00:00:00
5266	127	2026-01-14 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-14 00:00:00
5267	127	2026-01-15 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-15 00:00:00
5268	127	2026-01-16 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-16 00:00:00
5269	127	2026-01-17 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-17 00:00:00
5270	127	2026-01-18 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-18 00:00:00
5271	127	2026-01-19 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-19 00:00:00
5272	127	2026-01-20 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-20 00:00:00
5273	127	2026-01-21 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-21 00:00:00
5274	127	2026-01-22 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-22 00:00:00
5275	127	2026-01-23 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-23 00:00:00
5276	127	2026-01-24 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-24 00:00:00
5277	127	2026-01-25 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-25 00:00:00
5278	127	2026-01-26 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-26 00:00:00
5279	127	2026-01-27 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-27 00:00:00
5280	127	2026-01-28 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-28 00:00:00
5281	127	2026-01-29 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-29 00:00:00
5282	127	2026-01-30 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-30 00:00:00
5283	127	2026-01-31 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-01-31 00:00:00
5284	127	2026-02-01 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-01 00:00:00
5285	127	2026-02-02 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-02 00:00:00
5286	127	2026-02-03 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-03 00:00:00
5287	127	2026-02-04 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-04 00:00:00
5288	127	2026-02-05 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-05 00:00:00
5289	127	2026-02-06 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-06 00:00:00
5290	127	2026-02-07 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-07 00:00:00
5291	127	2026-02-08 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-08 00:00:00
5292	127	2026-02-09 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-09 00:00:00
5293	127	2026-02-10 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-10 00:00:00
5294	127	2026-02-11 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-11 00:00:00
10311	143	2026-03-29 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-29 11:21:01.761
10312	144	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-29 11:21:02.383
10313	68	2026-03-29 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-29 11:21:03.003
5295	127	2026-02-12 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-12 00:00:00
5296	127	2026-02-13 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-13 00:00:00
5297	127	2026-02-14 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-14 00:00:00
5298	127	2026-02-15 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-15 00:00:00
5299	127	2026-02-16 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-16 00:00:00
5300	127	2026-02-17 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-17 00:00:00
5301	127	2026-02-18 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-18 00:00:00
5302	127	2026-02-19 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-19 00:00:00
5303	127	2026-02-20 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-20 00:00:00
5304	127	2026-02-21 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-21 00:00:00
5305	127	2026-02-22 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-22 00:00:00
5306	127	2026-02-23 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-23 00:00:00
5307	127	2026-02-24 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-24 00:00:00
5308	127	2026-02-25 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-25 00:00:00
5309	127	2026-02-26 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-26 00:00:00
5310	127	2026-02-27 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-27 00:00:00
5311	127	2026-02-28 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-02-28 00:00:00
5312	127	2026-03-01 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-01 00:00:00
5313	127	2026-03-02 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-02 00:00:00
5314	127	2026-03-03 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-03 00:00:00
5315	127	2026-03-04 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-04 00:00:00
5316	127	2026-03-05 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-05 00:00:00
5317	127	2026-03-06 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-06 00:00:00
5318	127	2026-03-07 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-07 00:00:00
5319	128	2026-02-05 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-05 00:00:00
5320	128	2026-02-06 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-06 00:00:00
5321	128	2026-02-07 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-07 00:00:00
5322	128	2026-02-08 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-08 00:00:00
5323	128	2026-02-09 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-09 00:00:00
5324	128	2026-02-10 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-10 00:00:00
5325	128	2026-02-11 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-11 00:00:00
5326	128	2026-02-12 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-12 00:00:00
5327	128	2026-02-13 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-13 00:00:00
5328	128	2026-02-14 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-14 00:00:00
5329	128	2026-02-15 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-15 00:00:00
5330	128	2026-02-16 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-16 00:00:00
5331	128	2026-02-17 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-17 00:00:00
5332	128	2026-02-18 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-18 00:00:00
5333	128	2026-02-19 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-19 00:00:00
5334	128	2026-02-20 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-20 00:00:00
5335	128	2026-02-21 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-21 00:00:00
5336	128	2026-02-22 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-22 00:00:00
5337	128	2026-02-23 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-23 00:00:00
5338	128	2026-02-24 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-24 00:00:00
5339	128	2026-02-25 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-25 00:00:00
5340	128	2026-02-26 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-26 00:00:00
5341	128	2026-02-27 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-27 00:00:00
5342	128	2026-02-28 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-02-28 00:00:00
5343	128	2026-03-01 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-01 00:00:00
5344	128	2026-03-02 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-02 00:00:00
5345	128	2026-03-03 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-03 00:00:00
5346	128	2026-03-04 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-04 00:00:00
5347	128	2026-03-05 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-05 00:00:00
5348	128	2026-03-06 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-06 00:00:00
5349	128	2026-03-07 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-07 00:00:00
5350	129	2026-02-04 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-04 00:00:00
5351	129	2026-02-05 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-05 00:00:00
5352	129	2026-02-06 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-06 00:00:00
5353	129	2026-02-07 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-07 00:00:00
5354	129	2026-02-08 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-08 00:00:00
5355	129	2026-02-09 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-09 00:00:00
5356	129	2026-02-10 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-10 00:00:00
5357	129	2026-02-11 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-11 00:00:00
5358	129	2026-02-12 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-12 00:00:00
5359	129	2026-02-13 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-13 00:00:00
5360	129	2026-02-14 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-14 00:00:00
5361	129	2026-02-15 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-15 00:00:00
5362	129	2026-02-16 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-16 00:00:00
5363	129	2026-02-17 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-17 00:00:00
5364	129	2026-02-18 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-18 00:00:00
5365	129	2026-02-19 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-19 00:00:00
5366	129	2026-02-20 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-20 00:00:00
5367	129	2026-02-21 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-21 00:00:00
5368	129	2026-02-22 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-22 00:00:00
5369	129	2026-02-23 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-23 00:00:00
5370	129	2026-02-24 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-24 00:00:00
5371	129	2026-02-25 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-25 00:00:00
5372	129	2026-02-26 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-26 00:00:00
5373	129	2026-02-27 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-27 00:00:00
5374	129	2026-02-28 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-02-28 00:00:00
5375	129	2026-03-01 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-01 00:00:00
5376	129	2026-03-02 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-02 00:00:00
5377	129	2026-03-03 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-03 00:00:00
5378	129	2026-03-04 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-04 00:00:00
5379	129	2026-03-05 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-05 00:00:00
5380	129	2026-03-06 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-06 00:00:00
5381	129	2026-03-07 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-07 00:00:00
10314	104	2026-03-29 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-29 11:21:03.624
5386	131	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-01 00:00:00
10315	145	2026-03-29 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-29 11:21:04.249
10316	146	2026-03-29 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-29 11:21:04.871
10317	71	2026-03-29 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-29 11:21:05.492
10318	147	2026-03-29 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-29 11:21:06.113
10319	73	2026-03-29 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-29 11:21:06.735
10320	75	2026-03-29 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-29 11:21:07.356
5387	132	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-09 00:00:00
5383	130	2026-03-10 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-10 00:00:00
5388	132	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-10 00:00:00
5384	130	2026-03-11 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-11 00:00:00
5389	132	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-11 00:00:00
5385	130	2026-03-12 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-12 00:00:00
5390	132	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-12 00:00:00
5391	132	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-13 00:00:00
5392	132	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-14 00:00:00
5393	132	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-15 00:00:00
5394	132	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-16 00:00:00
5395	132	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-17 00:00:00
5396	132	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-18 00:00:00
5397	132	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-19 00:00:00
10321	76	2026-03-29 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-29 11:21:07.976
10322	77	2026-03-29 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-29 11:21:08.597
10323	148	2026-03-29 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-29 11:21:09.217
10324	105	2026-03-29 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-29 11:21:09.837
10325	82	2026-03-29 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-29 11:21:10.458
10326	154	2026-03-29 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-29 11:21:11.078
10327	84	2026-03-29 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-29 11:21:11.699
10328	149	2026-03-29 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-29 11:21:12.319
10329	86	2026-03-29 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-29 11:21:12.94
10330	150	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-29 11:21:13.561
10331	88	2026-03-29 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-29 11:21:14.181
10332	106	2026-03-29 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-29 11:21:14.801
10333	151	2026-03-29 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-29 11:21:15.421
10334	92	2026-03-29 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-29 11:21:16.041
10335	93	2026-03-29 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-29 11:21:16.661
10336	152	2026-03-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-29 11:21:17.281
10337	97	2026-03-29 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-29 11:21:17.901
10338	69	2026-03-23 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-29 16:51:18.622
10339	69	2026-03-24 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-29 16:51:18.622
10340	69	2026-03-25 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-29 16:51:18.622
10341	3	2026-03-30 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-30 11:45:39.546
10342	9	2026-03-30 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-30 11:45:40.168
10343	11	2026-03-30 00:00:00	21	27	131.7km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-30 11:45:40.774
10344	12	2026-03-30 00:00:00	0	9	0km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-30 11:45:41.381
10345	15	2026-03-30 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-30 11:45:42.003
10346	18	2026-03-30 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-30 11:45:42.609
10347	19	2026-03-30 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-30 11:45:43.215
10348	20	2026-03-30 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-30 11:45:43.819
10349	22	2026-03-30 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-30 11:45:44.424
10350	25	2026-03-30 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-30 11:45:45.028
10351	30	2026-03-30 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-30 11:45:45.631
10352	31	2026-03-30 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-30 11:45:46.235
10353	34	2026-03-30 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-30 11:45:46.839
10354	155	2026-03-30 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-30 11:45:47.444
10355	42	2026-03-30 00:00:00	17	22	40.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-30 11:45:48.048
10356	45	2026-03-30 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-30 11:45:48.663
10357	47	2026-03-30 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-30 11:45:49.269
10358	49	2026-03-30 00:00:00	9	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-30 11:45:49.874
10359	53	2026-03-30 00:00:00	8	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-30 11:45:50.477
10360	54	2026-03-30 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-30 11:45:51.08
10361	55	2026-03-30 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-30 11:45:51.684
10362	56	2026-03-30 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-30 11:45:52.29
10363	57	2026-03-30 00:00:00	19	27	57.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-30 11:45:52.895
10364	59	2026-03-30 00:00:00	13	27	85.7km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-30 11:45:53.5
10365	61	2026-03-30 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-30 11:45:54.106
10366	64	2026-03-30 00:00:00	0	21	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-30 11:45:54.71
10367	66	2026-03-30 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-30 11:45:55.314
10368	67	2026-03-30 00:00:00	3	12	11.7km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-30 11:45:55.919
10369	69	2026-03-30 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-30 11:45:56.521
10370	70	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-30 11:45:57.124
10371	72	2026-03-30 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-30 11:45:57.729
10372	74	2026-03-30 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-30 11:45:58.333
10373	78	2026-03-30 00:00:00	5	28	26.5km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-30 11:45:58.936
10374	79	2026-03-30 00:00:00	11	23	63.5km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-30 11:45:59.539
10375	80	2026-03-30 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-30 11:46:00.145
10376	83	2026-03-30 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-30 11:46:00.748
10377	85	2026-03-30 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-30 11:46:01.351
10378	90	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-30 11:46:01.956
10379	91	2026-03-30 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-30 11:46:02.559
10380	94	2026-03-30 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-30 11:46:03.161
10381	95	2026-03-30 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-30 11:46:03.764
10382	99	2026-03-30 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-30 11:46:04.367
10383	100	2026-03-30 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-30 11:46:04.97
10384	101	2026-03-30 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-30 11:46:05.572
10385	156	2026-03-30 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-30 11:46:06.175
10386	102	2026-03-30 00:00:00	8	15	18.3km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-30 11:46:06.778
10387	62	2026-03-30 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-30 11:46:07.382
10388	81	2026-03-30 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-30 11:46:07.985
10389	1	2026-03-30 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-30 11:46:08.59
10390	2	2026-03-30 00:00:00	0	9	0km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-30 11:46:09.193
10391	4	2026-03-30 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-30 11:46:09.798
10392	107	2026-03-30 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-30 11:46:10.401
10393	108	2026-03-30 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-30 11:46:11.004
10394	5	2026-03-30 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-30 11:46:11.607
10395	6	2026-03-30 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-30 11:46:12.212
10396	7	2026-03-30 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-30 11:46:12.815
10397	8	2026-03-30 00:00:00	0	31	0km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-30 11:46:13.424
10398	98	2026-03-30 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-30 11:46:14.027
10399	10	2026-03-30 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-30 11:46:14.631
10400	109	2026-03-30 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-30 11:46:15.236
10401	13	2026-03-30 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-30 11:46:15.84
10402	110	2026-03-30 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-30 11:46:16.442
10403	14	2026-03-30 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-30 11:46:17.045
10404	16	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-30 11:46:17.649
10405	17	2026-03-30 00:00:00	0	15	0km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-30 11:46:18.255
10406	111	2026-03-30 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-30 11:46:18.859
10407	21	2026-03-30 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-30 11:46:19.463
10408	153	2026-03-30 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-30 11:46:20.066
10409	112	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-30 11:46:20.67
10410	23	2026-03-30 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-30 11:46:21.273
10411	113	2026-03-30 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-30 11:46:21.876
10412	24	2026-03-30 00:00:00	0	8	0km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-30 11:46:22.48
10413	114	2026-03-30 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-30 11:46:23.082
10414	115	2026-03-30 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-30 11:46:23.685
10415	26	2026-03-30 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-30 11:46:24.288
10416	116	2026-03-30 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-30 11:46:24.89
10417	27	2026-03-30 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-30 11:46:25.493
10418	28	2026-03-30 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-30 11:46:26.096
10419	117	2026-03-30 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-30 11:46:26.7
10420	29	2026-03-30 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-30 11:46:27.302
10421	118	2026-03-30 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-30 11:46:27.906
10422	119	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-30 11:46:28.509
5591	133	2026-02-25 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-02-25 00:00:00
5592	133	2026-02-26 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-02-26 00:00:00
5593	133	2026-02-27 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-02-27 00:00:00
5594	133	2026-02-28 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-02-28 00:00:00
5595	133	2026-03-01 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-01 00:00:00
5596	133	2026-03-02 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-02 00:00:00
5597	133	2026-03-03 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-03 00:00:00
5598	133	2026-03-04 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-04 00:00:00
5599	133	2026-03-05 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-05 00:00:00
5600	133	2026-03-06 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-06 00:00:00
5601	133	2026-03-07 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-07 00:00:00
5602	134	2026-01-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-09 00:00:00
5603	134	2026-01-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-10 00:00:00
5604	134	2026-01-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-11 00:00:00
5605	134	2026-01-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-12 00:00:00
5606	134	2026-01-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-13 00:00:00
5607	134	2026-01-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-14 00:00:00
5608	134	2026-01-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-15 00:00:00
5609	134	2026-01-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-16 00:00:00
5610	134	2026-01-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-17 00:00:00
5611	134	2026-01-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-18 00:00:00
5612	134	2026-01-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-19 00:00:00
5613	134	2026-01-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-20 00:00:00
5614	134	2026-01-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-21 00:00:00
5615	134	2026-01-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-22 00:00:00
5616	134	2026-01-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-23 00:00:00
5617	134	2026-01-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-24 00:00:00
5618	134	2026-01-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-25 00:00:00
5619	134	2026-01-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-26 00:00:00
5620	134	2026-01-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-27 00:00:00
5621	134	2026-01-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-28 00:00:00
5622	134	2026-01-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-29 00:00:00
5623	134	2026-01-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-30 00:00:00
5624	134	2026-01-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-01-31 00:00:00
5625	134	2026-02-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-01 00:00:00
5626	134	2026-02-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-02 00:00:00
5627	134	2026-02-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-03 00:00:00
5628	134	2026-02-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-04 00:00:00
5629	134	2026-02-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-05 00:00:00
5630	134	2026-02-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-06 00:00:00
5631	134	2026-02-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-07 00:00:00
5632	134	2026-02-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-08 00:00:00
5633	134	2026-02-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-09 00:00:00
5634	134	2026-02-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-10 00:00:00
5635	134	2026-02-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-11 00:00:00
5636	134	2026-02-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-12 00:00:00
5637	134	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-13 00:00:00
5638	134	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-14 00:00:00
5639	134	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-15 00:00:00
5640	134	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-16 00:00:00
5641	134	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-17 00:00:00
5642	134	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-18 00:00:00
5643	134	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-19 00:00:00
5644	134	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-20 00:00:00
5645	134	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-21 00:00:00
5646	134	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-22 00:00:00
5647	134	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-23 00:00:00
5648	134	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-24 00:00:00
5649	134	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-25 00:00:00
5650	134	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-26 00:00:00
5651	134	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-27 00:00:00
5652	134	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-02-28 00:00:00
5653	134	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-01 00:00:00
5654	134	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-02 00:00:00
5655	134	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-04 00:00:00
5656	134	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-05 00:00:00
5657	134	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-06 00:00:00
5658	134	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-07 00:00:00
5659	135	2026-02-04 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-04 00:00:00
5660	135	2026-02-05 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-05 00:00:00
5661	135	2026-02-06 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-06 00:00:00
5662	135	2026-02-07 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-07 00:00:00
5663	135	2026-02-08 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-08 00:00:00
5664	135	2026-02-09 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-09 00:00:00
5665	135	2026-02-10 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-10 00:00:00
5666	135	2026-02-11 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-11 00:00:00
5667	135	2026-02-12 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-12 00:00:00
5668	135	2026-02-13 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-13 00:00:00
5669	135	2026-02-14 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-14 00:00:00
5670	135	2026-02-15 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-15 00:00:00
5671	135	2026-02-16 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-16 00:00:00
5672	135	2026-02-17 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-17 00:00:00
5673	135	2026-02-18 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-18 00:00:00
5674	135	2026-02-19 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-19 00:00:00
5675	135	2026-02-20 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-20 00:00:00
5676	135	2026-02-21 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-21 00:00:00
5677	135	2026-02-22 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-22 00:00:00
5678	135	2026-02-23 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-23 00:00:00
5679	135	2026-02-24 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-24 00:00:00
5680	135	2026-02-25 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-25 00:00:00
5681	135	2026-02-26 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-26 00:00:00
5682	135	2026-02-27 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-27 00:00:00
5683	135	2026-02-28 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-02-28 00:00:00
5684	135	2026-03-01 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-01 00:00:00
5685	135	2026-03-02 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-02 00:00:00
5686	135	2026-03-03 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-03 00:00:00
5687	135	2026-03-04 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-04 00:00:00
5688	135	2026-03-05 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-05 00:00:00
5689	135	2026-03-06 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-06 00:00:00
5690	135	2026-03-07 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-07 00:00:00
5691	136	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-02-28 00:00:00
5692	136	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-01 00:00:00
5693	136	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-03 00:00:00
5694	136	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-04 00:00:00
5695	136	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-05 00:00:00
5696	136	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-valtin-col-de-la-schlucht/	2026-03-07 00:00:00
5697	137	2026-02-04 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-04 00:00:00
5698	137	2026-02-05 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-05 00:00:00
5699	137	2026-02-06 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-06 00:00:00
5700	137	2026-02-07 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-07 00:00:00
5701	137	2026-02-08 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-08 00:00:00
5702	137	2026-02-09 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-09 00:00:00
5703	137	2026-02-10 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-10 00:00:00
5704	137	2026-02-11 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-11 00:00:00
5705	137	2026-02-12 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-12 00:00:00
5706	137	2026-02-13 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-13 00:00:00
5707	137	2026-02-14 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-14 00:00:00
5708	137	2026-02-15 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-15 00:00:00
5709	137	2026-02-16 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-16 00:00:00
5710	137	2026-02-17 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-17 00:00:00
5711	137	2026-02-18 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-18 00:00:00
5712	137	2026-02-19 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-19 00:00:00
5713	137	2026-02-20 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-20 00:00:00
5714	137	2026-02-21 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-21 00:00:00
5715	137	2026-02-22 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-22 00:00:00
5716	137	2026-02-23 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-23 00:00:00
5717	137	2026-02-24 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-24 00:00:00
5718	137	2026-02-25 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-25 00:00:00
5719	137	2026-02-26 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-26 00:00:00
5720	137	2026-02-27 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-27 00:00:00
5721	137	2026-02-28 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-02-28 00:00:00
5722	137	2026-03-01 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-01 00:00:00
5723	137	2026-03-02 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-02 00:00:00
5724	137	2026-03-03 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-03 00:00:00
5725	137	2026-03-04 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-04 00:00:00
5726	137	2026-03-05 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-05 00:00:00
5727	137	2026-03-06 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-06 00:00:00
5728	137	2026-03-07 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-07 00:00:00
5729	138	2026-01-31 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-01-31 00:00:00
5730	138	2026-02-01 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-01 00:00:00
5731	138	2026-02-02 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-02 00:00:00
5732	138	2026-02-03 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-03 00:00:00
5733	138	2026-02-04 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-04 00:00:00
5734	138	2026-02-05 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-05 00:00:00
5735	138	2026-02-06 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-06 00:00:00
5736	138	2026-02-07 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-07 00:00:00
5737	138	2026-02-08 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-08 00:00:00
5738	138	2026-02-09 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-09 00:00:00
5739	138	2026-02-10 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-10 00:00:00
5740	138	2026-02-11 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-11 00:00:00
5741	138	2026-02-12 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-12 00:00:00
5742	138	2026-02-13 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-13 00:00:00
5743	138	2026-02-14 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-14 00:00:00
5744	138	2026-02-15 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-15 00:00:00
5745	138	2026-02-16 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-16 00:00:00
5746	138	2026-02-17 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-17 00:00:00
5747	138	2026-02-18 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-18 00:00:00
5748	138	2026-02-19 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-19 00:00:00
5749	138	2026-02-20 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-20 00:00:00
5750	138	2026-02-21 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-21 00:00:00
5751	138	2026-02-22 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-22 00:00:00
5752	138	2026-02-23 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-23 00:00:00
5753	138	2026-02-24 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-24 00:00:00
5754	138	2026-02-25 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-25 00:00:00
5755	138	2026-02-26 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-26 00:00:00
5756	138	2026-02-27 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-27 00:00:00
5757	138	2026-02-28 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-02-28 00:00:00
5758	138	2026-03-01 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-01 00:00:00
5759	138	2026-03-02 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-02 00:00:00
5760	138	2026-03-03 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-03 00:00:00
5761	138	2026-03-04 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-04 00:00:00
5762	138	2026-03-05 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-05 00:00:00
5763	138	2026-03-06 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-06 00:00:00
5764	138	2026-03-07 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-07 00:00:00
10423	32	2026-03-30 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-30 11:46:29.112
10424	33	2026-03-30 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-30 11:46:29.715
10425	120	2026-03-30 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-30 11:46:30.317
5766	139	2026-03-10 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-10 00:00:00
5767	139	2026-03-11 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-11 00:00:00
5768	139	2026-03-12 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-12 00:00:00
5769	139	2026-03-13 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-13 00:00:00
5770	139	2026-03-14 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-14 00:00:00
5771	139	2026-03-15 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-15 00:00:00
5772	139	2026-03-16 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-16 00:00:00
5773	139	2026-03-17 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-17 00:00:00
5774	139	2026-03-18 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-18 00:00:00
5775	139	2026-03-19 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-19 00:00:00
10426	35	2026-03-30 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-30 11:46:30.92
10427	121	2026-03-30 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-30 11:46:31.523
10428	36	2026-03-30 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-30 11:46:32.126
10429	122	2026-03-30 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-30 11:46:32.729
10430	123	2026-03-30 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-30 11:46:33.332
10431	37	2026-03-30 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-30 11:46:33.935
10432	38	2026-03-30 00:00:00	0	42	0km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-30 11:46:34.538
10433	124	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-30 11:46:35.143
10434	125	2026-03-30 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-30 11:46:35.749
10435	39	2026-03-30 00:00:00	0	74	0km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-30 11:46:36.351
10436	126	2026-03-30 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-30 11:46:36.956
10437	127	2026-03-30 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-30 11:46:37.56
10438	41	2026-03-30 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-30 11:46:38.162
10439	128	2026-03-30 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-30 11:46:38.763
10440	43	2026-03-30 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-30 11:46:39.365
10441	40	2026-03-30 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-30 11:46:39.968
10442	44	2026-03-30 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-30 11:46:40.571
10443	129	2026-03-30 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-30 11:46:41.174
10444	130	2026-03-30 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-30 11:46:41.776
10445	131	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-30 11:46:42.381
10446	46	2026-03-30 00:00:00	0	12	0km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-30 11:46:42.984
10447	132	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-30 11:46:43.59
10448	48	2026-03-30 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-30 11:46:44.193
10449	133	2026-03-30 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-30 11:46:44.795
10450	50	2026-03-30 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-30 11:46:45.397
10451	134	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-30 11:46:46
10452	135	2026-03-30 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-30 11:46:46.602
10453	51	2026-03-30 00:00:00	6	14	5.5km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-30 11:46:47.206
10454	137	2026-03-30 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-30 11:46:47.809
10455	52	2026-03-30 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-30 11:46:48.412
10456	103	2026-03-30 00:00:00	12	64	30.4km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-30 11:46:49.015
10457	138	2026-03-30 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-30 11:46:49.618
10458	139	2026-03-30 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-30 11:46:50.22
10459	58	2026-03-30 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-30 11:46:50.822
10460	140	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-30 11:46:51.426
10461	141	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-30 11:46:52.028
10462	60	2026-03-30 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-30 11:46:52.63
10463	63	2026-03-30 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-30 11:46:53.232
10464	142	2026-03-30 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-30 11:46:53.836
10465	65	2026-03-30 00:00:00	1	22	0.8km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-30 11:46:54.438
10466	143	2026-03-30 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-30 11:46:55.04
10467	144	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-30 11:46:55.644
10468	68	2026-03-30 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-30 11:46:56.248
10469	104	2026-03-30 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-30 11:46:56.852
10470	145	2026-03-30 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-30 11:46:57.455
10471	146	2026-03-30 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-30 11:46:58.058
10472	71	2026-03-30 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-30 11:46:58.662
10473	147	2026-03-30 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-30 11:46:59.264
10474	73	2026-03-30 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-30 11:46:59.869
10475	75	2026-03-30 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-30 11:47:00.472
10476	76	2026-03-30 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-30 11:47:01.075
10477	77	2026-03-30 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-30 11:47:01.678
10478	148	2026-03-30 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-30 11:47:02.282
10479	105	2026-03-30 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-30 11:47:02.886
10480	82	2026-03-30 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-30 11:47:03.489
10481	154	2026-03-30 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-30 11:47:04.092
10482	84	2026-03-30 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-30 11:47:04.697
10483	149	2026-03-30 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-30 11:47:05.301
10484	86	2026-03-30 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-30 11:47:05.904
10485	150	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-30 11:47:06.507
10486	88	2026-03-30 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-30 11:47:07.111
10487	106	2026-03-30 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-30 11:47:07.716
10488	151	2026-03-30 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-30 11:47:08.32
10489	92	2026-03-30 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-30 11:47:08.924
10490	93	2026-03-30 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-30 11:47:09.527
10491	152	2026-03-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-30 11:47:10.13
10492	96	2026-03-30 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-30 11:47:10.735
10493	97	2026-03-30 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-30 11:47:11.337
10494	3	2026-03-31 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-31 11:39:49.496
10495	9	2026-03-31 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-31 11:39:50.03
10496	11	2026-03-31 00:00:00	21	27	131.7km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-31 11:39:50.548
10497	12	2026-03-31 00:00:00	0	9	0km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-31 11:39:51.068
10498	15	2026-03-31 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-31 11:39:51.585
10499	18	2026-03-31 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-31 11:39:52.101
10500	19	2026-03-31 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-31 11:39:52.616
10501	20	2026-03-31 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-31 11:39:53.132
10502	22	2026-03-31 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-31 11:39:53.651
10503	25	2026-03-31 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-31 11:39:54.167
10504	30	2026-03-31 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-31 11:39:54.684
10505	31	2026-03-31 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-31 11:39:55.199
10506	34	2026-03-31 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-31 11:39:55.716
10507	39	2026-03-31 00:00:00	10	74	70.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-31 11:39:56.23
10508	155	2026-03-31 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-31 11:39:56.746
10509	42	2026-03-31 00:00:00	16	22	37.6km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-31 11:39:57.263
10510	45	2026-03-31 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-31 11:39:57.779
10511	47	2026-03-31 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-31 11:39:58.294
10512	49	2026-03-31 00:00:00	9	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-31 11:39:58.808
10513	53	2026-03-31 00:00:00	8	13	40km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-31 11:39:59.324
10514	54	2026-03-31 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-31 11:39:59.838
10515	55	2026-03-31 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-31 11:40:00.353
10516	56	2026-03-31 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-31 11:40:00.87
10517	57	2026-03-31 00:00:00	19	27	57.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-31 11:40:01.388
10518	59	2026-03-31 00:00:00	13	27	85.7km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-31 11:40:01.903
10519	61	2026-03-31 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-31 11:40:02.418
10520	64	2026-03-31 00:00:00	0	21	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-31 11:40:02.932
10521	66	2026-03-31 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-31 11:40:03.447
10522	69	2026-03-31 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-31 11:40:03.962
10523	70	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-31 11:40:04.479
10524	72	2026-03-31 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-31 11:40:04.995
10525	74	2026-03-31 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-31 11:40:05.512
10526	78	2026-03-31 00:00:00	5	28	26.5km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-31 11:40:06.028
10527	79	2026-03-31 00:00:00	11	23	63.5km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-31 11:40:06.544
10528	80	2026-03-31 00:00:00	15	23	74.21km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-31 11:40:07.061
10529	83	2026-03-31 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-31 11:40:07.579
10530	85	2026-03-31 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-31 11:40:08.096
10531	90	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-31 11:40:08.614
10532	91	2026-03-31 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-31 11:40:09.129
10533	94	2026-03-31 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-31 11:40:09.644
10534	95	2026-03-31 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-31 11:40:10.165
10535	99	2026-03-31 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-31 11:40:10.681
10536	100	2026-03-31 00:00:00	0	38	0km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-31 11:40:11.199
10537	101	2026-03-31 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-31 11:40:11.715
10538	156	2026-03-31 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-31 11:40:12.231
10539	102	2026-03-31 00:00:00	8	15	18.3km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-31 11:40:12.747
10540	62	2026-03-31 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-31 11:40:13.265
10541	81	2026-03-31 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-31 11:40:13.783
10542	1	2026-03-31 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-31 11:40:14.298
10543	2	2026-03-31 00:00:00	0	9	0km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-31 11:40:14.813
10544	4	2026-03-31 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-31 11:40:15.327
10545	107	2026-03-31 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-31 11:40:15.843
10546	108	2026-03-31 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-31 11:40:16.36
10547	5	2026-03-31 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-31 11:40:16.878
10548	6	2026-03-31 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-31 11:40:17.395
10549	7	2026-03-31 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-31 11:40:17.91
10550	8	2026-03-31 00:00:00	0	31	0km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-31 11:40:18.426
10551	98	2026-03-31 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-31 11:40:18.941
10552	10	2026-03-31 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-31 11:40:19.457
10553	109	2026-03-31 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-31 11:40:19.973
10554	13	2026-03-31 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-31 11:40:20.489
10555	110	2026-03-31 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-31 11:40:21.006
10556	14	2026-03-31 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-31 11:40:21.521
10557	16	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-31 11:40:22.036
10558	17	2026-03-31 00:00:00	0	15	0km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-31 11:40:22.551
10559	111	2026-03-31 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-31 11:40:23.068
10560	21	2026-03-31 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-31 11:40:23.583
10561	153	2026-03-31 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-31 11:40:24.098
10562	112	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-31 11:40:24.614
10563	23	2026-03-31 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-31 11:40:25.129
10564	113	2026-03-31 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-31 11:40:25.646
10565	24	2026-03-31 00:00:00	0	8	0km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-31 11:40:26.16
10566	114	2026-03-31 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-31 11:40:26.679
10567	115	2026-03-31 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-31 11:40:27.195
10568	26	2026-03-31 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-31 11:40:27.712
10569	116	2026-03-31 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-31 11:40:28.228
10570	27	2026-03-31 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-31 11:40:28.748
10571	28	2026-03-31 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-31 11:40:29.263
10572	117	2026-03-31 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-31 11:40:29.778
10573	29	2026-03-31 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-31 11:40:30.292
10574	118	2026-03-31 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-31 11:40:30.808
10575	119	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-31 11:40:31.323
10576	32	2026-03-31 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-31 11:40:31.837
10577	33	2026-03-31 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-31 11:40:32.355
10578	120	2026-03-31 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-31 11:40:32.87
10579	35	2026-03-31 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-31 11:40:33.385
10580	121	2026-03-31 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-31 11:40:33.9
10581	36	2026-03-31 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-31 11:40:34.415
10582	122	2026-03-31 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-31 11:40:34.929
10583	123	2026-03-31 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-31 11:40:35.444
10584	37	2026-03-31 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-31 11:40:35.959
10585	38	2026-03-31 00:00:00	0	42	0km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-31 11:40:36.473
10586	124	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-31 11:40:36.99
10587	125	2026-03-31 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-31 11:40:37.504
10588	126	2026-03-31 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-31 11:40:38.018
10589	127	2026-03-31 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-31 11:40:38.532
10590	41	2026-03-31 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-31 11:40:39.047
10591	128	2026-03-31 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-31 11:40:39.562
10592	43	2026-03-31 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-31 11:40:40.076
10593	44	2026-03-31 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-31 11:40:40.593
10594	40	2026-03-31 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-31 11:40:41.108
10595	129	2026-03-31 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-31 11:40:41.622
10596	130	2026-03-31 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-31 11:40:42.138
10597	131	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-31 11:40:42.653
10598	46	2026-03-31 00:00:00	0	12	0km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-31 11:40:43.167
10599	132	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-03-31 11:40:43.683
10600	48	2026-03-31 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-31 11:40:44.199
10601	133	2026-03-31 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-31 11:40:44.714
10602	50	2026-03-31 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-31 11:40:45.23
10603	134	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-31 11:40:45.745
10604	135	2026-03-31 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-31 11:40:46.259
10605	51	2026-03-31 00:00:00	6	14	5.5km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-31 11:40:46.773
10606	137	2026-03-31 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-31 11:40:47.288
10607	52	2026-03-31 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-31 11:40:47.803
10608	103	2026-03-31 00:00:00	18	64	45.5km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-31 11:40:48.317
10609	138	2026-03-31 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-31 11:40:48.833
10610	139	2026-03-31 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-31 11:40:49.349
10611	58	2026-03-31 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-31 11:40:49.869
10612	140	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-31 11:40:50.385
10613	141	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-31 11:40:50.9
10614	60	2026-03-31 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-31 11:40:51.415
10615	63	2026-03-31 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-31 11:40:51.93
10616	142	2026-03-31 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-31 11:40:52.445
10617	65	2026-03-31 00:00:00	1	22	0.8km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-31 11:40:52.96
10618	143	2026-03-31 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-31 11:40:53.474
10619	144	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-31 11:40:53.989
10620	67	2026-03-31 00:00:00	0	12	0km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-31 11:40:54.506
10621	68	2026-03-31 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-31 11:40:55.022
6021	140	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-14 00:00:00
6022	140	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-15 00:00:00
6023	140	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-16 00:00:00
6024	140	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-17 00:00:00
6025	140	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-18 00:00:00
6026	140	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-19 00:00:00
6027	140	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-20 00:00:00
6028	140	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-21 00:00:00
6029	140	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-22 00:00:00
6030	140	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-23 00:00:00
6031	140	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-24 00:00:00
6032	140	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-25 00:00:00
6033	140	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-26 00:00:00
6034	140	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-27 00:00:00
6035	140	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-02-28 00:00:00
6036	140	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-01 00:00:00
6037	140	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-02 00:00:00
6038	140	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-03 00:00:00
6039	140	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-04 00:00:00
6040	140	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-05 00:00:00
6041	140	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-06 00:00:00
6042	140	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-07 00:00:00
10622	104	2026-03-31 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-31 11:40:55.538
10623	145	2026-03-31 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-31 11:40:56.054
6044	141	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-10 00:00:00
6045	141	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-11 00:00:00
6046	141	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-12 00:00:00
6047	141	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-13 00:00:00
6048	141	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-14 00:00:00
6049	141	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-15 00:00:00
6050	141	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-16 00:00:00
6051	141	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-17 00:00:00
6052	141	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-18 00:00:00
6053	141	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-19 00:00:00
10624	146	2026-03-31 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-31 11:40:56.57
10625	71	2026-03-31 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-31 11:40:57.087
10626	147	2026-03-31 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-31 11:40:57.606
10627	73	2026-03-31 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-31 11:40:58.121
10628	75	2026-03-31 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-31 11:40:58.635
10629	76	2026-03-31 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-31 11:40:59.148
10630	77	2026-03-31 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-31 11:40:59.663
10631	148	2026-03-31 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-31 11:41:00.179
10632	105	2026-03-31 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-31 11:41:00.694
10633	82	2026-03-31 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-31 11:41:01.209
10634	154	2026-03-31 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-31 11:41:01.725
10635	84	2026-03-31 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-31 11:41:02.241
10636	149	2026-03-31 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-31 11:41:02.756
10637	86	2026-03-31 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-31 11:41:03.272
10638	150	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-31 11:41:03.788
10639	88	2026-03-31 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-31 11:41:04.303
10640	106	2026-03-31 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-31 11:41:04.82
10641	151	2026-03-31 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-31 11:41:05.334
10642	92	2026-03-31 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-31 11:41:05.849
10643	93	2026-03-31 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-31 11:41:06.364
10644	152	2026-03-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-31 11:41:06.879
10645	96	2026-03-31 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-31 11:41:07.393
10646	97	2026-03-31 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-31 11:41:07.907
10647	3	2026-04-09 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-04-09 15:14:39.4
10648	11	2026-04-09 00:00:00	12	27	92.6km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-04-09 15:14:39.459
10649	12	2026-04-09 00:00:00	0	9	0km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-04-09 15:14:39.502
10650	19	2026-04-09 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-04-09 15:14:39.54
10651	20	2026-04-09 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-04-09 15:14:39.581
10652	22	2026-04-09 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-04-09 15:14:39.618
10653	25	2026-04-09 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-04-09 15:14:39.659
10654	31	2026-04-09 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-04-09 15:14:39.694
10655	34	2026-04-09 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-04-09 15:14:39.731
10656	155	2026-04-09 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-04-09 15:14:39.766
10657	45	2026-04-09 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-04-09 15:14:39.804
10658	47	2026-04-09 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-04-09 15:14:39.84
10659	49	2026-04-09 00:00:00	0	14	0km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-04-09 15:14:39.888
10660	55	2026-04-09 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-04-09 15:14:39.927
10661	56	2026-04-09 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-04-09 15:14:39.965
10662	61	2026-04-09 00:00:00	8	11	23.1km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-04-09 15:14:40.001
10663	66	2026-04-09 00:00:00	18	22	50.3km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-04-09 15:14:40.038
10664	79	2026-04-09 00:00:00	0	23	0km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-04-09 15:14:40.078
10665	80	2026-04-09 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-04-09 15:14:40.114
10666	83	2026-04-09 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-04-09 15:14:40.15
10667	85	2026-04-09 00:00:00	0	62	0km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-04-09 15:14:40.19
10668	90	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-04-09 15:14:40.224
10669	91	2026-04-09 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-04-09 15:14:40.26
10670	94	2026-04-09 00:00:00	5	5	19.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-04-09 15:14:40.296
10671	99	2026-04-09 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-04-09 15:14:40.332
10672	100	2026-04-09 00:00:00	0	38	0km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-04-09 15:14:40.369
10673	101	2026-04-09 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-04-09 15:14:40.404
10674	156	2026-04-09 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-04-09 15:14:40.439
10675	102	2026-04-09 00:00:00	0	15	0km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-04-09 15:14:40.475
10676	81	2026-04-09 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-04-09 15:14:40.51
10677	1	2026-04-09 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-04-09 15:14:40.547
10678	2	2026-04-09 00:00:00	0	9	0km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-04-09 15:14:40.584
10679	4	2026-04-09 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-04-09 15:14:40.621
10680	107	2026-04-09 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-04-09 15:14:40.656
10681	108	2026-04-09 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-04-09 15:14:40.69
10682	5	2026-04-09 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-04-09 15:14:40.725
10683	6	2026-04-09 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-04-09 15:14:40.76
10684	7	2026-04-09 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-04-09 15:14:40.797
10685	8	2026-04-09 00:00:00	0	31	0km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-04-09 15:14:40.834
10686	98	2026-04-09 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-04-09 15:14:40.873
10687	9	2026-04-09 00:00:00	0	23	0km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-04-09 15:14:40.907
10688	10	2026-04-09 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-04-09 15:14:40.945
10689	109	2026-04-09 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-04-09 15:14:40.982
10690	13	2026-04-09 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-04-09 15:14:41.017
10691	110	2026-04-09 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-04-09 15:14:41.054
10692	14	2026-04-09 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-04-09 15:14:41.089
10693	15	2026-04-09 00:00:00	0	9	0km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-04-09 15:14:41.126
10694	16	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-04-09 15:14:41.163
10695	17	2026-04-09 00:00:00	0	15	0km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-04-09 15:14:41.198
10696	111	2026-04-09 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-04-09 15:14:41.233
10697	18	2026-04-09 00:00:00	0	12	0km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-04-09 15:14:41.27
10698	21	2026-04-09 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-04-09 15:14:41.305
10699	153	2026-04-09 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-04-09 15:14:41.341
10700	112	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-04-09 15:14:41.379
10701	23	2026-04-09 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-04-09 15:14:41.416
10702	113	2026-04-09 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-04-09 15:14:41.449
10703	24	2026-04-09 00:00:00	0	8	0km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-04-09 15:14:41.484
10704	114	2026-04-09 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-04-09 15:14:41.522
10705	115	2026-04-09 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-04-09 15:14:41.557
10706	26	2026-04-09 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-04-09 15:14:41.594
10707	116	2026-04-09 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-04-09 15:14:41.63
10708	27	2026-04-09 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-04-09 15:14:41.669
10709	28	2026-04-09 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-04-09 15:14:41.705
10710	117	2026-04-09 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-04-09 15:14:41.742
10711	29	2026-04-09 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-04-09 15:14:41.778
10712	118	2026-04-09 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-04-09 15:14:41.816
10713	119	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-04-09 15:14:41.85
10714	30	2026-04-09 00:00:00	0	13	0km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-04-09 15:14:41.884
10715	32	2026-04-09 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-04-09 15:14:41.921
10716	33	2026-04-09 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-04-09 15:14:41.956
10717	120	2026-04-09 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-04-09 15:14:41.991
10718	35	2026-04-09 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-04-09 15:14:42.028
10719	121	2026-04-09 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-04-09 15:14:42.064
10720	36	2026-04-09 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-04-09 15:14:42.099
10721	122	2026-04-09 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-04-09 15:14:42.133
10722	123	2026-04-09 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-04-09 15:14:42.168
10723	37	2026-04-09 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-04-09 15:14:42.204
10724	38	2026-04-09 00:00:00	0	42	0km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-04-09 15:14:42.238
10725	124	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-04-09 15:14:42.276
10726	125	2026-04-09 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-04-09 15:14:42.312
10727	39	2026-04-09 00:00:00	0	74	0km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-04-09 15:14:42.347
10728	126	2026-04-09 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-04-09 15:14:42.384
10729	40	2026-04-09 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-04-09 15:14:42.422
10730	127	2026-04-09 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-04-09 15:14:42.456
10731	41	2026-04-09 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-04-09 15:14:42.491
10732	128	2026-04-09 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-04-09 15:14:42.526
10733	42	2026-04-09 00:00:00	13	22	31.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-04-09 15:14:42.562
10734	43	2026-04-09 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-04-09 15:14:42.595
10735	44	2026-04-09 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-04-09 15:14:42.633
10736	129	2026-04-09 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-04-09 15:14:42.667
10737	130	2026-04-09 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-04-09 15:14:42.701
10738	131	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-04-09 15:14:42.737
10739	46	2026-04-09 00:00:00	0	12	0km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-04-09 15:14:42.769
10740	132	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-04-09 15:14:42.803
10741	48	2026-04-09 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-04-09 15:14:42.837
10742	133	2026-04-09 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-04-09 15:14:42.871
10743	50	2026-04-09 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-04-09 15:14:42.902
10744	134	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-04-09 15:14:42.938
10745	135	2026-04-09 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-04-09 15:14:42.975
10746	51	2026-04-09 00:00:00	6	14	5.5km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-04-09 15:14:43.011
10747	137	2026-04-09 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-04-09 15:14:43.046
10748	52	2026-04-09 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-04-09 15:14:43.084
10749	53	2026-04-09 00:00:00	0	13	0km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-04-09 15:14:43.12
10750	103	2026-04-09 00:00:00	7	64	18.85km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-04-09 15:14:43.153
10751	138	2026-04-09 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-04-09 15:14:43.186
10752	57	2026-04-09 00:00:00	0	27	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-04-09 15:14:43.219
10753	139	2026-04-09 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-04-09 15:14:43.253
10754	58	2026-04-09 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-04-09 15:14:43.288
10755	140	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-04-09 15:14:43.322
10756	141	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-04-09 15:14:43.355
10757	59	2026-04-09 00:00:00	0	27	0km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-04-09 15:14:43.388
10758	60	2026-04-09 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-04-09 15:14:43.426
10759	62	2026-04-09 00:00:00	0	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-04-09 15:14:43.46
10760	63	2026-04-09 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-04-09 15:14:43.494
10761	142	2026-04-09 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-04-09 15:14:43.527
10762	64	2026-04-09 00:00:00	0	21	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-04-09 15:14:43.559
10763	65	2026-04-09 00:00:00	0	22	0km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-04-09 15:14:43.595
10764	143	2026-04-09 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-04-09 15:14:43.628
10765	144	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-04-09 15:14:43.661
10766	67	2026-04-09 00:00:00	0	12	0km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-04-09 15:14:43.694
10767	68	2026-04-09 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-04-09 15:14:43.728
10768	69	2026-04-09 00:00:00	0	12	0km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:14:43.761
10769	104	2026-04-09 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-04-09 15:14:43.796
10770	145	2026-04-09 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-04-09 15:14:43.83
10771	146	2026-04-09 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-04-09 15:14:43.865
10772	70	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-04-09 15:14:43.9
10773	71	2026-04-09 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-04-09 15:14:43.936
10774	72	2026-04-09 00:00:00	0	30	0km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-04-09 15:14:43.972
10775	147	2026-04-09 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-04-09 15:14:44.007
10776	73	2026-04-09 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-04-09 15:14:44.038
10777	74	2026-04-09 00:00:00	0	6	0km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-04-09 15:14:44.072
10778	75	2026-04-09 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-04-09 15:14:44.105
10779	76	2026-04-09 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-04-09 15:14:44.14
10780	77	2026-04-09 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-04-09 15:14:44.174
10781	148	2026-04-09 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-04-09 15:14:44.208
10782	105	2026-04-09 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-04-09 15:14:44.244
10783	78	2026-04-09 00:00:00	0	28	0km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-04-09 15:14:44.279
10784	82	2026-04-09 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-04-09 15:14:44.313
10785	154	2026-04-09 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-04-09 15:14:44.346
10786	84	2026-04-09 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-04-09 15:14:44.381
10787	149	2026-04-09 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-04-09 15:14:44.415
10788	86	2026-04-09 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-04-09 15:14:44.45
10789	150	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-04-09 15:14:44.484
10790	88	2026-04-09 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-04-09 15:14:44.516
10791	106	2026-04-09 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-04-09 15:14:44.551
10792	151	2026-04-09 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-04-09 15:14:44.585
10793	92	2026-04-09 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-04-09 15:14:44.621
10794	93	2026-04-09 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-04-09 15:14:44.654
10795	95	2026-04-09 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-04-09 15:14:44.687
10796	152	2026-04-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-04-09 15:14:44.722
10797	96	2026-04-09 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-04-09 15:14:44.756
10798	97	2026-04-09 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-04-09 15:14:44.789
10799	69	2026-04-01 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.421
10800	69	2026-04-02 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.437
10801	69	2026-04-03 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.448
10802	69	2026-04-04 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.459
10803	69	2026-04-05 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.468
10804	69	2026-04-06 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.479
10805	69	2026-04-07 00:00:00	0	12	0km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.492
10806	69	2026-04-08 00:00:00	0	12	0km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-09 15:27:23.507
6299	142	2026-03-10 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-10 00:00:00
6300	142	2026-03-11 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-11 00:00:00
6301	142	2026-03-12 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-12 00:00:00
6302	142	2026-03-13 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-13 00:00:00
6303	142	2026-03-14 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-14 00:00:00
6304	142	2026-03-15 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-15 00:00:00
6305	142	2026-03-16 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-16 00:00:00
6306	142	2026-03-17 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-17 00:00:00
6307	142	2026-03-18 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-18 00:00:00
6308	142	2026-03-19 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-19 00:00:00
10808	11	2026-04-10 00:00:00	12	27	92.6km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-04-10 08:13:18.299
10809	12	2026-04-10 00:00:00	0	9	0km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-04-10 08:13:18.734
10810	19	2026-04-10 00:00:00	11	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-04-10 08:13:19.164
10811	20	2026-04-10 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-04-10 08:13:19.594
10812	22	2026-04-10 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-04-10 08:13:20.024
10813	25	2026-04-10 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-04-10 08:13:20.453
10814	31	2026-04-10 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-04-10 08:13:20.892
10815	34	2026-04-10 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-04-10 08:13:21.321
10816	155	2026-04-10 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-04-10 08:13:21.751
10817	45	2026-04-10 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-04-10 08:13:22.179
10818	47	2026-04-10 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-04-10 08:13:22.608
10819	49	2026-04-10 00:00:00	0	14	0km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-04-10 08:13:23.036
10820	55	2026-04-10 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-04-10 08:13:23.467
10821	56	2026-04-10 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-04-10 08:13:23.897
10822	61	2026-04-10 00:00:00	8	11	23.1km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-04-10 08:13:24.325
10823	66	2026-04-10 00:00:00	18	22	50.3km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-04-10 08:13:24.754
10824	79	2026-04-10 00:00:00	0	23	0km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-04-10 08:13:25.184
10825	80	2026-04-10 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-04-10 08:13:25.613
10826	83	2026-04-10 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-04-10 08:13:26.043
10827	85	2026-04-10 00:00:00	0	62	0km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-04-10 08:13:26.471
10828	90	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-04-10 08:13:26.9
10829	91	2026-04-10 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-04-10 08:13:27.329
10830	94	2026-04-10 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-04-10 08:13:27.76
10831	99	2026-04-10 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-04-10 08:13:28.188
10833	101	2026-04-10 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-04-10 08:13:29.046
10834	156	2026-04-10 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-04-10 08:13:29.476
10835	102	2026-04-10 00:00:00	0	15	0km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-04-10 08:13:29.91
10836	81	2026-04-10 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-04-10 08:13:30.338
10837	1	2026-04-10 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-04-10 08:13:30.769
10838	2	2026-04-10 00:00:00	0	9	0km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-04-10 08:13:31.197
10839	4	2026-04-10 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-04-10 08:13:31.625
10840	107	2026-04-10 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-04-10 08:13:32.055
10841	108	2026-04-10 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-04-10 08:13:32.485
10842	5	2026-04-10 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-04-10 08:13:32.914
10843	6	2026-04-10 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-04-10 08:13:33.343
10844	7	2026-04-10 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-04-10 08:13:33.772
10845	8	2026-04-10 00:00:00	0	31	0km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-04-10 08:13:34.201
10846	98	2026-04-10 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-04-10 08:13:34.629
10847	9	2026-04-10 00:00:00	0	23	0km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-04-10 08:13:35.06
10848	10	2026-04-10 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-04-10 08:13:35.488
10849	109	2026-04-10 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-04-10 08:13:35.915
10850	13	2026-04-10 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-04-10 08:13:36.343
10851	110	2026-04-10 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-04-10 08:13:36.77
10852	14	2026-04-10 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-04-10 08:13:37.201
10853	15	2026-04-10 00:00:00	0	9	0km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-04-10 08:13:37.628
10854	16	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-04-10 08:13:38.058
10855	17	2026-04-10 00:00:00	0	15	0km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-04-10 08:13:38.486
10856	111	2026-04-10 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-04-10 08:13:38.914
10857	18	2026-04-10 00:00:00	0	12	0km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-04-10 08:13:39.342
10858	21	2026-04-10 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-04-10 08:13:39.769
10860	112	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-04-10 08:13:40.627
10861	23	2026-04-10 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-04-10 08:13:41.055
10862	113	2026-04-10 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-04-10 08:13:41.483
10863	24	2026-04-10 00:00:00	0	8	0km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-04-10 08:13:41.911
10864	114	2026-04-10 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-04-10 08:13:42.34
10865	115	2026-04-10 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-04-10 08:13:42.768
10866	26	2026-04-10 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-04-10 08:13:43.197
10867	116	2026-04-10 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-04-10 08:13:43.626
10868	27	2026-04-10 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-04-10 08:13:44.054
10869	28	2026-04-10 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-04-10 08:13:44.483
10870	117	2026-04-10 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-04-10 08:13:44.913
10871	29	2026-04-10 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-04-10 08:13:45.341
10872	118	2026-04-10 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-04-10 08:13:45.77
10874	30	2026-04-10 00:00:00	0	13	0km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-04-10 08:13:46.626
10875	32	2026-04-10 00:00:00	0	46	0km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-04-10 08:13:47.054
10876	33	2026-04-10 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-04-10 08:13:47.484
10877	120	2026-04-10 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-04-10 08:13:47.912
10878	35	2026-04-10 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-04-10 08:13:48.34
10879	121	2026-04-10 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-04-10 08:13:48.769
10880	36	2026-04-10 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-04-10 08:13:49.197
10881	122	2026-04-10 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-04-10 08:13:49.626
10882	123	2026-04-10 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-04-10 08:13:50.054
10883	37	2026-04-10 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-04-10 08:13:50.481
10884	38	2026-04-10 00:00:00	0	42	0km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-04-10 08:13:50.911
10885	124	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-04-10 08:13:51.339
10886	125	2026-04-10 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-04-10 08:13:51.767
10887	39	2026-04-10 00:00:00	0	74	0km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-04-10 08:13:52.196
10888	126	2026-04-10 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-04-10 08:13:52.624
10889	40	2026-04-10 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-04-10 08:13:53.052
10890	127	2026-04-10 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-04-10 08:13:53.481
10891	41	2026-04-10 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-04-10 08:13:53.909
10892	128	2026-04-10 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-04-10 08:13:54.337
10893	42	2026-04-10 00:00:00	13	22	31.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-04-10 08:13:54.765
10894	43	2026-04-10 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-04-10 08:13:55.193
10895	44	2026-04-10 00:00:00	0	8	0km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-04-10 08:13:55.62
10896	129	2026-04-10 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-04-10 08:13:56.048
10897	130	2026-04-10 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-04-10 08:13:56.476
10898	131	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-04-10 08:13:56.903
10899	46	2026-04-10 00:00:00	0	12	0km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-04-10 08:13:57.331
10900	132	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/laubert-plateau-du-roy/	2026-04-10 08:13:57.758
10901	48	2026-04-10 00:00:00	0	26	0km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-04-10 08:13:58.187
10902	133	2026-04-10 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-04-10 08:13:58.614
10903	50	2026-04-10 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-04-10 08:13:59.042
10904	134	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-04-10 08:13:59.47
10905	135	2026-04-10 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-04-10 08:13:59.898
10906	51	2026-04-10 00:00:00	6	14	5.5km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-04-10 08:14:00.325
10907	137	2026-04-10 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-04-10 08:14:00.753
10908	52	2026-04-10 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-04-10 08:14:01.186
10909	53	2026-04-10 00:00:00	0	13	0km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-04-10 08:14:01.613
10910	103	2026-04-10 00:00:00	7	64	18.85km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-04-10 08:14:02.041
10911	138	2026-04-10 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-04-10 08:14:02.469
10912	57	2026-04-10 00:00:00	0	27	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-04-10 08:14:02.897
10913	139	2026-04-10 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-04-10 08:14:03.325
10914	58	2026-04-10 00:00:00	0	17	0km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-04-10 08:14:03.753
10915	140	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-04-10 08:14:04.181
10916	141	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-04-10 08:14:04.609
10917	59	2026-04-10 00:00:00	0	27	0km/210km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-04-10 08:14:05.037
10918	60	2026-04-10 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-04-10 08:14:05.465
10919	62	2026-04-10 00:00:00	0	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-04-10 08:14:05.892
10920	63	2026-04-10 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-04-10 08:14:06.32
10921	142	2026-04-10 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-04-10 08:14:06.749
10922	64	2026-04-10 00:00:00	0	21	0km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-04-10 08:14:07.178
10923	65	2026-04-10 00:00:00	0	22	0km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-04-10 08:14:07.605
10924	143	2026-04-10 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-04-10 08:14:08.034
10925	144	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-04-10 08:14:08.461
10926	67	2026-04-10 00:00:00	0	12	0km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-04-10 08:14:08.889
10927	68	2026-04-10 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-04-10 08:14:09.317
10928	69	2026-04-10 00:00:00	0	12	0km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-04-10 08:14:09.745
10929	104	2026-04-10 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-04-10 08:14:10.173
10930	145	2026-04-10 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-04-10 08:14:10.601
10931	146	2026-04-10 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-04-10 08:14:11.029
10932	70	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-04-10 08:14:11.457
10933	71	2026-04-10 00:00:00	0	28	0km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-04-10 08:14:11.885
10934	72	2026-04-10 00:00:00	0	30	0km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-04-10 08:14:12.314
10935	147	2026-04-10 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-04-10 08:14:12.742
10936	73	2026-04-10 00:00:00	2	21	10.5km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-04-10 08:14:13.171
10937	74	2026-04-10 00:00:00	0	6	0km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-04-10 08:14:13.6
10938	75	2026-04-10 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-04-10 08:14:14.029
10939	76	2026-04-10 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-04-10 08:14:14.457
10940	77	2026-04-10 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-04-10 08:14:14.888
10941	148	2026-04-10 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-04-10 08:14:15.315
10942	105	2026-04-10 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-04-10 08:14:15.746
10943	78	2026-04-10 00:00:00	0	28	0km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-04-10 08:14:16.173
10944	82	2026-04-10 00:00:00	0	16	0km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-04-10 08:14:16.602
10945	154	2026-04-10 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-04-10 08:14:17.03
10946	84	2026-04-10 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-04-10 08:14:17.46
10947	149	2026-04-10 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-04-10 08:14:17.89
10948	86	2026-04-10 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-04-10 08:14:18.318
10949	150	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-04-10 08:14:18.746
10950	88	2026-04-10 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-04-10 08:14:19.174
10951	106	2026-04-10 00:00:00	0	49	0km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-04-10 08:14:19.601
10952	151	2026-04-10 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-04-10 08:14:20.029
10953	92	2026-04-10 00:00:00	0	22	0km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-04-10 08:14:20.457
10954	93	2026-04-10 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-04-10 08:14:20.884
10955	95	2026-04-10 00:00:00	3	16	14km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-04-10 08:14:21.312
10956	152	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-04-10 08:14:21.741
10957	96	2026-04-10 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-04-10 08:14:22.171
10958	97	2026-04-10 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-04-10 08:14:22.598
10807	3	2026-04-10 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-04-10 08:13:17.851
10832	100	2026-04-10 00:00:00	0	38	0km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-04-10 08:13:28.616
10859	153	2026-04-10 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-04-10 08:13:40.199
10873	119	2026-04-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-04-10 08:13:46.198
6599	144	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-09 00:00:00
6595	143	2026-03-10 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-10 00:00:00
6600	144	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-10 00:00:00
6596	143	2026-03-11 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-11 00:00:00
6597	143	2026-03-12 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-12 00:00:00
6598	143	2026-03-13 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-13 00:00:00
10959	3	2026-04-11 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-04-11 07:41:15.38
10960	11	2026-04-11 00:00:00	12	27	92.6km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-04-11 07:41:15.918
10961	12	2026-04-11 00:00:00	0	9	0km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-04-11 07:41:16.452
10963	20	2026-04-11 00:00:00	22	25	74.1km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-04-11 07:41:17.497
10964	22	2026-04-11 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-04-11 07:41:18.021
10965	25	2026-04-11 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-04-11 07:41:18.543
10966	31	2026-04-11 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-04-11 07:41:19.068
10967	34	2026-04-11 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-04-11 07:41:19.596
10968	155	2026-04-11 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-04-11 07:41:20.118
10969	45	2026-04-11 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-04-11 07:41:20.639
10970	47	2026-04-11 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-04-11 07:41:21.162
10971	49	2026-04-11 00:00:00	0	14	0km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-04-11 07:41:21.684
10972	55	2026-04-11 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-04-11 07:41:22.208
10973	56	2026-04-11 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-04-11 07:41:22.73
10974	61	2026-04-11 00:00:00	8	11	23.1km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-04-11 07:41:23.252
10975	66	2026-04-11 00:00:00	18	22	50.3km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-04-11 07:41:23.773
10976	79	2026-04-11 00:00:00	0	23	0km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-04-11 07:41:24.297
10977	80	2026-04-11 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-04-11 07:41:24.819
10978	83	2026-04-11 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-04-11 07:41:25.342
10979	85	2026-04-11 00:00:00	0	62	0km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-04-11 07:41:25.863
10980	90	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-04-11 07:41:26.388
10981	91	2026-04-11 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-04-11 07:41:26.91
10982	94	2026-04-11 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-04-11 07:41:27.431
10983	99	2026-04-11 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-04-11 07:41:27.953
10985	101	2026-04-11 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-04-11 07:41:28.998
10986	156	2026-04-11 00:00:00	0	18	0km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-04-11 07:41:29.519
10987	102	2026-04-11 00:00:00	0	15	0km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-04-11 07:41:30.041
10988	81	2026-04-11 00:00:00	0	6	0km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-04-11 07:41:30.571
10989	1	2026-04-11 00:00:00	0	17	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-04-11 07:41:31.092
10990	2	2026-04-11 00:00:00	0	9	0km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-04-11 07:41:31.613
10991	4	2026-04-11 00:00:00	0	21	0km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-04-11 07:41:32.136
10992	107	2026-04-11 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-04-11 07:41:32.658
10993	108	2026-04-11 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-04-11 07:41:33.18
10994	5	2026-04-11 00:00:00	0	17	0km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-04-11 07:41:33.702
10995	6	2026-04-11 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-04-11 07:41:34.226
10996	7	2026-04-11 00:00:00	0	10	0km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-04-11 07:41:34.747
10997	8	2026-04-11 00:00:00	0	31	0km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-04-11 07:41:35.268
10998	98	2026-04-11 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-04-11 07:41:35.79
10999	9	2026-04-11 00:00:00	0	23	0km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-04-11 07:41:36.312
11000	10	2026-04-11 00:00:00	1	8	10km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-04-11 07:41:36.833
11001	109	2026-04-11 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-04-11 07:41:37.355
11002	13	2026-04-11 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-04-11 07:41:37.877
11003	110	2026-04-11 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-04-11 07:41:38.398
11004	14	2026-04-11 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-04-11 07:41:38.92
11005	15	2026-04-11 00:00:00	0	9	0km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-04-11 07:41:39.442
11006	16	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-04-11 07:41:39.965
11007	17	2026-04-11 00:00:00	0	15	0km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-04-11 07:41:40.486
11008	111	2026-04-11 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-04-11 07:41:41.007
11009	18	2026-04-11 00:00:00	0	12	0km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-04-11 07:41:41.528
11010	21	2026-04-11 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-04-11 07:41:42.049
11011	153	2026-04-11 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-04-11 07:41:42.57
11012	112	2026-04-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-04-11 07:41:43.096
11013	23	2026-04-11 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-04-11 07:41:43.617
11014	113	2026-04-11 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-04-11 07:41:44.139
11015	24	2026-04-11 00:00:00	0	8	0km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-04-11 07:41:44.662
11016	114	2026-04-11 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-04-11 07:41:45.184
11017	115	2026-04-11 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-04-11 07:41:45.705
11018	26	2026-04-11 00:00:00	0	14	0km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-04-11 07:41:46.226
11019	116	2026-04-11 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-04-11 07:41:46.749
11020	27	2026-04-11 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-04-11 07:41:47.271
11021	28	2026-04-11 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-04-11 07:41:47.795
11022	117	2026-04-11 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-04-11 07:41:48.316
6602	144	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-12 00:00:00
6603	144	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-13 00:00:00
6604	144	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-14 00:00:00
6605	144	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-15 00:00:00
6606	144	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-16 00:00:00
6607	144	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-17 00:00:00
6608	144	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-18 00:00:00
6609	144	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-19 00:00:00
6877	145	2026-02-21 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-21 00:00:00
6878	145	2026-02-22 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-22 00:00:00
6879	145	2026-02-23 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-23 00:00:00
6880	145	2026-02-24 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-24 00:00:00
6881	145	2026-02-25 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-25 00:00:00
6882	145	2026-02-26 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-26 00:00:00
6883	145	2026-02-27 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-27 00:00:00
6884	145	2026-02-28 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-02-28 00:00:00
6885	145	2026-03-01 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-01 00:00:00
6886	145	2026-03-02 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-02 00:00:00
6887	145	2026-03-03 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-03 00:00:00
6888	145	2026-03-04 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-04 00:00:00
6889	145	2026-03-05 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-05 00:00:00
6890	145	2026-03-06 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-06 00:00:00
6891	145	2026-03-07 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-07 00:00:00
6892	146	2026-02-25 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-02-25 00:00:00
6893	146	2026-02-26 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-02-26 00:00:00
6894	146	2026-02-27 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-02-27 00:00:00
6895	146	2026-02-28 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-02-28 00:00:00
6896	146	2026-03-01 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-01 00:00:00
6897	146	2026-03-02 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-02 00:00:00
6898	146	2026-03-03 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-03 00:00:00
6899	146	2026-03-04 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-04 00:00:00
6900	146	2026-03-05 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-05 00:00:00
6901	146	2026-03-06 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-06 00:00:00
6902	146	2026-03-07 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-07 00:00:00
6903	147	2026-02-12 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-12 00:00:00
6904	147	2026-02-13 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-13 00:00:00
6905	147	2026-02-14 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-14 00:00:00
6906	147	2026-02-15 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-15 00:00:00
6907	147	2026-02-16 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-16 00:00:00
6908	147	2026-02-17 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-17 00:00:00
6909	147	2026-02-18 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-18 00:00:00
6910	147	2026-02-19 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-19 00:00:00
6911	147	2026-02-20 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-20 00:00:00
6912	147	2026-02-21 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-21 00:00:00
6913	147	2026-02-22 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-22 00:00:00
6914	147	2026-02-23 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-23 00:00:00
6915	147	2026-02-24 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-24 00:00:00
6916	147	2026-02-25 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-25 00:00:00
6917	147	2026-02-26 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-26 00:00:00
6918	147	2026-02-27 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-27 00:00:00
6919	147	2026-02-28 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-02-28 00:00:00
6920	147	2026-03-01 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-01 00:00:00
6921	147	2026-03-02 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-02 00:00:00
6922	147	2026-03-03 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-03 00:00:00
6923	147	2026-03-04 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-04 00:00:00
6924	147	2026-03-05 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-05 00:00:00
6925	147	2026-03-06 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-06 00:00:00
6926	147	2026-03-07 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-07 00:00:00
6927	148	2026-02-04 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-04 00:00:00
6928	148	2026-02-05 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-05 00:00:00
6929	148	2026-02-06 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-06 00:00:00
6930	148	2026-02-07 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-07 00:00:00
6931	148	2026-02-08 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-08 00:00:00
6932	148	2026-02-09 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-09 00:00:00
6933	148	2026-02-10 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-10 00:00:00
6934	148	2026-02-11 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-11 00:00:00
6935	148	2026-02-12 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-12 00:00:00
6936	148	2026-02-13 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-13 00:00:00
6937	148	2026-02-14 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-14 00:00:00
6938	148	2026-02-15 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-15 00:00:00
6939	148	2026-02-16 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-16 00:00:00
6940	148	2026-02-17 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-17 00:00:00
6941	148	2026-02-18 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-18 00:00:00
6942	148	2026-02-19 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-19 00:00:00
6943	148	2026-02-20 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-20 00:00:00
6944	148	2026-02-21 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-21 00:00:00
6945	148	2026-02-22 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-22 00:00:00
6946	148	2026-02-23 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-23 00:00:00
6947	148	2026-02-24 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-24 00:00:00
6948	148	2026-02-25 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-25 00:00:00
6949	148	2026-02-26 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-26 00:00:00
6950	148	2026-02-27 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-27 00:00:00
6951	148	2026-02-28 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-02-28 00:00:00
6952	148	2026-03-01 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-01 00:00:00
6953	148	2026-03-02 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-02 00:00:00
6954	148	2026-03-03 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-03 00:00:00
6955	148	2026-03-04 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-04 00:00:00
6956	148	2026-03-05 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-05 00:00:00
6957	148	2026-03-06 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-06 00:00:00
6958	148	2026-03-07 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-07 00:00:00
6967	150	2026-01-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-14 00:00:00
6968	150	2026-01-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-15 00:00:00
6969	150	2026-01-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-16 00:00:00
6970	150	2026-01-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-17 00:00:00
6971	150	2026-01-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-18 00:00:00
6972	150	2026-01-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-19 00:00:00
6973	150	2026-01-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-20 00:00:00
6974	150	2026-01-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-21 00:00:00
6975	150	2026-01-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-22 00:00:00
6976	150	2026-01-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-23 00:00:00
6977	150	2026-01-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-24 00:00:00
6978	150	2026-01-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-25 00:00:00
6979	150	2026-01-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-26 00:00:00
6980	150	2026-01-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-27 00:00:00
6981	150	2026-01-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-28 00:00:00
6982	150	2026-01-29 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-29 00:00:00
6983	150	2026-01-30 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-30 00:00:00
6984	150	2026-01-31 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-01-31 00:00:00
6985	150	2026-02-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-01 00:00:00
6986	150	2026-02-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-02 00:00:00
6987	150	2026-02-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-03 00:00:00
6988	150	2026-02-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-04 00:00:00
6989	150	2026-02-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-05 00:00:00
6990	150	2026-02-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-06 00:00:00
6960	149	2026-03-10 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-10 00:00:00
6961	149	2026-03-11 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-11 00:00:00
6962	149	2026-03-12 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-12 00:00:00
6963	149	2026-03-13 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-13 00:00:00
6964	149	2026-03-14 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-14 00:00:00
6965	149	2026-03-15 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-15 00:00:00
6966	149	2026-03-16 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-16 00:00:00
6991	150	2026-02-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-07 00:00:00
6992	150	2026-02-08 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-08 00:00:00
6993	150	2026-02-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-09 00:00:00
6994	150	2026-02-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-10 00:00:00
6995	150	2026-02-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-11 00:00:00
6996	150	2026-02-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-12 00:00:00
6997	150	2026-02-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-13 00:00:00
6998	150	2026-02-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-14 00:00:00
6999	150	2026-02-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-15 00:00:00
7000	150	2026-02-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-16 00:00:00
7001	150	2026-02-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-17 00:00:00
7002	150	2026-02-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-18 00:00:00
7003	150	2026-02-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-19 00:00:00
7004	150	2026-02-20 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-20 00:00:00
7005	150	2026-02-21 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-21 00:00:00
7006	150	2026-02-22 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-22 00:00:00
7007	150	2026-02-23 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-23 00:00:00
7008	150	2026-02-24 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-24 00:00:00
7009	150	2026-02-25 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-25 00:00:00
7010	150	2026-02-26 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-26 00:00:00
7011	150	2026-02-27 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-27 00:00:00
7012	150	2026-02-28 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-02-28 00:00:00
7013	150	2026-03-01 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-01 00:00:00
7014	150	2026-03-02 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-02 00:00:00
7015	150	2026-03-03 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-03 00:00:00
7016	150	2026-03-04 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-04 00:00:00
7017	150	2026-03-05 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-05 00:00:00
7018	150	2026-03-06 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-06 00:00:00
7019	150	2026-03-07 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-07 00:00:00
7020	151	2026-01-25 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-25 00:00:00
7021	151	2026-01-26 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-26 00:00:00
7022	151	2026-01-27 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-27 00:00:00
7023	151	2026-01-28 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-28 00:00:00
7024	151	2026-01-29 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-29 00:00:00
7025	151	2026-01-30 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-30 00:00:00
7026	151	2026-01-31 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-01-31 00:00:00
7027	151	2026-02-01 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-01 00:00:00
7028	151	2026-02-02 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-02 00:00:00
7029	151	2026-02-03 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-03 00:00:00
7030	151	2026-02-04 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-04 00:00:00
7031	151	2026-02-05 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-05 00:00:00
7032	151	2026-02-06 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-06 00:00:00
7033	151	2026-02-07 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-07 00:00:00
7034	151	2026-02-08 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-08 00:00:00
7035	151	2026-02-09 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-09 00:00:00
7036	151	2026-02-10 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-10 00:00:00
7037	151	2026-02-11 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-11 00:00:00
7038	151	2026-02-12 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-12 00:00:00
7039	151	2026-02-13 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-13 00:00:00
7040	151	2026-02-14 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-14 00:00:00
7041	151	2026-02-15 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-15 00:00:00
7042	151	2026-02-16 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-16 00:00:00
7043	151	2026-02-17 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-17 00:00:00
7044	151	2026-02-18 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-18 00:00:00
7045	151	2026-02-19 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-19 00:00:00
7046	151	2026-02-20 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-20 00:00:00
7047	151	2026-02-21 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-21 00:00:00
7048	151	2026-02-22 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-22 00:00:00
7049	151	2026-02-23 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-23 00:00:00
7050	151	2026-02-24 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-24 00:00:00
7051	151	2026-02-25 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-25 00:00:00
7052	151	2026-02-26 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-26 00:00:00
7053	151	2026-02-27 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-27 00:00:00
7054	151	2026-02-28 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-02-28 00:00:00
7055	151	2026-03-01 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-01 00:00:00
7056	151	2026-03-02 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-02 00:00:00
7057	151	2026-03-03 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-03 00:00:00
7058	151	2026-03-04 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-04 00:00:00
7059	151	2026-03-05 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-05 00:00:00
7060	151	2026-03-06 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-06 00:00:00
7061	151	2026-03-07 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-07 00:00:00
7063	152	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-10 00:00:00
7064	152	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-11 00:00:00
7065	152	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-12 00:00:00
7066	152	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-13 00:00:00
7067	152	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-14 00:00:00
7068	152	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-15 00:00:00
7069	152	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-16 00:00:00
7071	152	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-18 00:00:00
7072	152	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-19 00:00:00
7148	153	2026-03-03 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-03 00:00:00
7149	153	2026-03-07 00:00:00	17	25	108km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-07 00:00:00
7150	154	2026-03-06 00:00:00	19	24	118.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-06 00:00:00
7151	155	2026-03-07 00:00:00	30	35	179.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-07 00:00:00
7193	48	2026-03-09 00:00:00	6	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-09 00:00:00
7194	49	2026-03-09 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-09 00:00:00
7195	51	2026-03-09 00:00:00	14	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-09 00:00:00
7196	52	2026-03-09 00:00:00	2	41	9.8km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-09 00:00:00
7197	53	2026-03-09 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-09 00:00:00
7198	54	2026-03-09 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-09 00:00:00
7199	55	2026-03-09 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-09 00:00:00
7200	56	2026-03-09 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-09 00:00:00
7201	57	2026-03-09 00:00:00	25	27	78.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-09 00:00:00
7202	58	2026-03-09 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-09 00:00:00
7203	59	2026-03-09 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-09 00:00:00
7204	60	2026-03-09 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-09 00:00:00
7205	61	2026-03-09 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-09 00:00:00
7206	64	2026-03-09 00:00:00	20	21	80.6km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-09 00:00:00
7207	65	2026-03-09 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-09 00:00:00
7208	66	2026-03-09 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-09 00:00:00
7209	67	2026-03-09 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-09 00:00:00
7210	69	2026-03-09 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-09 00:00:00
7211	70	2026-03-09 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-09 00:00:00
7212	71	2026-03-09 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-09 00:00:00
7213	72	2026-03-09 00:00:00	30	30	99.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-09 00:00:00
7214	73	2026-03-09 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-09 00:00:00
7215	74	2026-03-09 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-09 00:00:00
7216	76	2026-03-09 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-09 00:00:00
7217	77	2026-03-09 00:00:00	3	3	11.5km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-09 00:00:00
7218	78	2026-03-09 00:00:00	21	28	113.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-09 00:00:00
7219	79	2026-03-09 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-09 00:00:00
7220	80	2026-03-09 00:00:00	23	23	122.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-09 00:00:00
7221	81	2026-03-09 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-09 00:00:00
7222	82	2026-03-09 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-09 00:00:00
7223	83	2026-03-09 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-09 00:00:00
7224	154	2026-03-09 00:00:00	19	24	118.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-09 00:00:00
7225	85	2026-03-09 00:00:00	29	62	145.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-09 00:00:00
7226	88	2026-03-09 00:00:00	6	13	29.7km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-09 00:00:00
7227	90	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-09 00:00:00
7228	91	2026-03-09 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-09 00:00:00
7229	92	2026-03-09 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-09 00:00:00
7230	94	2026-03-09 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-09 00:00:00
7231	95	2026-03-09 00:00:00	14	16	51km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-09 00:00:00
7232	96	2026-03-09 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-09 00:00:00
7233	97	2026-03-09 00:00:00	6	12	8.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-09 00:00:00
7234	98	2026-03-09 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-09 00:00:00
7235	99	2026-03-09 00:00:00	9	9	68km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-09 00:00:00
7236	100	2026-03-09 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-09 00:00:00
7237	101	2026-03-09 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-09 00:00:00
7238	102	2026-03-09 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-09 00:00:00
7239	62	2026-03-09 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-09 00:00:00
7240	107	2026-03-09 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-09 00:00:00
7241	108	2026-03-09 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-09 00:00:00
7242	6	2026-03-09 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-09 00:00:00
7243	109	2026-03-09 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-09 00:00:00
3266	110	2026-03-09 00:00:00	0	10	0km/55.6km	https://www.nordicfrance.fr/nordicfrance_station/bonnecombe/	2026-03-09 00:00:00
7245	14	2026-03-09 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-09 00:00:00
7246	111	2026-03-09 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-09 00:00:00
7247	21	2026-03-09 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-09 00:00:00
3492	112	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-09 00:00:00
7249	23	2026-03-09 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-09 00:00:00
3672	113	2026-03-09 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-09 00:00:00
3942	114	2026-03-09 00:00:00	0	15	0km/75km	https://www.nordicfrance.fr/nordicfrance_station/1560/	2026-03-09 00:00:00
7252	115	2026-03-09 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-09 00:00:00
4224	116	2026-03-09 00:00:00	0	17	0km/86.1km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-markstein-grand-ballon/	2026-03-09 00:00:00
7254	28	2026-03-09 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-09 00:00:00
7255	117	2026-03-09 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-09 00:00:00
4532	118	2026-03-09 00:00:00	0	5	0km/28km	https://www.nordicfrance.fr/nordicfrance_station/4971/	2026-03-09 00:00:00
4591	119	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-09 00:00:00
7258	33	2026-03-09 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-09 00:00:00
7259	120	2026-03-09 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-09 00:00:00
7260	121	2026-03-09 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-09 00:00:00
7261	36	2026-03-09 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-09 00:00:00
4890	122	2026-03-09 00:00:00	5	7	32km/54km	https://www.nordicfrance.fr/nordicfrance_station/gresse-en-vercors/	2026-03-09 00:00:00
7263	123	2026-03-09 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-09 00:00:00
7264	124	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-09 00:00:00
7265	125	2026-03-09 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-09 00:00:00
4971	126	2026-03-09 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-09 00:00:00
7267	127	2026-03-09 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-09 00:00:00
7268	128	2026-03-09 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-09 00:00:00
7269	43	2026-03-09 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-09 00:00:00
7270	129	2026-03-09 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-09 00:00:00
5382	130	2026-03-09 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-09 00:00:00
7272	131	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-09 00:00:00
7274	133	2026-03-09 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-09 00:00:00
7275	50	2026-03-09 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-09 00:00:00
7276	134	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-09 00:00:00
7277	135	2026-03-09 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-09 00:00:00
7278	137	2026-03-09 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-09 00:00:00
7279	138	2026-03-09 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-09 00:00:00
5765	139	2026-03-09 00:00:00	0	22	0km/14.97km	https://www.nordicfrance.fr/nordicfrance_station/mijanes-donezan/	2026-03-09 00:00:00
7281	140	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-09 00:00:00
6043	141	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/montoncel/	2026-03-09 00:00:00
7283	63	2026-03-09 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-09 00:00:00
6298	142	2026-03-09 00:00:00	0	6	0km/24.3km	https://www.nordicfrance.fr/nordicfrance_station/nasbinals-fer-a-cheval/	2026-03-09 00:00:00
6594	143	2026-03-09 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-09 00:00:00
7287	68	2026-03-09 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-09 00:00:00
7288	104	2026-03-09 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-09 00:00:00
7289	145	2026-03-09 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-09 00:00:00
7290	146	2026-03-09 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-09 00:00:00
7291	147	2026-03-09 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-09 00:00:00
7292	75	2026-03-09 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-09 00:00:00
7293	148	2026-03-09 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-09 00:00:00
7294	105	2026-03-09 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-09 00:00:00
7295	84	2026-03-09 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-09 00:00:00
6959	149	2026-03-09 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-09 00:00:00
7297	86	2026-03-09 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-09 00:00:00
7298	150	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-09 00:00:00
7299	106	2026-03-09 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-09 00:00:00
7300	151	2026-03-09 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-09 00:00:00
7062	152	2026-03-09 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-09 00:00:00
7302	1	2026-03-10 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-10 00:00:00
7303	2	2026-03-10 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-10 00:00:00
7304	3	2026-03-10 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-10 00:00:00
7305	4	2026-03-10 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-10 00:00:00
7306	5	2026-03-10 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-10 00:00:00
7307	7	2026-03-10 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-10 00:00:00
7308	8	2026-03-10 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-10 00:00:00
7309	9	2026-03-10 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-10 00:00:00
7310	10	2026-03-10 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-10 00:00:00
7311	11	2026-03-10 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-10 00:00:00
7312	12	2026-03-10 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-10 00:00:00
7313	13	2026-03-10 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-10 00:00:00
7314	15	2026-03-10 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-10 00:00:00
7315	16	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-10 00:00:00
7316	17	2026-03-10 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-10 00:00:00
7317	18	2026-03-10 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-10 00:00:00
7318	19	2026-03-10 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-10 00:00:00
7319	20	2026-03-10 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-10 00:00:00
7320	153	2026-03-10 00:00:00	8	25	64.7km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-10 00:00:00
7321	22	2026-03-10 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-10 00:00:00
7322	24	2026-03-10 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-10 00:00:00
7323	25	2026-03-10 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-10 00:00:00
7324	26	2026-03-10 00:00:00	3	14	4km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-10 00:00:00
7325	29	2026-03-10 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-10 00:00:00
7326	30	2026-03-10 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-10 00:00:00
7327	31	2026-03-10 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-10 00:00:00
7328	32	2026-03-10 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-10 00:00:00
7329	34	2026-03-10 00:00:00	14	20	90.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-10 00:00:00
7330	35	2026-03-10 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-10 00:00:00
7331	38	2026-03-10 00:00:00	19	42	56.8km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-10 00:00:00
7332	39	2026-03-10 00:00:00	35	74	209.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-10 00:00:00
7333	155	2026-03-10 00:00:00	26	35	168.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-10 00:00:00
7334	40	2026-03-10 00:00:00	12	19	32km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-10 00:00:00
7335	41	2026-03-10 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-10 00:00:00
7336	42	2026-03-10 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-10 00:00:00
7337	44	2026-03-10 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-10 00:00:00
7338	45	2026-03-10 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-10 00:00:00
7339	46	2026-03-10 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-10 00:00:00
7340	47	2026-03-10 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-10 00:00:00
7341	48	2026-03-10 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-10 00:00:00
7342	49	2026-03-10 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-10 00:00:00
7343	51	2026-03-10 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-10 00:00:00
7344	53	2026-03-10 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-10 00:00:00
7345	54	2026-03-10 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-10 00:00:00
7346	55	2026-03-10 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-10 00:00:00
7347	56	2026-03-10 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-10 00:00:00
7348	57	2026-03-10 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-10 00:00:00
7349	58	2026-03-10 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-10 00:00:00
7350	59	2026-03-10 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-10 00:00:00
7351	60	2026-03-10 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-10 00:00:00
7352	61	2026-03-10 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-10 00:00:00
7353	64	2026-03-10 00:00:00	20	21	80.6km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-10 00:00:00
7354	65	2026-03-10 00:00:00	21	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-10 00:00:00
7355	66	2026-03-10 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-10 00:00:00
7356	67	2026-03-10 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-10 00:00:00
7357	69	2026-03-10 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-10 00:00:00
7358	70	2026-03-10 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-10 00:00:00
7359	71	2026-03-10 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-10 00:00:00
7360	72	2026-03-10 00:00:00	30	30	99.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-10 00:00:00
7361	73	2026-03-10 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-10 00:00:00
7362	74	2026-03-10 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-10 00:00:00
7363	76	2026-03-10 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-10 00:00:00
7364	78	2026-03-10 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-10 00:00:00
7365	79	2026-03-10 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-10 00:00:00
7366	80	2026-03-10 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-10 00:00:00
7367	81	2026-03-10 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-10 00:00:00
7368	82	2026-03-10 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-10 00:00:00
7369	83	2026-03-10 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-10 00:00:00
7370	154	2026-03-10 00:00:00	14	24	89.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-10 00:00:00
7371	85	2026-03-10 00:00:00	29	62	145.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-10 00:00:00
7372	90	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-10 00:00:00
7373	91	2026-03-10 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-10 00:00:00
7374	92	2026-03-10 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-10 00:00:00
7375	94	2026-03-10 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-10 00:00:00
7376	95	2026-03-10 00:00:00	11	16	38km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-10 00:00:00
7377	96	2026-03-10 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-10 00:00:00
7378	97	2026-03-10 00:00:00	6	12	8.1km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-10 00:00:00
7379	98	2026-03-10 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-10 00:00:00
7380	99	2026-03-10 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-10 00:00:00
7381	100	2026-03-10 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-10 00:00:00
7382	101	2026-03-10 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-10 00:00:00
7383	102	2026-03-10 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-10 00:00:00
7384	62	2026-03-10 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-10 00:00:00
7385	107	2026-03-10 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-10 00:00:00
7386	108	2026-03-10 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-10 00:00:00
7387	6	2026-03-10 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-10 00:00:00
7388	109	2026-03-10 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-10 00:00:00
7390	14	2026-03-10 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-10 00:00:00
7391	111	2026-03-10 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-10 00:00:00
7392	21	2026-03-10 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-10 00:00:00
7394	23	2026-03-10 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-10 00:00:00
7397	115	2026-03-10 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-10 00:00:00
7399	27	2026-03-10 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-10 00:00:00
7400	28	2026-03-10 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-10 00:00:00
7401	117	2026-03-10 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-10 00:00:00
7404	33	2026-03-10 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-10 00:00:00
7405	120	2026-03-10 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-10 00:00:00
7406	121	2026-03-10 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-10 00:00:00
7407	36	2026-03-10 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-10 00:00:00
7409	123	2026-03-10 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-10 00:00:00
7410	37	2026-03-10 00:00:00	6	23	26.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-10 00:00:00
7411	124	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-10 00:00:00
7412	125	2026-03-10 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-10 00:00:00
7414	127	2026-03-10 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-10 00:00:00
7415	128	2026-03-10 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-10 00:00:00
7416	43	2026-03-10 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-10 00:00:00
7417	129	2026-03-10 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-10 00:00:00
7419	131	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-10 00:00:00
7421	133	2026-03-10 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-10 00:00:00
7422	50	2026-03-10 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-10 00:00:00
7423	134	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-10 00:00:00
7424	135	2026-03-10 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-10 00:00:00
7425	137	2026-03-10 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-10 00:00:00
7426	52	2026-03-10 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-10 00:00:00
7427	138	2026-03-10 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-10 00:00:00
7429	140	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-10 00:00:00
7431	63	2026-03-10 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-10 00:00:00
7435	68	2026-03-10 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-10 00:00:00
7436	104	2026-03-10 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-10 00:00:00
7437	145	2026-03-10 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-10 00:00:00
7438	146	2026-03-10 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-10 00:00:00
7439	147	2026-03-10 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-10 00:00:00
7440	75	2026-03-10 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-10 00:00:00
7441	77	2026-03-10 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-10 00:00:00
7442	148	2026-03-10 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-10 00:00:00
7443	105	2026-03-10 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-10 00:00:00
7444	84	2026-03-10 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-10 00:00:00
7446	86	2026-03-10 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-10 00:00:00
7447	150	2026-03-10 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-10 00:00:00
7448	88	2026-03-10 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-10 00:00:00
7449	106	2026-03-10 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-10 00:00:00
7450	151	2026-03-10 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-10 00:00:00
7452	1	2026-03-11 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-11 00:00:00
7453	2	2026-03-11 00:00:00	9	9	51km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-11 00:00:00
7454	3	2026-03-11 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-11 00:00:00
7455	4	2026-03-11 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-11 00:00:00
7456	5	2026-03-11 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-11 00:00:00
7457	7	2026-03-11 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-11 00:00:00
7458	8	2026-03-11 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-11 00:00:00
7459	9	2026-03-11 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-11 00:00:00
7460	10	2026-03-11 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-11 00:00:00
7461	11	2026-03-11 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-11 00:00:00
7462	12	2026-03-11 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-11 00:00:00
7463	13	2026-03-11 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-11 00:00:00
7464	15	2026-03-11 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-11 00:00:00
7465	16	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-11 00:00:00
7466	17	2026-03-11 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-11 00:00:00
7467	18	2026-03-11 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-11 00:00:00
7468	19	2026-03-11 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-11 00:00:00
7469	20	2026-03-11 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-11 00:00:00
7470	153	2026-03-11 00:00:00	8	25	64.7km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-11 00:00:00
7471	22	2026-03-11 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-11 00:00:00
7472	24	2026-03-11 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-11 00:00:00
7473	25	2026-03-11 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-11 00:00:00
7474	26	2026-03-11 00:00:00	3	14	4km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-11 00:00:00
7475	29	2026-03-11 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-11 00:00:00
7476	30	2026-03-11 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-11 00:00:00
7477	31	2026-03-11 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-11 00:00:00
7478	32	2026-03-11 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-11 00:00:00
7479	34	2026-03-11 00:00:00	14	20	90.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-11 00:00:00
7480	35	2026-03-11 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-11 00:00:00
7481	36	2026-03-11 00:00:00	9	19	74.2km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-11 00:00:00
7482	37	2026-03-11 00:00:00	13	23	52.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-11 00:00:00
7483	38	2026-03-11 00:00:00	14	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-11 00:00:00
7484	39	2026-03-11 00:00:00	34	74	209.5km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-11 00:00:00
7485	155	2026-03-11 00:00:00	26	35	168.9km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-11 00:00:00
7486	40	2026-03-11 00:00:00	10	19	26km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-11 00:00:00
7487	41	2026-03-11 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-11 00:00:00
7488	42	2026-03-11 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-11 00:00:00
7489	44	2026-03-11 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-11 00:00:00
7490	45	2026-03-11 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-11 00:00:00
7491	46	2026-03-11 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-11 00:00:00
7492	47	2026-03-11 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-11 00:00:00
7493	48	2026-03-11 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-11 00:00:00
7494	49	2026-03-11 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-11 00:00:00
7495	51	2026-03-11 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-11 00:00:00
7496	53	2026-03-11 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-11 00:00:00
7497	54	2026-03-11 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-11 00:00:00
7498	55	2026-03-11 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-11 00:00:00
7499	56	2026-03-11 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-11 00:00:00
7500	57	2026-03-11 00:00:00	16	27	56.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-11 00:00:00
7501	58	2026-03-11 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-11 00:00:00
7502	59	2026-03-11 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-11 00:00:00
7503	61	2026-03-11 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-11 00:00:00
7504	64	2026-03-11 00:00:00	20	21	80.6km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-11 00:00:00
7505	65	2026-03-11 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-11 00:00:00
7506	66	2026-03-11 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-11 00:00:00
7507	67	2026-03-11 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-11 00:00:00
7508	69	2026-03-11 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-11 00:00:00
7509	70	2026-03-11 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-11 00:00:00
7510	71	2026-03-11 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-11 00:00:00
7511	72	2026-03-11 00:00:00	30	30	99.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-11 00:00:00
7512	73	2026-03-11 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-11 00:00:00
7513	74	2026-03-11 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-11 00:00:00
7514	76	2026-03-11 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-11 00:00:00
7515	78	2026-03-11 00:00:00	22	28	116.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-11 00:00:00
7516	79	2026-03-11 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-11 00:00:00
7517	80	2026-03-11 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-11 00:00:00
7518	81	2026-03-11 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-11 00:00:00
7519	82	2026-03-11 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-11 00:00:00
7520	83	2026-03-11 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-11 00:00:00
7521	154	2026-03-11 00:00:00	14	24	89.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-11 00:00:00
7522	85	2026-03-11 00:00:00	30	62	145.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-11 00:00:00
7523	90	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-11 00:00:00
7524	91	2026-03-11 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-11 00:00:00
7525	92	2026-03-11 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-11 00:00:00
7526	94	2026-03-11 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-11 00:00:00
7527	95	2026-03-11 00:00:00	11	16	38km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-11 00:00:00
7528	96	2026-03-11 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-11 00:00:00
7529	98	2026-03-11 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-11 00:00:00
7530	99	2026-03-11 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-11 00:00:00
7531	100	2026-03-11 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-11 00:00:00
7532	101	2026-03-11 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-11 00:00:00
7533	102	2026-03-11 00:00:00	13	15	27.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-11 00:00:00
7534	62	2026-03-11 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-11 00:00:00
7535	107	2026-03-11 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-11 00:00:00
7536	108	2026-03-11 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-11 00:00:00
7537	6	2026-03-11 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-11 00:00:00
7538	109	2026-03-11 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-11 00:00:00
7540	14	2026-03-11 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-11 00:00:00
7541	111	2026-03-11 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-11 00:00:00
7542	21	2026-03-11 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-11 00:00:00
7544	23	2026-03-11 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-11 00:00:00
7547	115	2026-03-11 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-11 00:00:00
7549	27	2026-03-11 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-11 00:00:00
7550	28	2026-03-11 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-11 00:00:00
7551	117	2026-03-11 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-11 00:00:00
7554	33	2026-03-11 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-11 00:00:00
7555	120	2026-03-11 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-11 00:00:00
7556	121	2026-03-11 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-11 00:00:00
7558	123	2026-03-11 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-11 00:00:00
7559	124	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-11 00:00:00
7560	125	2026-03-11 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-11 00:00:00
4973	126	2026-03-11 00:00:00	0	7	0km/49.3km	https://www.nordicfrance.fr/nordicfrance_station/pailherols-carlades-les-flocons-verts/	2026-03-11 00:00:00
7562	127	2026-03-11 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-11 00:00:00
7563	128	2026-03-11 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-11 00:00:00
7564	43	2026-03-11 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-11 00:00:00
7565	129	2026-03-11 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-11 00:00:00
7567	131	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-11 00:00:00
7569	133	2026-03-11 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-11 00:00:00
7570	50	2026-03-11 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-11 00:00:00
7571	134	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-11 00:00:00
7572	135	2026-03-11 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-11 00:00:00
7573	137	2026-03-11 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-11 00:00:00
7574	52	2026-03-11 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-11 00:00:00
7575	138	2026-03-11 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-11 00:00:00
7577	140	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-11 00:00:00
7579	60	2026-03-11 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-11 00:00:00
7580	63	2026-03-11 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-11 00:00:00
6601	144	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/parrot-nature/	2026-03-11 00:00:00
7584	68	2026-03-11 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-11 00:00:00
7585	104	2026-03-11 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-11 00:00:00
7586	145	2026-03-11 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-11 00:00:00
7587	146	2026-03-11 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-11 00:00:00
7588	147	2026-03-11 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-11 00:00:00
7589	75	2026-03-11 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-11 00:00:00
7590	77	2026-03-11 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-11 00:00:00
7591	148	2026-03-11 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-11 00:00:00
7592	105	2026-03-11 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-11 00:00:00
7593	84	2026-03-11 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-11 00:00:00
7595	86	2026-03-11 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-11 00:00:00
7596	150	2026-03-11 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-11 00:00:00
7597	88	2026-03-11 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-11 00:00:00
7598	106	2026-03-11 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-11 00:00:00
7599	151	2026-03-11 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-11 00:00:00
7601	1	2026-03-12 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-12 00:00:00
7602	2	2026-03-12 00:00:00	6	9	39km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-12 00:00:00
7603	3	2026-03-12 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-12 00:00:00
7604	4	2026-03-12 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-12 00:00:00
7605	5	2026-03-12 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-12 00:00:00
7606	7	2026-03-12 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-12 00:00:00
7607	8	2026-03-12 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-12 00:00:00
7608	9	2026-03-12 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-12 00:00:00
7609	10	2026-03-12 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-12 00:00:00
7610	11	2026-03-12 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-12 00:00:00
7611	12	2026-03-12 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-12 00:00:00
7612	13	2026-03-12 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-12 00:00:00
7613	16	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-12 00:00:00
7614	17	2026-03-12 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-12 00:00:00
7615	18	2026-03-12 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-12 00:00:00
7616	19	2026-03-12 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-12 00:00:00
7617	20	2026-03-12 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-12 00:00:00
7618	153	2026-03-12 00:00:00	8	25	64.7km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-12 00:00:00
7619	22	2026-03-12 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-12 00:00:00
7620	24	2026-03-12 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-12 00:00:00
7621	25	2026-03-12 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-12 00:00:00
7622	26	2026-03-12 00:00:00	3	14	4km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-12 00:00:00
7623	29	2026-03-12 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-12 00:00:00
7624	30	2026-03-12 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-12 00:00:00
7625	31	2026-03-12 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-12 00:00:00
7626	32	2026-03-12 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-12 00:00:00
7627	34	2026-03-12 00:00:00	14	20	90.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-12 00:00:00
7628	35	2026-03-12 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-12 00:00:00
7629	37	2026-03-12 00:00:00	13	23	52.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-12 00:00:00
7630	38	2026-03-12 00:00:00	14	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-12 00:00:00
7631	155	2026-03-12 00:00:00	24	35	167.7km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-12 00:00:00
7632	40	2026-03-12 00:00:00	10	19	26km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-12 00:00:00
7633	41	2026-03-12 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-12 00:00:00
7634	42	2026-03-12 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-12 00:00:00
7635	44	2026-03-12 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-12 00:00:00
7636	45	2026-03-12 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-12 00:00:00
7637	46	2026-03-12 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-12 00:00:00
7638	47	2026-03-12 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-12 00:00:00
7639	48	2026-03-12 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-12 00:00:00
7640	49	2026-03-12 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-12 00:00:00
7641	51	2026-03-12 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-12 00:00:00
7642	53	2026-03-12 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-12 00:00:00
7643	54	2026-03-12 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-12 00:00:00
7644	55	2026-03-12 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-12 00:00:00
7645	56	2026-03-12 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-12 00:00:00
7646	57	2026-03-12 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-12 00:00:00
7647	58	2026-03-12 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-12 00:00:00
7648	59	2026-03-12 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-12 00:00:00
7649	61	2026-03-12 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-12 00:00:00
7650	64	2026-03-12 00:00:00	18	21	71.1km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-12 00:00:00
7651	65	2026-03-12 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-12 00:00:00
7652	66	2026-03-12 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-12 00:00:00
7653	67	2026-03-12 00:00:00	6	12	20.9km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-12 00:00:00
7654	69	2026-03-12 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-12 00:00:00
7655	70	2026-03-12 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-12 00:00:00
7656	71	2026-03-12 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-12 00:00:00
7657	72	2026-03-12 00:00:00	30	30	99.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-12 00:00:00
7658	73	2026-03-12 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-12 00:00:00
7659	74	2026-03-12 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-12 00:00:00
7660	76	2026-03-12 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-12 00:00:00
7661	78	2026-03-12 00:00:00	19	28	104.8km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-12 00:00:00
7662	79	2026-03-12 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-12 00:00:00
7663	80	2026-03-12 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-12 00:00:00
7664	81	2026-03-12 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-12 00:00:00
7665	82	2026-03-12 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-12 00:00:00
7666	83	2026-03-12 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-12 00:00:00
7667	154	2026-03-12 00:00:00	12	24	78.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-12 00:00:00
7668	85	2026-03-12 00:00:00	29	62	145.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-12 00:00:00
7669	90	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-12 00:00:00
7670	91	2026-03-12 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-12 00:00:00
7671	92	2026-03-12 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-12 00:00:00
7672	94	2026-03-12 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-12 00:00:00
7673	95	2026-03-12 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-12 00:00:00
7674	96	2026-03-12 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-12 00:00:00
7675	98	2026-03-12 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-12 00:00:00
7676	99	2026-03-12 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-12 00:00:00
7677	100	2026-03-12 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-12 00:00:00
7678	101	2026-03-12 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-12 00:00:00
7679	102	2026-03-12 00:00:00	11	15	21.1km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-12 00:00:00
7680	62	2026-03-12 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-12 00:00:00
7681	107	2026-03-12 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-12 00:00:00
7682	108	2026-03-12 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-12 00:00:00
7683	6	2026-03-12 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-12 00:00:00
7684	109	2026-03-12 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-12 00:00:00
7686	14	2026-03-12 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-12 00:00:00
7687	15	2026-03-12 00:00:00	0	9	0km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-12 00:00:00
7688	111	2026-03-12 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-12 00:00:00
7689	21	2026-03-12 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-12 00:00:00
7691	23	2026-03-12 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-12 00:00:00
7694	115	2026-03-12 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-12 00:00:00
7696	27	2026-03-12 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-12 00:00:00
7697	28	2026-03-12 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-12 00:00:00
7698	117	2026-03-12 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-12 00:00:00
7701	33	2026-03-12 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-12 00:00:00
7702	120	2026-03-12 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-12 00:00:00
7703	121	2026-03-12 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-12 00:00:00
7704	36	2026-03-12 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-12 00:00:00
7706	123	2026-03-12 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-12 00:00:00
7707	124	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-12 00:00:00
7708	125	2026-03-12 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-12 00:00:00
7710	127	2026-03-12 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-12 00:00:00
7711	128	2026-03-12 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-12 00:00:00
7712	43	2026-03-12 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-12 00:00:00
7713	129	2026-03-12 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-12 00:00:00
7715	131	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-12 00:00:00
7717	133	2026-03-12 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-12 00:00:00
7718	50	2026-03-12 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-12 00:00:00
7719	134	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-12 00:00:00
7720	135	2026-03-12 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-12 00:00:00
7721	137	2026-03-12 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-12 00:00:00
7722	52	2026-03-12 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-12 00:00:00
7723	138	2026-03-12 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-12 00:00:00
7725	140	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-12 00:00:00
7727	60	2026-03-12 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-12 00:00:00
7728	63	2026-03-12 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-12 00:00:00
7732	68	2026-03-12 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-12 00:00:00
7733	104	2026-03-12 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-12 00:00:00
7734	145	2026-03-12 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-12 00:00:00
7735	146	2026-03-12 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-12 00:00:00
7736	147	2026-03-12 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-12 00:00:00
7737	75	2026-03-12 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-12 00:00:00
7738	77	2026-03-12 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-12 00:00:00
7739	148	2026-03-12 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-12 00:00:00
7740	105	2026-03-12 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-12 00:00:00
7741	84	2026-03-12 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-12 00:00:00
7743	86	2026-03-12 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-12 00:00:00
7744	150	2026-03-12 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-12 00:00:00
7745	88	2026-03-12 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-12 00:00:00
7746	106	2026-03-12 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-12 00:00:00
7747	151	2026-03-12 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-12 00:00:00
7748	93	2026-03-12 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-12 00:00:00
7750	1	2026-03-13 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-13 00:00:00
7751	2	2026-03-13 00:00:00	6	9	39km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-13 00:00:00
7752	3	2026-03-13 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-13 00:00:00
7753	4	2026-03-13 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-13 00:00:00
7754	5	2026-03-13 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-13 00:00:00
7755	7	2026-03-13 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-13 00:00:00
7756	8	2026-03-13 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-13 00:00:00
7757	9	2026-03-13 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-13 00:00:00
7758	10	2026-03-13 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-13 00:00:00
7759	11	2026-03-13 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-13 00:00:00
7760	12	2026-03-13 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-13 00:00:00
7761	13	2026-03-13 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-13 00:00:00
7762	15	2026-03-13 00:00:00	7	9	20.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-13 00:00:00
7763	16	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-13 00:00:00
7764	17	2026-03-13 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-13 00:00:00
7765	18	2026-03-13 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-13 00:00:00
7766	19	2026-03-13 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-13 00:00:00
7767	20	2026-03-13 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-13 00:00:00
7768	22	2026-03-13 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-13 00:00:00
7769	24	2026-03-13 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-13 00:00:00
7770	25	2026-03-13 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-13 00:00:00
7771	26	2026-03-13 00:00:00	3	14	4km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-13 00:00:00
7772	29	2026-03-13 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-13 00:00:00
7773	30	2026-03-13 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-13 00:00:00
7774	31	2026-03-13 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-13 00:00:00
7775	32	2026-03-13 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-13 00:00:00
7776	34	2026-03-13 00:00:00	14	20	90.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-13 00:00:00
7777	39	2026-03-13 00:00:00	28	74	181km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-13 00:00:00
7778	155	2026-03-13 00:00:00	24	35	167.7km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-13 00:00:00
7779	40	2026-03-13 00:00:00	10	19	26km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-13 00:00:00
7780	41	2026-03-13 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-13 00:00:00
7781	42	2026-03-13 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-13 00:00:00
7782	44	2026-03-13 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-13 00:00:00
7783	45	2026-03-13 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-13 00:00:00
7784	46	2026-03-13 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-13 00:00:00
7785	47	2026-03-13 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-13 00:00:00
7786	48	2026-03-13 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-13 00:00:00
7787	49	2026-03-13 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-13 00:00:00
7788	51	2026-03-13 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-13 00:00:00
7789	53	2026-03-13 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-13 00:00:00
7790	54	2026-03-13 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-13 00:00:00
7791	55	2026-03-13 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-13 00:00:00
7792	56	2026-03-13 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-13 00:00:00
7793	57	2026-03-13 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-13 00:00:00
7794	58	2026-03-13 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-13 00:00:00
7795	59	2026-03-13 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-13 00:00:00
7796	61	2026-03-13 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-13 00:00:00
7797	64	2026-03-13 00:00:00	20	21	80.6km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-13 00:00:00
7798	65	2026-03-13 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-13 00:00:00
7799	66	2026-03-13 00:00:00	16	22	47.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-13 00:00:00
7800	67	2026-03-13 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-13 00:00:00
7801	69	2026-03-13 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-13 00:00:00
7802	70	2026-03-13 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-13 00:00:00
7803	71	2026-03-13 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-13 00:00:00
7804	72	2026-03-13 00:00:00	28	30	93.7km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-13 00:00:00
7805	73	2026-03-13 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-13 00:00:00
7806	74	2026-03-13 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-13 00:00:00
7807	76	2026-03-13 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-13 00:00:00
7808	78	2026-03-13 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-13 00:00:00
7809	79	2026-03-13 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-13 00:00:00
7810	80	2026-03-13 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-13 00:00:00
7811	81	2026-03-13 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-13 00:00:00
7812	82	2026-03-13 00:00:00	13	16	47.85km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-13 00:00:00
7813	83	2026-03-13 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-13 00:00:00
7814	154	2026-03-13 00:00:00	11	24	72.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-13 00:00:00
7815	85	2026-03-13 00:00:00	28	62	141.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-13 00:00:00
7816	90	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-13 00:00:00
7817	91	2026-03-13 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-13 00:00:00
7818	92	2026-03-13 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-13 00:00:00
7819	94	2026-03-13 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-13 00:00:00
7820	95	2026-03-13 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-13 00:00:00
7821	96	2026-03-13 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-13 00:00:00
7822	97	2026-03-13 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-13 00:00:00
7823	98	2026-03-13 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-13 00:00:00
7824	99	2026-03-13 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-13 00:00:00
7825	100	2026-03-13 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-13 00:00:00
7826	101	2026-03-13 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-13 00:00:00
7827	102	2026-03-13 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-13 00:00:00
7828	62	2026-03-13 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-13 00:00:00
7829	107	2026-03-13 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-13 00:00:00
7830	108	2026-03-13 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-13 00:00:00
7831	6	2026-03-13 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-13 00:00:00
7832	109	2026-03-13 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-13 00:00:00
7834	14	2026-03-13 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-13 00:00:00
7835	111	2026-03-13 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-13 00:00:00
7836	21	2026-03-13 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-13 00:00:00
7837	153	2026-03-13 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-13 00:00:00
7839	23	2026-03-13 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-13 00:00:00
7842	115	2026-03-13 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-13 00:00:00
7844	27	2026-03-13 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-13 00:00:00
7845	28	2026-03-13 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-13 00:00:00
7846	117	2026-03-13 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-13 00:00:00
7849	33	2026-03-13 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-13 00:00:00
7850	120	2026-03-13 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-13 00:00:00
7851	35	2026-03-13 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-13 00:00:00
7852	121	2026-03-13 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-13 00:00:00
7853	36	2026-03-13 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-13 00:00:00
7855	123	2026-03-13 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-13 00:00:00
7856	124	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-13 00:00:00
7857	125	2026-03-13 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-13 00:00:00
7859	127	2026-03-13 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-13 00:00:00
7860	128	2026-03-13 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-13 00:00:00
7861	43	2026-03-13 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-13 00:00:00
7862	129	2026-03-13 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-13 00:00:00
291	130	2026-03-13 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-02-25 14:58:55.918
7864	131	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-13 00:00:00
7866	133	2026-03-13 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-13 00:00:00
7867	50	2026-03-13 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-13 00:00:00
7868	134	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-13 00:00:00
7869	135	2026-03-13 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-13 00:00:00
7870	137	2026-03-13 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-13 00:00:00
7871	52	2026-03-13 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-13 00:00:00
7872	138	2026-03-13 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-13 00:00:00
7874	140	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-13 00:00:00
7876	60	2026-03-13 00:00:00	0	17	0km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-13 00:00:00
7877	63	2026-03-13 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-13 00:00:00
7881	68	2026-03-13 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-13 00:00:00
7882	104	2026-03-13 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-13 00:00:00
7883	145	2026-03-13 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-13 00:00:00
7884	146	2026-03-13 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-13 00:00:00
7885	147	2026-03-13 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-13 00:00:00
7886	75	2026-03-13 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-13 00:00:00
7887	77	2026-03-13 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-13 00:00:00
7888	148	2026-03-13 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-13 00:00:00
7889	105	2026-03-13 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-13 00:00:00
7890	84	2026-03-13 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-13 00:00:00
7892	86	2026-03-13 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-13 00:00:00
7893	150	2026-03-13 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-13 00:00:00
7894	88	2026-03-13 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-13 00:00:00
7895	106	2026-03-13 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-13 00:00:00
7896	151	2026-03-13 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-13 00:00:00
7897	93	2026-03-13 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-13 00:00:00
7899	1	2026-03-14 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-14 00:00:00
7900	2	2026-03-14 00:00:00	6	9	39km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-14 00:00:00
7901	3	2026-03-14 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-14 00:00:00
7902	4	2026-03-14 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-14 00:00:00
7903	5	2026-03-14 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-14 00:00:00
7904	7	2026-03-14 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-14 00:00:00
7905	8	2026-03-14 00:00:00	28	31	55.2km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-14 00:00:00
7906	9	2026-03-14 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-14 00:00:00
7907	10	2026-03-14 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-14 00:00:00
7908	11	2026-03-14 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-14 00:00:00
7909	12	2026-03-14 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-14 00:00:00
7910	13	2026-03-14 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-14 00:00:00
7911	16	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-14 00:00:00
7912	17	2026-03-14 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-14 00:00:00
7913	18	2026-03-14 00:00:00	0	12	0km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-14 00:00:00
7914	19	2026-03-14 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-14 00:00:00
7915	20	2026-03-14 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-14 00:00:00
7916	22	2026-03-14 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-14 00:00:00
7917	24	2026-03-14 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-14 00:00:00
7918	25	2026-03-14 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-14 00:00:00
7919	26	2026-03-14 00:00:00	4	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-14 00:00:00
7920	29	2026-03-14 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-14 00:00:00
7921	30	2026-03-14 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-14 00:00:00
7922	31	2026-03-14 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-14 00:00:00
7923	32	2026-03-14 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-14 00:00:00
7924	34	2026-03-14 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-14 00:00:00
7925	36	2026-03-14 00:00:00	9	19	74.2km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-14 00:00:00
7926	39	2026-03-14 00:00:00	27	74	177.2km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-14 00:00:00
7927	155	2026-03-14 00:00:00	24	35	167.7km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-14 00:00:00
7928	40	2026-03-14 00:00:00	10	19	26km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-14 00:00:00
7929	41	2026-03-14 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-14 00:00:00
7930	42	2026-03-14 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-14 00:00:00
7931	44	2026-03-14 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-14 00:00:00
7932	45	2026-03-14 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-14 00:00:00
7933	46	2026-03-14 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-14 00:00:00
7934	47	2026-03-14 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-14 00:00:00
7935	156	2026-03-14 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-14 00:00:00
7936	48	2026-03-14 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-14 00:00:00
7937	49	2026-03-14 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-14 00:00:00
7938	51	2026-03-14 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-14 00:00:00
7939	53	2026-03-14 00:00:00	13	13	50.4km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-14 00:00:00
7940	54	2026-03-14 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-14 00:00:00
7941	55	2026-03-14 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-14 00:00:00
7942	56	2026-03-14 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-14 00:00:00
7943	57	2026-03-14 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-14 00:00:00
7944	58	2026-03-14 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-14 00:00:00
7945	59	2026-03-14 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-14 00:00:00
7946	61	2026-03-14 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-14 00:00:00
7947	64	2026-03-14 00:00:00	18	21	71.1km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-14 00:00:00
7948	65	2026-03-14 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-14 00:00:00
7949	66	2026-03-14 00:00:00	16	22	47.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-14 00:00:00
7950	67	2026-03-14 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-14 00:00:00
7951	69	2026-03-14 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-14 00:00:00
7952	70	2026-03-14 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-14 00:00:00
7953	71	2026-03-14 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-14 00:00:00
7954	72	2026-03-14 00:00:00	28	30	93.7km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-14 00:00:00
7955	73	2026-03-14 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-14 00:00:00
7956	74	2026-03-14 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-14 00:00:00
7957	76	2026-03-14 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-14 00:00:00
7958	78	2026-03-14 00:00:00	18	28	100.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-14 00:00:00
7959	79	2026-03-14 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-14 00:00:00
7960	80	2026-03-14 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-14 00:00:00
7961	81	2026-03-14 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-14 00:00:00
7962	82	2026-03-14 00:00:00	11	16	30.75km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-14 00:00:00
7963	83	2026-03-14 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-14 00:00:00
7964	154	2026-03-14 00:00:00	11	24	72.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-14 00:00:00
7965	85	2026-03-14 00:00:00	28	62	141.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-14 00:00:00
7966	90	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-14 00:00:00
7967	91	2026-03-14 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-14 00:00:00
7968	92	2026-03-14 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-14 00:00:00
7969	93	2026-03-14 00:00:00	3	4	25km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-14 00:00:00
7970	94	2026-03-14 00:00:00	3	5	12.12km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-14 00:00:00
7971	95	2026-03-14 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-14 00:00:00
7972	96	2026-03-14 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-14 00:00:00
7973	97	2026-03-14 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-14 00:00:00
7974	98	2026-03-14 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-14 00:00:00
7975	99	2026-03-14 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-14 00:00:00
7976	100	2026-03-14 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-14 00:00:00
7977	101	2026-03-14 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-14 00:00:00
7978	102	2026-03-14 00:00:00	11	15	20.7km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-14 00:00:00
7979	103	2026-03-14 00:00:00	11	64	17.47km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-14 00:00:00
7980	62	2026-03-14 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-14 00:00:00
7981	107	2026-03-14 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-14 00:00:00
7982	108	2026-03-14 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-14 00:00:00
7983	6	2026-03-14 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-14 00:00:00
7984	109	2026-03-14 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-14 00:00:00
7986	14	2026-03-14 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-14 00:00:00
7987	15	2026-03-14 00:00:00	0	9	0km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-14 00:00:00
7988	111	2026-03-14 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-14 00:00:00
7989	21	2026-03-14 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-14 00:00:00
7990	153	2026-03-14 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-14 00:00:00
7992	23	2026-03-14 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-14 00:00:00
7995	115	2026-03-14 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-14 00:00:00
7996	27	2026-03-14 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-14 00:00:00
7997	28	2026-03-14 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-14 00:00:00
7998	117	2026-03-14 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-14 00:00:00
8002	33	2026-03-14 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-14 00:00:00
8003	120	2026-03-14 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-14 00:00:00
8004	35	2026-03-14 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-14 00:00:00
8005	121	2026-03-14 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-14 00:00:00
8007	123	2026-03-14 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-14 00:00:00
8008	124	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-14 00:00:00
8009	125	2026-03-14 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-14 00:00:00
8011	127	2026-03-14 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-14 00:00:00
8012	128	2026-03-14 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-14 00:00:00
8013	43	2026-03-14 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-14 00:00:00
8014	129	2026-03-14 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-14 00:00:00
8015	130	2026-03-14 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-14 00:00:00
8016	131	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-14 00:00:00
8018	133	2026-03-14 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-14 00:00:00
8019	50	2026-03-14 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-14 00:00:00
8020	134	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-14 00:00:00
8021	135	2026-03-14 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-14 00:00:00
8022	137	2026-03-14 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-14 00:00:00
8023	52	2026-03-14 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-14 00:00:00
8024	138	2026-03-14 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-14 00:00:00
8026	140	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-14 00:00:00
8028	60	2026-03-14 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-14 00:00:00
8029	63	2026-03-14 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-14 00:00:00
8033	68	2026-03-14 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-14 00:00:00
8034	104	2026-03-14 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-14 00:00:00
8035	145	2026-03-14 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-14 00:00:00
8036	146	2026-03-14 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-14 00:00:00
8037	147	2026-03-14 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-14 00:00:00
8038	75	2026-03-14 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-14 00:00:00
8039	77	2026-03-14 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-14 00:00:00
8040	148	2026-03-14 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-14 00:00:00
8041	105	2026-03-14 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-14 00:00:00
8042	84	2026-03-14 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-14 00:00:00
8044	86	2026-03-14 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-14 00:00:00
8045	150	2026-03-14 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-14 00:00:00
8046	88	2026-03-14 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-14 00:00:00
8047	106	2026-03-14 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-14 00:00:00
8048	151	2026-03-14 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-14 00:00:00
8050	1	2026-03-15 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-15 00:00:00
8051	2	2026-03-15 00:00:00	6	9	39km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-15 00:00:00
8052	3	2026-03-15 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-15 00:00:00
8053	4	2026-03-15 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-15 00:00:00
8054	5	2026-03-15 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-15 00:00:00
8055	7	2026-03-15 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-15 00:00:00
8056	8	2026-03-15 00:00:00	30	31	68.6km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-15 00:00:00
8057	9	2026-03-15 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-15 00:00:00
8058	10	2026-03-15 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-15 00:00:00
8059	11	2026-03-15 00:00:00	27	27	169km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-15 00:00:00
8060	12	2026-03-15 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-15 00:00:00
8061	13	2026-03-15 00:00:00	8	15	34.6km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-15 00:00:00
8062	15	2026-03-15 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-15 00:00:00
8063	16	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-15 00:00:00
8064	17	2026-03-15 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-15 00:00:00
8065	18	2026-03-15 00:00:00	0	12	0km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-15 00:00:00
8066	19	2026-03-15 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-15 00:00:00
8067	20	2026-03-15 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-15 00:00:00
8068	153	2026-03-15 00:00:00	5	25	33.5km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-15 00:00:00
8069	22	2026-03-15 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-15 00:00:00
8070	24	2026-03-15 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-15 00:00:00
8071	25	2026-03-15 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-15 00:00:00
8072	26	2026-03-15 00:00:00	4	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-15 00:00:00
8073	29	2026-03-15 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-15 00:00:00
8074	30	2026-03-15 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-15 00:00:00
8075	31	2026-03-15 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-15 00:00:00
8076	32	2026-03-15 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-15 00:00:00
8077	34	2026-03-15 00:00:00	15	20	100.5km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-15 00:00:00
8078	36	2026-03-15 00:00:00	9	19	74.2km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-15 00:00:00
8079	37	2026-03-15 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-15 00:00:00
8080	39	2026-03-15 00:00:00	31	74	190km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-15 00:00:00
8081	155	2026-03-15 00:00:00	24	35	167.7km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-15 00:00:00
8082	40	2026-03-15 00:00:00	10	19	26km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-15 00:00:00
8083	41	2026-03-15 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-15 00:00:00
8084	42	2026-03-15 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-15 00:00:00
8085	44	2026-03-15 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-15 00:00:00
8086	45	2026-03-15 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-15 00:00:00
8087	46	2026-03-15 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-15 00:00:00
8088	47	2026-03-15 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-15 00:00:00
8089	156	2026-03-15 00:00:00	16	18	31.15km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-15 00:00:00
8090	48	2026-03-15 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-15 00:00:00
8091	49	2026-03-15 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-15 00:00:00
8092	51	2026-03-15 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-15 00:00:00
8093	53	2026-03-15 00:00:00	1	13	0km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-15 00:00:00
8094	103	2026-03-15 00:00:00	31	64	68.97km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-15 00:00:00
8095	54	2026-03-15 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-15 00:00:00
8096	55	2026-03-15 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-15 00:00:00
8097	56	2026-03-15 00:00:00	6	7	34.9km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-15 00:00:00
8098	57	2026-03-15 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-15 00:00:00
8099	58	2026-03-15 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-15 00:00:00
8100	59	2026-03-15 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-15 00:00:00
8101	61	2026-03-15 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-15 00:00:00
8102	64	2026-03-15 00:00:00	21	21	80.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-15 00:00:00
8103	65	2026-03-15 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-15 00:00:00
8104	66	2026-03-15 00:00:00	16	22	47.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-15 00:00:00
8105	67	2026-03-15 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-15 00:00:00
8106	69	2026-03-15 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-15 00:00:00
8107	70	2026-03-15 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-15 00:00:00
8108	71	2026-03-15 00:00:00	4	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-15 00:00:00
8109	72	2026-03-15 00:00:00	28	30	93.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-15 00:00:00
8110	73	2026-03-15 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-15 00:00:00
8111	74	2026-03-15 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-15 00:00:00
8112	76	2026-03-15 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-15 00:00:00
8113	78	2026-03-15 00:00:00	21	28	111.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-15 00:00:00
8114	79	2026-03-15 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-15 00:00:00
8115	80	2026-03-15 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-15 00:00:00
8116	81	2026-03-15 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-15 00:00:00
8117	82	2026-03-15 00:00:00	12	16	44.55km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-15 00:00:00
8118	83	2026-03-15 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-15 00:00:00
8119	154	2026-03-15 00:00:00	11	24	72.2km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-15 00:00:00
8120	85	2026-03-15 00:00:00	28	62	141.2km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-15 00:00:00
8121	90	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-15 00:00:00
8122	91	2026-03-15 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-15 00:00:00
8123	92	2026-03-15 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-15 00:00:00
8124	93	2026-03-15 00:00:00	1	4	18km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-15 00:00:00
8125	94	2026-03-15 00:00:00	4	5	9.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-15 00:00:00
8126	95	2026-03-15 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-15 00:00:00
8127	96	2026-03-15 00:00:00	4	6	20.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-15 00:00:00
8128	97	2026-03-15 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-15 00:00:00
8129	98	2026-03-15 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-15 00:00:00
8130	99	2026-03-15 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-15 00:00:00
8131	100	2026-03-15 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-15 00:00:00
8132	101	2026-03-15 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-15 00:00:00
8133	102	2026-03-15 00:00:00	12	15	22.7km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-15 00:00:00
8134	62	2026-03-15 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-15 00:00:00
8135	107	2026-03-15 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-15 00:00:00
8136	108	2026-03-15 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-15 00:00:00
8137	6	2026-03-15 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-15 00:00:00
8138	109	2026-03-15 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-15 00:00:00
8140	14	2026-03-15 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-15 00:00:00
8141	111	2026-03-15 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-15 00:00:00
8142	21	2026-03-15 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-15 00:00:00
8144	23	2026-03-15 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-15 00:00:00
8147	27	2026-03-15 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-15 00:00:00
8148	28	2026-03-15 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-15 00:00:00
8149	117	2026-03-15 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-15 00:00:00
8150	115	2026-03-15 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-15 00:00:00
4597	119	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-15 00:00:00
8154	33	2026-03-15 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-15 00:00:00
8155	120	2026-03-15 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-15 00:00:00
8156	35	2026-03-15 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-15 00:00:00
8157	121	2026-03-15 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-15 00:00:00
8159	123	2026-03-15 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-15 00:00:00
8160	124	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-15 00:00:00
8161	125	2026-03-15 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-15 00:00:00
8163	127	2026-03-15 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-15 00:00:00
8164	128	2026-03-15 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-15 00:00:00
8165	43	2026-03-15 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-15 00:00:00
8166	129	2026-03-15 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-15 00:00:00
8167	130	2026-03-15 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-15 00:00:00
8168	131	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-15 00:00:00
8170	133	2026-03-15 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-15 00:00:00
8171	50	2026-03-15 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-15 00:00:00
8172	134	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-15 00:00:00
8173	135	2026-03-15 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-15 00:00:00
8174	137	2026-03-15 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-15 00:00:00
8175	52	2026-03-15 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-15 00:00:00
8176	138	2026-03-15 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-15 00:00:00
8178	140	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-15 00:00:00
8180	60	2026-03-15 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-15 00:00:00
8181	63	2026-03-15 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-15 00:00:00
8183	143	2026-03-15 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-15 00:00:00
8185	68	2026-03-15 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-15 00:00:00
8186	104	2026-03-15 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-15 00:00:00
8187	145	2026-03-15 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-15 00:00:00
8188	146	2026-03-15 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-15 00:00:00
8189	147	2026-03-15 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-15 00:00:00
8190	75	2026-03-15 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-15 00:00:00
8191	77	2026-03-15 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-15 00:00:00
8192	148	2026-03-15 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-15 00:00:00
8193	105	2026-03-15 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-15 00:00:00
8194	84	2026-03-15 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-15 00:00:00
8196	86	2026-03-15 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-15 00:00:00
8197	150	2026-03-15 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-15 00:00:00
8198	88	2026-03-15 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-15 00:00:00
8199	106	2026-03-15 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-15 00:00:00
8200	151	2026-03-15 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-15 00:00:00
8202	1	2026-03-16 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-16 00:00:00
8203	2	2026-03-16 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-16 00:00:00
8204	3	2026-03-16 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-16 00:00:00
8205	4	2026-03-16 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-16 00:00:00
8206	5	2026-03-16 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-16 00:00:00
8207	7	2026-03-16 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-16 00:00:00
8208	8	2026-03-16 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-16 00:00:00
8209	9	2026-03-16 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-16 00:00:00
8210	10	2026-03-16 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-16 00:00:00
8211	11	2026-03-16 00:00:00	24	27	137.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-16 00:00:00
8212	12	2026-03-16 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-16 00:00:00
8213	15	2026-03-16 00:00:00	9	9	38.3km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-16 00:00:00
8214	16	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-16 00:00:00
8215	17	2026-03-16 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-16 00:00:00
8216	18	2026-03-16 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-16 00:00:00
8217	19	2026-03-16 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-16 00:00:00
8218	20	2026-03-16 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-16 00:00:00
8219	153	2026-03-16 00:00:00	5	25	33.5km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-16 00:00:00
8220	22	2026-03-16 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-16 00:00:00
8221	24	2026-03-16 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-16 00:00:00
8222	25	2026-03-16 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-16 00:00:00
8223	26	2026-03-16 00:00:00	4	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-16 00:00:00
8224	29	2026-03-16 00:00:00	8	13	38.5km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-16 00:00:00
8225	30	2026-03-16 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-16 00:00:00
8226	31	2026-03-16 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-16 00:00:00
8227	32	2026-03-16 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-16 00:00:00
8228	34	2026-03-16 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-16 00:00:00
8229	37	2026-03-16 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-16 00:00:00
8230	39	2026-03-16 00:00:00	30	74	188.8km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-16 00:00:00
8231	155	2026-03-16 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-16 00:00:00
8232	41	2026-03-16 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-16 00:00:00
8233	42	2026-03-16 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-16 00:00:00
8234	44	2026-03-16 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-16 00:00:00
8235	45	2026-03-16 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-16 00:00:00
8236	46	2026-03-16 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-16 00:00:00
8237	47	2026-03-16 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-16 00:00:00
8238	156	2026-03-16 00:00:00	16	18	31.15km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-16 00:00:00
8239	48	2026-03-16 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-16 00:00:00
8240	49	2026-03-16 00:00:00	12	14	45.6km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-16 00:00:00
8241	51	2026-03-16 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-16 00:00:00
8242	53	2026-03-16 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-16 00:00:00
8243	54	2026-03-16 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-16 00:00:00
8244	55	2026-03-16 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-16 00:00:00
8245	56	2026-03-16 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-16 00:00:00
8246	57	2026-03-16 00:00:00	21	27	68.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-16 00:00:00
8247	58	2026-03-16 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-16 00:00:00
8248	59	2026-03-16 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-16 00:00:00
8249	61	2026-03-16 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-16 00:00:00
8250	64	2026-03-16 00:00:00	20	21	79.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-16 00:00:00
8251	65	2026-03-16 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-16 00:00:00
8252	66	2026-03-16 00:00:00	22	22	56.3km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-16 00:00:00
8253	67	2026-03-16 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-16 00:00:00
8254	69	2026-03-16 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-16 00:00:00
8255	70	2026-03-16 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-16 00:00:00
8256	71	2026-03-16 00:00:00	3	28	7.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-16 00:00:00
8257	72	2026-03-16 00:00:00	29	30	96.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-16 00:00:00
8258	73	2026-03-16 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-16 00:00:00
8259	74	2026-03-16 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-16 00:00:00
8260	76	2026-03-16 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-16 00:00:00
8261	78	2026-03-16 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-16 00:00:00
8262	79	2026-03-16 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-16 00:00:00
8263	80	2026-03-16 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-16 00:00:00
8264	81	2026-03-16 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-16 00:00:00
8265	82	2026-03-16 00:00:00	12	16	44.55km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-16 00:00:00
8266	83	2026-03-16 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-16 00:00:00
8267	154	2026-03-16 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-16 00:00:00
8268	85	2026-03-16 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-16 00:00:00
8269	90	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-16 00:00:00
8270	91	2026-03-16 00:00:00	15	15	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-16 00:00:00
8271	92	2026-03-16 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-16 00:00:00
8272	93	2026-03-16 00:00:00	1	4	18km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-16 00:00:00
8273	94	2026-03-16 00:00:00	4	5	9.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-16 00:00:00
8274	95	2026-03-16 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-16 00:00:00
8275	96	2026-03-16 00:00:00	0	6	0km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-16 00:00:00
8276	97	2026-03-16 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-16 00:00:00
8277	98	2026-03-16 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-16 00:00:00
8278	99	2026-03-16 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-16 00:00:00
8279	100	2026-03-16 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-16 00:00:00
8280	101	2026-03-16 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-16 00:00:00
8281	102	2026-03-16 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-16 00:00:00
8282	103	2026-03-16 00:00:00	26	64	59.32km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-16 00:00:00
8283	62	2026-03-16 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-16 00:00:00
8284	107	2026-03-16 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-16 00:00:00
8285	108	2026-03-16 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-16 00:00:00
8286	6	2026-03-16 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-16 00:00:00
8287	109	2026-03-16 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-16 00:00:00
8288	13	2026-03-16 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-16 00:00:00
8290	14	2026-03-16 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-16 00:00:00
8291	111	2026-03-16 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-16 00:00:00
8292	21	2026-03-16 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-16 00:00:00
3499	112	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-et-site-nordique-chichilianne-mont-aiguille/	2026-03-16 00:00:00
8294	23	2026-03-16 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-16 00:00:00
8297	115	2026-03-16 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-16 00:00:00
8299	27	2026-03-16 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-16 00:00:00
8300	28	2026-03-16 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-16 00:00:00
8301	117	2026-03-16 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-16 00:00:00
4598	119	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-des-monts-du-pilat/	2026-03-16 00:00:00
8304	33	2026-03-16 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-16 00:00:00
8305	120	2026-03-16 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-16 00:00:00
8306	35	2026-03-16 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-16 00:00:00
8307	121	2026-03-16 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-16 00:00:00
8308	36	2026-03-16 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-16 00:00:00
8310	123	2026-03-16 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-16 00:00:00
8311	124	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-16 00:00:00
8312	125	2026-03-16 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-16 00:00:00
8314	40	2026-03-16 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-16 00:00:00
8315	127	2026-03-16 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-16 00:00:00
8316	128	2026-03-16 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-16 00:00:00
8317	43	2026-03-16 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-16 00:00:00
8318	129	2026-03-16 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-16 00:00:00
8319	130	2026-03-16 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-16 00:00:00
8320	131	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-16 00:00:00
8322	133	2026-03-16 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-16 00:00:00
8323	50	2026-03-16 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-16 00:00:00
8324	134	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-16 00:00:00
8325	135	2026-03-16 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-16 00:00:00
8326	137	2026-03-16 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-16 00:00:00
8327	52	2026-03-16 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-16 00:00:00
8328	138	2026-03-16 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-16 00:00:00
8330	140	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-16 00:00:00
8332	60	2026-03-16 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-16 00:00:00
8333	63	2026-03-16 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-16 00:00:00
8335	143	2026-03-16 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-16 00:00:00
8337	68	2026-03-16 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-16 00:00:00
8338	104	2026-03-16 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-16 00:00:00
8339	145	2026-03-16 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-16 00:00:00
8340	146	2026-03-16 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-16 00:00:00
8341	147	2026-03-16 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-16 00:00:00
8342	75	2026-03-16 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-16 00:00:00
8343	77	2026-03-16 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-16 00:00:00
8344	148	2026-03-16 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-16 00:00:00
8345	105	2026-03-16 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-16 00:00:00
8346	84	2026-03-16 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-16 00:00:00
8348	86	2026-03-16 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-16 00:00:00
8349	150	2026-03-16 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-16 00:00:00
8350	88	2026-03-16 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-16 00:00:00
8351	106	2026-03-16 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-16 00:00:00
8352	151	2026-03-16 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-16 00:00:00
8354	1	2026-03-17 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-17 00:00:00
8355	2	2026-03-17 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-17 00:00:00
8356	3	2026-03-17 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-17 00:00:00
8357	4	2026-03-17 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-17 00:00:00
8358	5	2026-03-17 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-17 00:00:00
8359	7	2026-03-17 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-17 00:00:00
8360	8	2026-03-17 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-17 00:00:00
8361	9	2026-03-17 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-17 00:00:00
8362	10	2026-03-17 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-17 00:00:00
8363	11	2026-03-17 00:00:00	24	27	137.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-17 00:00:00
8364	12	2026-03-17 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-17 00:00:00
8365	15	2026-03-17 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-17 00:00:00
8366	16	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-17 00:00:00
8367	17	2026-03-17 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-17 00:00:00
8368	18	2026-03-17 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-17 00:00:00
8369	19	2026-03-17 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-17 00:00:00
8370	20	2026-03-17 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-17 00:00:00
8371	153	2026-03-17 00:00:00	5	25	33.5km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-17 00:00:00
8372	22	2026-03-17 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-17 00:00:00
8373	24	2026-03-17 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-17 00:00:00
8374	25	2026-03-17 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-17 00:00:00
8375	26	2026-03-17 00:00:00	4	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-17 00:00:00
8376	30	2026-03-17 00:00:00	9	13	29.4km/66.4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-17 00:00:00
8377	31	2026-03-17 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-17 00:00:00
8378	32	2026-03-17 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-17 00:00:00
8379	34	2026-03-17 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-17 00:00:00
8380	37	2026-03-17 00:00:00	14	23	53.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-17 00:00:00
8381	39	2026-03-17 00:00:00	29	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-17 00:00:00
8382	155	2026-03-17 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-17 00:00:00
8383	41	2026-03-17 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-17 00:00:00
8384	42	2026-03-17 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-17 00:00:00
8385	44	2026-03-17 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-17 00:00:00
8386	45	2026-03-17 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-17 00:00:00
8387	46	2026-03-17 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-17 00:00:00
8388	47	2026-03-17 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-17 00:00:00
8389	156	2026-03-17 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-17 00:00:00
8390	48	2026-03-17 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-17 00:00:00
8391	49	2026-03-17 00:00:00	11	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-17 00:00:00
8392	51	2026-03-17 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-17 00:00:00
8393	53	2026-03-17 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-17 00:00:00
8394	54	2026-03-17 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-17 00:00:00
8395	55	2026-03-17 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-17 00:00:00
8396	56	2026-03-17 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-17 00:00:00
8397	57	2026-03-17 00:00:00	21	27	68.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-17 00:00:00
8398	58	2026-03-17 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-17 00:00:00
8399	59	2026-03-17 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-17 00:00:00
8400	61	2026-03-17 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-17 00:00:00
8401	64	2026-03-17 00:00:00	20	21	79.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-17 00:00:00
8402	65	2026-03-17 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-17 00:00:00
8403	66	2026-03-17 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-17 00:00:00
8404	67	2026-03-17 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-17 00:00:00
8405	69	2026-03-17 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-17 00:00:00
8406	70	2026-03-17 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-17 00:00:00
8407	71	2026-03-17 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-17 00:00:00
8408	72	2026-03-17 00:00:00	30	30	99.2km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-17 00:00:00
8409	73	2026-03-17 00:00:00	21	21	57.1km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-17 00:00:00
8410	74	2026-03-17 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-17 00:00:00
8411	76	2026-03-17 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-17 00:00:00
8412	78	2026-03-17 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-17 00:00:00
8413	79	2026-03-17 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-17 00:00:00
8414	80	2026-03-17 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-17 00:00:00
8415	81	2026-03-17 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-17 00:00:00
8416	82	2026-03-17 00:00:00	12	16	44.55km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-17 00:00:00
8417	83	2026-03-17 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-17 00:00:00
8418	85	2026-03-17 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-17 00:00:00
8419	90	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-17 00:00:00
8420	91	2026-03-17 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-17 00:00:00
8421	92	2026-03-17 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-17 00:00:00
8422	93	2026-03-17 00:00:00	1	4	18km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-17 00:00:00
8423	94	2026-03-17 00:00:00	4	5	9.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-17 00:00:00
8424	95	2026-03-17 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-17 00:00:00
8425	96	2026-03-17 00:00:00	0	6	0km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-17 00:00:00
8426	97	2026-03-17 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-17 00:00:00
8427	98	2026-03-17 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-17 00:00:00
8428	99	2026-03-17 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-17 00:00:00
8429	100	2026-03-17 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-17 00:00:00
8430	101	2026-03-17 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-17 00:00:00
8431	102	2026-03-17 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-17 00:00:00
8432	103	2026-03-17 00:00:00	23	64	55.77km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-17 00:00:00
8433	62	2026-03-17 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-17 00:00:00
8434	107	2026-03-17 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-17 00:00:00
8435	108	2026-03-17 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-17 00:00:00
8436	6	2026-03-17 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-17 00:00:00
8437	109	2026-03-17 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-17 00:00:00
8438	13	2026-03-17 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-17 00:00:00
8440	14	2026-03-17 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-17 00:00:00
8441	111	2026-03-17 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-17 00:00:00
8442	21	2026-03-17 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-17 00:00:00
8444	23	2026-03-17 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-17 00:00:00
3680	113	2026-03-17 00:00:00	0	7	0km/56.5km	https://www.nordicfrance.fr/nordicfrance_station/col-du-beal/	2026-03-17 00:00:00
8447	115	2026-03-17 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-17 00:00:00
8449	27	2026-03-17 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-17 00:00:00
8450	28	2026-03-17 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-17 00:00:00
8451	117	2026-03-17 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-17 00:00:00
8452	29	2026-03-17 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-17 00:00:00
8455	33	2026-03-17 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-17 00:00:00
8456	120	2026-03-17 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-17 00:00:00
8457	35	2026-03-17 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-17 00:00:00
8458	121	2026-03-17 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-17 00:00:00
8459	36	2026-03-17 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-17 00:00:00
8461	123	2026-03-17 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-17 00:00:00
8462	124	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-17 00:00:00
8463	125	2026-03-17 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-17 00:00:00
8465	40	2026-03-17 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-17 00:00:00
8466	127	2026-03-17 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-17 00:00:00
8467	128	2026-03-17 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-17 00:00:00
8468	43	2026-03-17 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-17 00:00:00
8469	129	2026-03-17 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-17 00:00:00
8470	130	2026-03-17 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-17 00:00:00
8471	131	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-17 00:00:00
8473	133	2026-03-17 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-17 00:00:00
8474	50	2026-03-17 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-17 00:00:00
8475	134	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-17 00:00:00
8476	135	2026-03-17 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-17 00:00:00
8477	137	2026-03-17 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-17 00:00:00
8478	52	2026-03-17 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-17 00:00:00
8479	138	2026-03-17 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-17 00:00:00
8481	140	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-17 00:00:00
8483	60	2026-03-17 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-17 00:00:00
8484	63	2026-03-17 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-17 00:00:00
8486	143	2026-03-17 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-17 00:00:00
8488	68	2026-03-17 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-17 00:00:00
8489	104	2026-03-17 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-17 00:00:00
8490	145	2026-03-17 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-17 00:00:00
8491	146	2026-03-17 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-17 00:00:00
8492	147	2026-03-17 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-17 00:00:00
8493	75	2026-03-17 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-17 00:00:00
8494	77	2026-03-17 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-17 00:00:00
8495	148	2026-03-17 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-17 00:00:00
8496	105	2026-03-17 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-17 00:00:00
8497	154	2026-03-17 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-17 00:00:00
8498	84	2026-03-17 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-17 00:00:00
8500	86	2026-03-17 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-17 00:00:00
8501	150	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-17 00:00:00
8502	88	2026-03-17 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-17 00:00:00
8503	106	2026-03-17 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-17 00:00:00
8504	151	2026-03-17 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-17 00:00:00
7070	152	2026-03-17 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree/	2026-03-17 00:00:00
8506	1	2026-03-18 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-18 00:00:00
8507	2	2026-03-18 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-18 00:00:00
8508	3	2026-03-18 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-18 00:00:00
8509	4	2026-03-18 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-18 00:00:00
8510	5	2026-03-18 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-18 00:00:00
8511	7	2026-03-18 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-18 00:00:00
8512	8	2026-03-18 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-18 00:00:00
8513	9	2026-03-18 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-18 00:00:00
8514	10	2026-03-18 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-18 00:00:00
8515	11	2026-03-18 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-18 00:00:00
8516	12	2026-03-18 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-18 00:00:00
8517	15	2026-03-18 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-18 00:00:00
8518	16	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-18 00:00:00
8519	17	2026-03-18 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-18 00:00:00
8520	18	2026-03-18 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-18 00:00:00
8521	19	2026-03-18 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-18 00:00:00
8522	20	2026-03-18 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-18 00:00:00
8523	153	2026-03-18 00:00:00	5	25	33.5km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-18 00:00:00
8524	22	2026-03-18 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-18 00:00:00
8525	24	2026-03-18 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-18 00:00:00
8526	25	2026-03-18 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-18 00:00:00
8527	26	2026-03-18 00:00:00	4	14	10km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-18 00:00:00
8528	30	2026-03-18 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-18 00:00:00
8529	31	2026-03-18 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-18 00:00:00
8530	32	2026-03-18 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-18 00:00:00
8531	34	2026-03-18 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-18 00:00:00
8532	39	2026-03-18 00:00:00	29	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-18 00:00:00
8533	155	2026-03-18 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-18 00:00:00
8534	41	2026-03-18 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-18 00:00:00
8535	42	2026-03-18 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-18 00:00:00
8536	44	2026-03-18 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-18 00:00:00
8537	45	2026-03-18 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-18 00:00:00
8538	46	2026-03-18 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-18 00:00:00
8539	47	2026-03-18 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-18 00:00:00
8540	156	2026-03-18 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-18 00:00:00
8541	48	2026-03-18 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-18 00:00:00
8542	49	2026-03-18 00:00:00	11	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-18 00:00:00
8543	51	2026-03-18 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-18 00:00:00
8544	53	2026-03-18 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-18 00:00:00
8545	54	2026-03-18 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-18 00:00:00
8546	55	2026-03-18 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-18 00:00:00
8547	56	2026-03-18 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-18 00:00:00
8548	57	2026-03-18 00:00:00	21	27	68.5km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-18 00:00:00
8549	58	2026-03-18 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-18 00:00:00
8550	59	2026-03-18 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-18 00:00:00
8551	61	2026-03-18 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-18 00:00:00
8552	64	2026-03-18 00:00:00	19	21	79.4km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-18 00:00:00
8553	65	2026-03-18 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-18 00:00:00
8554	66	2026-03-18 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-18 00:00:00
8555	67	2026-03-18 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-18 00:00:00
8556	69	2026-03-18 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-18 00:00:00
8557	70	2026-03-18 00:00:00	5	6	17.8km/27.3km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-18 00:00:00
8558	71	2026-03-18 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-18 00:00:00
8559	72	2026-03-18 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-18 00:00:00
8560	73	2026-03-18 00:00:00	20	21	54.6km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-18 00:00:00
8561	74	2026-03-18 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-18 00:00:00
8562	76	2026-03-18 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-18 00:00:00
8563	78	2026-03-18 00:00:00	21	28	111.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-18 00:00:00
8564	79	2026-03-18 00:00:00	14	23	89km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-18 00:00:00
8565	80	2026-03-18 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-18 00:00:00
8566	81	2026-03-18 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-18 00:00:00
8567	82	2026-03-18 00:00:00	11	16	43.95km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-18 00:00:00
8568	83	2026-03-18 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-18 00:00:00
8569	85	2026-03-18 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-18 00:00:00
8570	90	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-18 00:00:00
8571	91	2026-03-18 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-18 00:00:00
8572	92	2026-03-18 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-18 00:00:00
8573	94	2026-03-18 00:00:00	4	5	9.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-18 00:00:00
8574	95	2026-03-18 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-18 00:00:00
8575	96	2026-03-18 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-18 00:00:00
8576	97	2026-03-18 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-18 00:00:00
8577	98	2026-03-18 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-18 00:00:00
8578	99	2026-03-18 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-18 00:00:00
8579	100	2026-03-18 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-18 00:00:00
8580	101	2026-03-18 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-18 00:00:00
8581	102	2026-03-18 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-18 00:00:00
8582	103	2026-03-18 00:00:00	21	64	52.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-18 00:00:00
8583	62	2026-03-18 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-18 00:00:00
8584	107	2026-03-18 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-18 00:00:00
8585	108	2026-03-18 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-18 00:00:00
8586	6	2026-03-18 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-18 00:00:00
8587	109	2026-03-18 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-18 00:00:00
8588	13	2026-03-18 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-18 00:00:00
8590	14	2026-03-18 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-18 00:00:00
8591	111	2026-03-18 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-18 00:00:00
8592	21	2026-03-18 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-18 00:00:00
8594	23	2026-03-18 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-18 00:00:00
8597	115	2026-03-18 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-18 00:00:00
8599	27	2026-03-18 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-18 00:00:00
8600	28	2026-03-18 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-18 00:00:00
8601	117	2026-03-18 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-18 00:00:00
8602	29	2026-03-18 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-18 00:00:00
8605	33	2026-03-18 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-18 00:00:00
8606	120	2026-03-18 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-18 00:00:00
8607	35	2026-03-18 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-18 00:00:00
8608	121	2026-03-18 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-18 00:00:00
8609	36	2026-03-18 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-18 00:00:00
8611	123	2026-03-18 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-18 00:00:00
8612	37	2026-03-18 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-18 00:00:00
8613	124	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-18 00:00:00
8614	125	2026-03-18 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-18 00:00:00
8616	40	2026-03-18 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-18 00:00:00
8617	127	2026-03-18 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-18 00:00:00
8618	128	2026-03-18 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-18 00:00:00
8619	43	2026-03-18 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-18 00:00:00
8620	129	2026-03-18 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-18 00:00:00
8621	130	2026-03-18 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-18 00:00:00
8622	131	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-18 00:00:00
8624	133	2026-03-18 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-18 00:00:00
8625	50	2026-03-18 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-18 00:00:00
8626	134	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-18 00:00:00
8627	135	2026-03-18 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-18 00:00:00
8628	137	2026-03-18 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-18 00:00:00
8629	52	2026-03-18 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-18 00:00:00
8630	138	2026-03-18 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-18 00:00:00
8632	140	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-18 00:00:00
8634	60	2026-03-18 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-18 00:00:00
8635	63	2026-03-18 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-18 00:00:00
8637	143	2026-03-18 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-18 00:00:00
8639	68	2026-03-18 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-18 00:00:00
8640	104	2026-03-18 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-18 00:00:00
8641	145	2026-03-18 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-18 00:00:00
8642	146	2026-03-18 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-18 00:00:00
8643	147	2026-03-18 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-18 00:00:00
8644	75	2026-03-18 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-18 00:00:00
8645	77	2026-03-18 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-18 00:00:00
8646	148	2026-03-18 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-18 00:00:00
8647	105	2026-03-18 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-18 00:00:00
8648	154	2026-03-18 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-18 00:00:00
8649	84	2026-03-18 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-18 00:00:00
8650	149	2026-03-18 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-18 00:00:00
8651	86	2026-03-18 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-18 00:00:00
8652	150	2026-03-18 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-18 00:00:00
8653	88	2026-03-18 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-18 00:00:00
8654	106	2026-03-18 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-18 00:00:00
8655	151	2026-03-18 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-18 00:00:00
8656	93	2026-03-18 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-18 00:00:00
8658	1	2026-03-19 00:00:00	17	17	73km/73km	https://www.nordicfrance.fr/nordicfrance_station/aiguilles-abries-ristolas-vallee-du-haut-guil/	2026-03-19 00:00:00
8659	2	2026-03-19 00:00:00	5	9	30km/51km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-agy/	2026-03-19 00:00:00
8660	3	2026-03-19 00:00:00	25	27	57.6km/62.7km	https://www.nordicfrance.fr/nordicfrance_station/alpe-du-grand-serre/	2026-03-19 00:00:00
8661	4	2026-03-19 00:00:00	18	21	74.6km/98.6km	https://www.nordicfrance.fr/nordicfrance_station/ancelle/	2026-03-19 00:00:00
8662	5	2026-03-19 00:00:00	17	17	94km/94km	https://www.nordicfrance.fr/nordicfrance_station/arvieux-souliers-vallee-de-lizoard/	2026-03-19 00:00:00
8663	7	2026-03-19 00:00:00	10	10	40km/40km	https://www.nordicfrance.fr/nordicfrance_station/aussois-val-cenis-sardiere/	2026-03-19 00:00:00
8664	8	2026-03-19 00:00:00	29	31	73km/73.4km	https://www.nordicfrance.fr/nordicfrance_station/station-de-beille/	2026-03-19 00:00:00
8665	9	2026-03-19 00:00:00	2	23	21.5km/137.3km	https://www.nordicfrance.fr/nordicfrance_station/bellefontaine/	2026-03-19 00:00:00
8666	10	2026-03-19 00:00:00	3	8	13.8km/30.6km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-bellevaux/	2026-03-19 00:00:00
8667	11	2026-03-19 00:00:00	25	27	145.5km/169km	https://www.nordicfrance.fr/nordicfrance_station/bessans/	2026-03-19 00:00:00
8668	12	2026-03-19 00:00:00	7	9	35.45km/35.75km	https://www.nordicfrance.fr/nordicfrance_station/beuil-valberg/	2026-03-19 00:00:00
8669	15	2026-03-19 00:00:00	8	9	27.8km/38.3km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-brison-solaison/	2026-03-19 00:00:00
8670	16	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/casterino/	2026-03-19 00:00:00
8671	17	2026-03-19 00:00:00	14	15	62.5km/73.5km	https://www.nordicfrance.fr/nordicfrance_station/ceillac-vallee-du-queyras/	2026-03-19 00:00:00
8672	18	2026-03-19 00:00:00	5	12	42km/95km	https://www.nordicfrance.fr/nordicfrance_station/cervieres-izoard/	2026-03-19 00:00:00
8673	19	2026-03-19 00:00:00	12	16	36.4km/40.4km	https://www.nordicfrance.fr/nordicfrance_station/champagny-en-vanoise/	2026-03-19 00:00:00
8674	20	2026-03-19 00:00:00	25	25	82.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/chamrousse/	2026-03-19 00:00:00
8675	22	2026-03-19 00:00:00	12	12	43.1km/43.1km	https://www.nordicfrance.fr/nordicfrance_station/col-dornon/	2026-03-19 00:00:00
8676	24	2026-03-19 00:00:00	8	8	47.7km/47.7km	https://www.nordicfrance.fr/nordicfrance_station/crevoux-la-chalp/	2026-03-19 00:00:00
8677	25	2026-03-19 00:00:00	6	6	56km/56km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-col-de-la-llose/	2026-03-19 00:00:00
8678	26	2026-03-19 00:00:00	3	14	4km/59km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-la-bresse-lispach/	2026-03-19 00:00:00
8679	30	2026-03-19 00:00:00	0	5	0km/35.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-grand-coin/	2026-03-19 00:00:00
8680	31	2026-03-19 00:00:00	11	13	37km/53km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-du-barioz/	2026-03-19 00:00:00
8681	32	2026-03-19 00:00:00	43	46	84.5km/96km	https://www.nordicfrance.fr/nordicfrance_station/site-du-haut-vercors/	2026-03-19 00:00:00
8682	34	2026-03-19 00:00:00	0	20	0km/133.7km	https://www.nordicfrance.fr/nordicfrance_station/font-durle/	2026-03-19 00:00:00
8683	38	2026-03-19 00:00:00	13	42	27.4km/128.4km	https://www.nordicfrance.fr/nordicfrance_station/ski-de-fond-haut-giffre/	2026-03-19 00:00:00
8684	39	2026-03-19 00:00:00	29	74	176.1km/364.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-hautes-combes-haut-jura/	2026-03-19 00:00:00
8685	155	2026-03-19 00:00:00	0	35	0km/212.2km	https://www.nordicfrance.fr/nordicfrance_station/herbouilly/	2026-03-19 00:00:00
8686	41	2026-03-19 00:00:00	2	9	0km/21.8km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-dabondance/	2026-03-19 00:00:00
8687	42	2026-03-19 00:00:00	19	22	45.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/la-clusaz-espace-nordique-des-confins/	2026-03-19 00:00:00
8688	44	2026-03-19 00:00:00	8	8	27.9km/27.9km	https://www.nordicfrance.fr/nordicfrance_station/la-draye/	2026-03-19 00:00:00
8689	45	2026-03-19 00:00:00	0	59	0km/378.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-chavade/	2026-03-19 00:00:00
8690	46	2026-03-19 00:00:00	11	12	64.9km/74.9km	https://www.nordicfrance.fr/nordicfrance_station/val-doronaye/	2026-03-19 00:00:00
8691	47	2026-03-19 00:00:00	9	10	45km/49.2km	https://www.nordicfrance.fr/nordicfrance_station/le-boreon/	2026-03-19 00:00:00
8692	156	2026-03-19 00:00:00	17	18	32.95km/35.95km	https://www.nordicfrance.fr/nordicfrance_station/le-devoluy/	2026-03-19 00:00:00
8693	48	2026-03-19 00:00:00	5	26	24.6km/77.6km	https://www.nordicfrance.fr/nordicfrance_station/les-entremonts-en-chartreuse/	2026-03-19 00:00:00
8694	49	2026-03-19 00:00:00	11	14	44.3km/62.3km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-bornand/	2026-03-19 00:00:00
8695	51	2026-03-19 00:00:00	13	14	31.2km/31.2km	https://www.nordicfrance.fr/nordicfrance_station/les-contamines-montjoie/	2026-03-19 00:00:00
8696	53	2026-03-19 00:00:00	12	13	45.9km/50.4km	https://www.nordicfrance.fr/nordicfrance_station/les-glieres/	2026-03-19 00:00:00
8697	54	2026-03-19 00:00:00	32	32	181.2km/181.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-saisies-ski-de-fond-aux-saisies/	2026-03-19 00:00:00
8698	55	2026-03-19 00:00:00	5	13	13.5km/30km	https://www.nordicfrance.fr/nordicfrance_station/longchaumois-le-rosset-station-de-ski-pour-tous/	2026-03-19 00:00:00
8699	56	2026-03-19 00:00:00	0	7	0km/36.9km	https://www.nordicfrance.fr/nordicfrance_station/lus-la-jarjatte/	2026-03-19 00:00:00
8700	57	2026-03-19 00:00:00	22	27	70.7km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/megeve/	2026-03-19 00:00:00
8701	58	2026-03-19 00:00:00	16	17	97km/101km	https://www.nordicfrance.fr/nordicfrance_station/molines-saint-veran-vallee-des-aigues/	2026-03-19 00:00:00
8702	59	2026-03-19 00:00:00	26	31	192km/240.5km	https://www.nordicfrance.fr/nordicfrance_station/monts-jura-la-vattay-la-valserine/	2026-03-19 00:00:00
8703	61	2026-03-19 00:00:00	11	11	37.6km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/morzine-avoriaz/	2026-03-19 00:00:00
8704	64	2026-03-19 00:00:00	18	21	73.9km/80.9km	https://www.nordicfrance.fr/nordicfrance_station/naves/	2026-03-19 00:00:00
8705	65	2026-03-19 00:00:00	20	22	81km/80km	https://www.nordicfrance.fr/nordicfrance_station/nevache/	2026-03-19 00:00:00
8706	66	2026-03-19 00:00:00	21	22	55.6km/56.3km	https://www.nordicfrance.fr/nordicfrance_station/peisey-vallandry/	2026-03-19 00:00:00
8707	67	2026-03-19 00:00:00	5	12	19.3km/40.95km	https://www.nordicfrance.fr/nordicfrance_station/plaine-joux-les-brasses/	2026-03-19 00:00:00
8708	69	2026-03-19 00:00:00	12	12	67.1km/67.1km	https://www.nordicfrance.fr/nordicfrance_station/https-www-savoie-mont-blanc-nordic-com-domaines-nordiques-station-3629/	2026-03-19 00:00:00
8709	70	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/pralognan-la-vanoise/	2026-03-19 00:00:00
8710	71	2026-03-19 00:00:00	2	28	5.2km/90.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-prat-de-bouc/	2026-03-19 00:00:00
8711	72	2026-03-19 00:00:00	29	30	99.4km/99.2km	https://www.nordicfrance.fr/nordicfrance_station/praz-de-lys-sommand/	2026-03-19 00:00:00
8712	73	2026-03-19 00:00:00	20	21	54.6km/57.1km	https://www.nordicfrance.fr/nordicfrance_station/nordique-puy-saint-vincent/	2026-03-19 00:00:00
8713	74	2026-03-19 00:00:00	6	6	28.9km/28.9km	https://www.nordicfrance.fr/nordicfrance_station/3040/	2026-03-19 00:00:00
8714	76	2026-03-19 00:00:00	4	15	27km/80.55km	https://www.nordicfrance.fr/nordicfrance_station/reallon/	2026-03-19 00:00:00
8715	78	2026-03-19 00:00:00	20	28	107.3km/157.3km	https://www.nordicfrance.fr/nordicfrance_station/savoie-grand-revard/	2026-03-19 00:00:00
8716	79	2026-03-19 00:00:00	15	23	93km/99.15km	https://www.nordicfrance.fr/nordicfrance_station/serre-chevalier/	2026-03-19 00:00:00
8717	80	2026-03-19 00:00:00	16	23	76.11km/122.11km	https://www.nordicfrance.fr/nordicfrance_station/altiservice-font-romeu-pyrenees2000/	2026-03-19 00:00:00
8718	81	2026-03-19 00:00:00	4	6	16.5km/29km	https://www.nordicfrance.fr/nordicfrance_station/site-nordique-domaine-blanche-serre-poncon/	2026-03-19 00:00:00
8719	82	2026-03-19 00:00:00	11	16	43.95km/58.85km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-la-vallouise/	2026-03-19 00:00:00
8720	83	2026-03-19 00:00:00	0	6	0km/37.6km	https://www.nordicfrance.fr/nordicfrance_station/stade-raphael-poiree-2/	2026-03-19 00:00:00
8721	85	2026-03-19 00:00:00	18	62	92.4km/286.5km	https://www.nordicfrance.fr/nordicfrance_station/station-des-rousses/	2026-03-19 00:00:00
8722	90	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/val-d-allos/	2026-03-19 00:00:00
8723	91	2026-03-19 00:00:00	6	15	24.7km/82.7km	https://www.nordicfrance.fr/nordicfrance_station/val-cenis-bramans/	2026-03-19 00:00:00
8724	92	2026-03-19 00:00:00	22	22	33.9km/33.9km	https://www.nordicfrance.fr/nordicfrance_station/val-des-pres-les-alberts/	2026-03-19 00:00:00
8725	94	2026-03-19 00:00:00	4	5	9.52km/19.52km	https://www.nordicfrance.fr/nordicfrance_station/valloire-galibier/	2026-03-19 00:00:00
8726	95	2026-03-19 00:00:00	10	16	35km/55km	https://www.nordicfrance.fr/nordicfrance_station/chamonix/	2026-03-19 00:00:00
8727	96	2026-03-19 00:00:00	6	6	40.5km/40.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-villar-darene-pays-de-la-meije/	2026-03-19 00:00:00
8728	97	2026-03-19 00:00:00	5	12	6.6km/40.6km	https://www.nordicfrance.fr/nordicfrance_station/villard-st-pancrace/	2026-03-19 00:00:00
8729	98	2026-03-19 00:00:00	1	2	2km/4km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-barcelonnette/	2026-03-19 00:00:00
8730	99	2026-03-19 00:00:00	0	9	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/centre-de-ski-nordique-la-ruchere-en-chartreuse/	2026-03-19 00:00:00
8731	100	2026-03-19 00:00:00	9	38	22.5km/203.7km	https://www.nordicfrance.fr/nordicfrance_station/domaine-de-chamechaude-col-de-porte-sappey-en-chartreuse-st-hugues-de-chartreuse/	2026-03-19 00:00:00
8732	101	2026-03-19 00:00:00	0	14	0km/63.4km	https://www.nordicfrance.fr/nordicfrance_station/la-baraque-des-bouviers/	2026-03-19 00:00:00
8733	102	2026-03-19 00:00:00	15	15	36.4km/36.4km	https://www.nordicfrance.fr/nordicfrance_station/le-semnoz/	2026-03-19 00:00:00
8734	103	2026-03-19 00:00:00	21	64	52.72km/150.97km	https://www.nordicfrance.fr/nordicfrance_station/les-moises/	2026-03-19 00:00:00
8735	62	2026-03-19 00:00:00	2	24	0km/147.8km	https://www.nordicfrance.fr/nordicfrance_station/mouthe-chez-liadet/	2026-03-19 00:00:00
8736	107	2026-03-19 00:00:00	0	7	0km/44.8km	https://www.nordicfrance.fr/nordicfrance_station/apremont/	2026-03-19 00:00:00
8737	108	2026-03-19 00:00:00	0	13	0km/88.6km	https://www.nordicfrance.fr/nordicfrance_station/arc-sous-cicon/	2026-03-19 00:00:00
8738	6	2026-03-19 00:00:00	0	6	0km/32.3km	https://www.nordicfrance.fr/nordicfrance_station/areches-beaufort/	2026-03-19 00:00:00
8739	109	2026-03-19 00:00:00	0	4	0km/19km	https://www.nordicfrance.fr/nordicfrance_station/belleydoux/	2026-03-19 00:00:00
8740	13	2026-03-19 00:00:00	0	15	0km/41.55km	https://www.nordicfrance.fr/nordicfrance_station/bleymard-mont-lozere/	2026-03-19 00:00:00
8742	14	2026-03-19 00:00:00	0	18	0km/44.5km	https://www.nordicfrance.fr/nordicfrance_station/brameloup/	2026-03-19 00:00:00
8743	111	2026-03-19 00:00:00	0	9	0km/73km	https://www.nordicfrance.fr/nordicfrance_station/centre-montagnard-de-lachat/	2026-03-19 00:00:00
8744	21	2026-03-19 00:00:00	0	27	0km/231.2km	https://www.nordicfrance.fr/nordicfrance_station/chapelle-des-bois/	2026-03-19 00:00:00
8745	153	2026-03-19 00:00:00	0	25	0km/117.5km	https://www.nordicfrance.fr/nordicfrance_station/chaux-neuve-le-pre-poncet/	2026-03-19 00:00:00
8747	23	2026-03-19 00:00:00	0	11	0km/111km	https://www.nordicfrance.fr/nordicfrance_station/col-de-la-loge/	2026-03-19 00:00:00
8750	115	2026-03-19 00:00:00	0	20	0km/84.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-des-bas-rupts-a-gerardmer-vosges/	2026-03-19 00:00:00
8752	27	2026-03-19 00:00:00	0	13	0km/57.4km	https://www.nordicfrance.fr/nordicfrance_station/sur-lyand/	2026-03-19 00:00:00
8753	28	2026-03-19 00:00:00	0	19	0km/161.4km	https://www.nordicfrance.fr/nordicfrance_station/cretes-du-forez/	2026-03-19 00:00:00
8754	117	2026-03-19 00:00:00	0	7	0km/47.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-meygal/	2026-03-19 00:00:00
8755	29	2026-03-19 00:00:00	0	13	0km/67.8km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-du-mezenc/	2026-03-19 00:00:00
8758	33	2026-03-19 00:00:00	0	37	0km/144.5km	https://www.nordicfrance.fr/nordicfrance_station/foncine-le-haut/	2026-03-19 00:00:00
8759	120	2026-03-19 00:00:00	0	6	0km/21km	https://www.nordicfrance.fr/nordicfrance_station/frasne/	2026-03-19 00:00:00
8760	35	2026-03-19 00:00:00	8	10	22.5km/31.7km	https://www.nordicfrance.fr/nordicfrance_station/freissinieres/	2026-03-19 00:00:00
8761	121	2026-03-19 00:00:00	0	4	0km/28.1km	https://www.nordicfrance.fr/nordicfrance_station/gilley/	2026-03-19 00:00:00
8762	36	2026-03-19 00:00:00	0	19	0km/110.5km	https://www.nordicfrance.fr/nordicfrance_station/giron-1000/	2026-03-19 00:00:00
8764	123	2026-03-19 00:00:00	0	5	0km/32km	https://www.nordicfrance.fr/nordicfrance_station/greolieres-les-neiges/	2026-03-19 00:00:00
8765	37	2026-03-19 00:00:00	5	23	19.5km/89.5km	https://www.nordicfrance.fr/nordicfrance_station/haut-champsaur/	2026-03-19 00:00:00
8766	124	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/haut-saugeais-blanc/	2026-03-19 00:00:00
8767	125	2026-03-19 00:00:00	0	37	0km/232.6km	https://www.nordicfrance.fr/nordicfrance_station/haute-joux/	2026-03-19 00:00:00
8769	40	2026-03-19 00:00:00	0	19	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/le-chioula-2/	2026-03-19 00:00:00
8770	127	2026-03-19 00:00:00	0	5	0km/22km	https://www.nordicfrance.fr/nordicfrance_station/la-chapelle-rambaud/	2026-03-19 00:00:00
8771	128	2026-03-19 00:00:00	0	11	0km/51.7km	https://www.nordicfrance.fr/nordicfrance_station/la-cernay-blanche/	2026-03-19 00:00:00
8772	43	2026-03-19 00:00:00	0	12	0km/97.3km	https://www.nordicfrance.fr/nordicfrance_station/nordic-la-colle-saint-michel/	2026-03-19 00:00:00
8773	129	2026-03-19 00:00:00	0	15	0km/63.6km	https://www.nordicfrance.fr/nordicfrance_station/domaine-du-bugnon/	2026-03-19 00:00:00
8774	130	2026-03-19 00:00:00	0	29	0km/68km	https://www.nordicfrance.fr/nordicfrance_station/laguiole/	2026-03-19 00:00:00
8775	131	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/lans-en-vercors/	2026-03-19 00:00:00
8777	133	2026-03-19 00:00:00	0	9	0km/46.7km	https://www.nordicfrance.fr/nordicfrance_station/le-grand-echaillon/	2026-03-19 00:00:00
8778	50	2026-03-19 00:00:00	0	10	0km/58.6km	https://www.nordicfrance.fr/nordicfrance_station/le-mas-de-la-barque-espace-nordique-du-mont-lozere/	2026-03-19 00:00:00
8779	134	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/le-poli/	2026-03-19 00:00:00
8780	135	2026-03-19 00:00:00	0	3	0km/28.8km	https://www.nordicfrance.fr/nordicfrance_station/le-saleve/	2026-03-19 00:00:00
8781	137	2026-03-19 00:00:00	0	8	0km/24.9km	https://www.nordicfrance.fr/nordicfrance_station/les-crozets/	2026-03-19 00:00:00
8782	52	2026-03-19 00:00:00	0	41	0km/140.9km	https://www.nordicfrance.fr/nordicfrance_station/les-fourgs-lherba/	2026-03-19 00:00:00
8783	138	2026-03-19 00:00:00	0	5	0km/18.4km	https://www.nordicfrance.fr/nordicfrance_station/les-sept-laux-papoutel-beldina/	2026-03-19 00:00:00
8785	140	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/	2026-03-19 00:00:00
8787	60	2026-03-19 00:00:00	4	17	24.3km/71.6km	https://www.nordicfrance.fr/nordicfrance_station/morbier/	2026-03-19 00:00:00
8788	63	2026-03-19 00:00:00	0	33	0km/136.7km	https://www.nordicfrance.fr/nordicfrance_station/metabief-mont-dor/	2026-03-19 00:00:00
8790	143	2026-03-19 00:00:00	0	2	0km/7.5km	https://www.nordicfrance.fr/nordicfrance_station/orange-pays-rochois/	2026-03-19 00:00:00
8792	68	2026-03-19 00:00:00	0	31	0km/86.17km	https://www.nordicfrance.fr/nordicfrance_station/plateau-dhauteville/	2026-03-19 00:00:00
8793	104	2026-03-19 00:00:00	0	25	0km/96.35km	https://www.nordicfrance.fr/nordicfrance_station/combe-saint-pierre/	2026-03-19 00:00:00
8794	145	2026-03-19 00:00:00	0	11	0km/49.1km	https://www.nordicfrance.fr/nordicfrance_station/plateau-du-russey/	2026-03-19 00:00:00
8795	146	2026-03-19 00:00:00	0	41	0km/171.9km	https://www.nordicfrance.fr/nordicfrance_station/pontarlier-larmont/	2026-03-19 00:00:00
8796	147	2026-03-19 00:00:00	0	24	0km/114.1km	https://www.nordicfrance.fr/nordicfrance_station/prenovel-les-piards/	2026-03-19 00:00:00
8797	75	2026-03-19 00:00:00	0	8	0km/50km	https://www.nordicfrance.fr/nordicfrance_station/rochelotte/	2026-03-19 00:00:00
8798	77	2026-03-19 00:00:00	0	3	0km/11.5km	https://www.nordicfrance.fr/nordicfrance_station/espace-nordique-de-saint-paul-sur-ubaye/	2026-03-19 00:00:00
8799	148	2026-03-19 00:00:00	0	8	0km/44.6km	https://www.nordicfrance.fr/nordicfrance_station/saint-pierre-en-grandvaux-tremontagne/	2026-03-19 00:00:00
8800	105	2026-03-19 00:00:00	0	20	0km/103.5km	https://www.nordicfrance.fr/nordicfrance_station/saint-urcize/	2026-03-19 00:00:00
8801	154	2026-03-19 00:00:00	0	24	0km/162.2km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-autrans-meaudre-en-vercors/	2026-03-19 00:00:00
8802	84	2026-03-19 00:00:00	0	9	0km/56.6km	https://www.nordicfrance.fr/nordicfrance_station/station-gap-bayard/	2026-03-19 00:00:00
8803	149	2026-03-19 00:00:00	4	11	24km/55km	https://www.nordicfrance.fr/nordicfrance_station/station-des-coulmes-centre-nordique-des-coulmes/	2026-03-19 00:00:00
8804	86	2026-03-19 00:00:00	0	18	0km/105.1km	https://www.nordicfrance.fr/nordicfrance_station/station-du-lac-blanc-dans-le-massif-des-vosges/	2026-03-19 00:00:00
8805	150	2026-03-19 00:00:00	0	0	0km/0km	https://www.nordicfrance.fr/nordicfrance_station/station-du-semnoz/	2026-03-19 00:00:00
8806	88	2026-03-19 00:00:00	0	13	0km/62.5km	https://www.nordicfrance.fr/nordicfrance_station/domaine-nordique-de-sur-lyand-grand-colombier/	2026-03-19 00:00:00
8807	106	2026-03-19 00:00:00	4	49	8.6km/171.231km	https://www.nordicfrance.fr/nordicfrance_station/val-de-morteau/	2026-03-19 00:00:00
8808	151	2026-03-19 00:00:00	0	5	0km/29.7km	https://www.nordicfrance.fr/nordicfrance_station/val-de-vennes/	2026-03-19 00:00:00
8809	93	2026-03-19 00:00:00	0	4	0km/38km	https://www.nordicfrance.fr/nordicfrance_station/valgaudemar/	2026-03-19 00:00:00
\.


--
-- TOC entry 4071 (class 0 OID 18876)
-- Dependencies: 378
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
9ff94077-a570-41ec-b557-3963fcb8dba6	faaa94926c2a93211023cf34d216788a3863b6b35c60e67d85b6cc645a1680eb	2026-02-24 22:05:44.474342+00	0001_init	\N	\N	2026-02-24 22:05:44.402247+00	1
\.


--
-- TOC entry 4067 (class 0 OID 17267)
-- Dependencies: 370
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-02-23 20:24:20
20211116045059	2026-02-23 20:24:20
20211116050929	2026-02-23 20:24:20
20211116051442	2026-02-23 20:24:20
20211116212300	2026-02-23 20:24:20
20211116213355	2026-02-23 20:24:20
20211116213934	2026-02-23 20:24:20
20211116214523	2026-02-23 20:24:21
20211122062447	2026-02-23 20:24:21
20211124070109	2026-02-23 20:24:21
20211202204204	2026-02-23 20:24:21
20211202204605	2026-02-23 20:24:21
20211210212804	2026-02-23 20:24:21
20211228014915	2026-02-23 20:24:21
20220107221237	2026-02-23 20:24:21
20220228202821	2026-02-23 20:24:21
20220312004840	2026-02-23 20:24:22
20220603231003	2026-02-23 20:24:22
20220603232444	2026-02-23 20:24:22
20220615214548	2026-02-23 20:24:22
20220712093339	2026-02-23 20:24:22
20220908172859	2026-02-23 20:24:22
20220916233421	2026-02-23 20:24:22
20230119133233	2026-02-23 20:24:22
20230128025114	2026-02-23 20:24:22
20230128025212	2026-02-23 20:24:22
20230227211149	2026-02-23 20:24:23
20230228184745	2026-02-23 20:24:23
20230308225145	2026-02-23 20:24:23
20230328144023	2026-02-23 20:24:23
20231018144023	2026-02-23 20:24:23
20231204144023	2026-02-23 20:24:23
20231204144024	2026-02-23 20:24:23
20231204144025	2026-02-23 20:24:23
20240108234812	2026-02-23 20:24:23
20240109165339	2026-02-23 20:24:23
20240227174441	2026-02-23 20:24:24
20240311171622	2026-02-23 20:24:24
20240321100241	2026-02-23 20:24:24
20240401105812	2026-02-23 20:24:24
20240418121054	2026-02-23 20:24:24
20240523004032	2026-02-23 20:24:25
20240618124746	2026-02-23 20:24:25
20240801235015	2026-02-23 20:24:25
20240805133720	2026-02-23 20:24:25
20240827160934	2026-02-23 20:24:25
20240919163303	2026-02-23 20:24:25
20240919163305	2026-02-23 20:24:25
20241019105805	2026-02-23 20:24:25
20241030150047	2026-02-23 20:24:26
20241108114728	2026-02-23 20:24:26
20241121104152	2026-02-23 20:24:26
20241130184212	2026-02-23 20:24:26
20241220035512	2026-02-23 20:24:26
20241220123912	2026-02-23 20:24:26
20241224161212	2026-02-23 20:24:26
20250107150512	2026-02-23 20:24:26
20250110162412	2026-02-23 20:24:26
20250123174212	2026-02-23 20:24:26
20250128220012	2026-02-23 20:24:27
20250506224012	2026-02-23 20:24:27
20250523164012	2026-02-23 20:24:27
20250714121412	2026-02-23 20:24:27
20250905041441	2026-02-23 20:24:27
20251103001201	2026-02-23 20:24:27
20251120212548	2026-02-23 20:24:27
20251120215549	2026-02-23 20:24:27
20260218120000	2026-04-09 15:25:49
20260326120000	2026-04-10 13:10:47
\.


--
-- TOC entry 4069 (class 0 OID 17289)
-- Dependencies: 373
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter) FROM stdin;
\.


--
-- TOC entry 4060 (class 0 OID 17086)
-- Dependencies: 363
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4064 (class 0 OID 17206)
-- Dependencies: 367
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- TOC entry 4065 (class 0 OID 17219)
-- Dependencies: 368
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4059 (class 0 OID 17078)
-- Dependencies: 362
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-02-23 10:51:12.229557
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-02-23 10:51:12.264306
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-02-23 10:51:12.273679
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-02-23 10:51:12.30097
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-02-23 10:51:12.314537
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-02-23 10:51:12.319701
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-02-23 10:51:12.325602
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-02-23 10:51:12.331246
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-02-23 10:51:12.336267
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-02-23 10:51:12.341497
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-02-23 10:51:12.346874
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-02-23 10:51:12.352421
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-02-23 10:51:12.358243
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-02-23 10:51:12.363606
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-02-23 10:51:12.368973
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-02-23 10:51:12.395477
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-02-23 10:51:12.400938
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-02-23 10:51:12.406166
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-02-23 10:51:12.411198
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-02-23 10:51:12.418547
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-02-23 10:51:12.42369
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-02-23 10:51:12.430566
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-02-23 10:51:12.442935
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-02-23 10:51:12.453251
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-02-23 10:51:12.458885
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-02-23 10:51:12.464156
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-02-23 10:51:12.469607
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-02-23 10:51:12.474421
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-02-23 10:51:12.479277
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-02-23 10:51:12.483968
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-02-23 10:51:12.488828
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-02-23 10:51:12.493529
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-02-23 10:51:12.498238
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-02-23 10:51:12.502889
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-02-23 10:51:12.507868
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-02-23 10:51:12.512728
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-02-23 10:51:12.517538
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-02-23 10:51:12.522352
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-02-23 10:51:12.528447
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-02-23 10:51:12.543051
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-02-23 10:51:12.548069
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-02-23 10:51:12.552863
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-02-23 10:51:12.557606
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-02-23 10:51:12.56226
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-02-23 10:51:12.567053
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-02-23 10:51:12.572474
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-02-23 10:51:12.582813
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-02-23 10:51:12.588358
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-02-23 10:51:12.593605
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-02-23 10:51:12.60884
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-02-23 10:51:12.614369
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-02-23 10:51:13.263756
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-02-23 10:51:13.265932
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-02-23 10:51:13.277103
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-02-23 10:51:13.28025
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-02-23 10:51:13.282372
56	fix-optimized-search-function	cb58526ebc23048049fd5bf2fd148d18b04a2073	2026-02-23 10:51:13.2892
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-04-09 15:25:53.65558
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-04-09 15:25:53.664194
\.


--
-- TOC entry 4061 (class 0 OID 17096)
-- Dependencies: 364
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- TOC entry 4062 (class 0 OID 17145)
-- Dependencies: 365
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- TOC entry 4063 (class 0 OID 17159)
-- Dependencies: 366
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 4066 (class 0 OID 17229)
-- Dependencies: 369
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3668 (class 0 OID 16608)
-- Dependencies: 344
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4083 (class 0 OID 0)
-- Dependencies: 339
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- TOC entry 4084 (class 0 OID 0)
-- Dependencies: 379
-- Name: Resort_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Resort_id_seq"', 156, true);


--
-- TOC entry 4085 (class 0 OID 0)
-- Dependencies: 381
-- Name: SnowRecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."SnowRecord_id_seq"', 11110, true);


--
-- TOC entry 4086 (class 0 OID 0)
-- Dependencies: 372
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


-- Completed on 2026-04-12 04:52:01 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict f40dWdJ33GZePfJmrRbJOOL7RgbxlmZIeAkOxZNdaT727qnhtEojjzXcLvOmywc

